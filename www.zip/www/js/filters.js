(function() {
  angular
  .module('purple-wind.filters', []);
})();
(function() {
    angular
        .module('purple-wind.filters')
        .filter('capitalize', exec);

    function exec() {
        return function(input, all) {
            var reg = (all) ? /([^\W_]+[^\s-]*) */g : /([^\W_]+[^\s-]*)/;
            return (!!input) ? input.replace(reg, function(txt) {
                return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
            }) : '';
        }
    }

})();
(function() {
    exec.$inject = ['$storage', 'lodash'];
    angular
        .module('purple-wind.filters')
        .filter('month', exec);

    function exec($storage, lodash) {
        return function(input) {
            var output,
                months = $storage.get('months'),
                re = '(\\d+)(\\s+-\\s+)(\\d+)';
            var p = new RegExp(re, ['i']);
            var m = p.exec(input);
            if (m != null) {
                var month = m[1];
                var year = m[3];

                output = months[lodash.toNumber(month) - 1] + ' ' + year;
            }
            return output;
        }
    }

})();
(function() {
    angular
        .module('purple-wind.filters')
        .filter('cashback', exec);

    function exec() {
        return function(input) {
            return (input - input.toFixed(2) === 0) ? input : input.toPrecision(2);
        }
    }

})();