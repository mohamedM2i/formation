(function() {
    angular
        .module('purple-wind.components', ['ui.router']);
})();
(function() {
    service.$inject = ['platforms', '$storage', 'lodash', '$q'];
    angular
        .module('purple-wind.components')
        .service('$notification', service);

    function service(platforms, $storage, lodash, $q) {

        var target = (ionic.Platform.isAndroid()) ? 'android' : 'ios';
        /**
         * initialize the set up of OneSignal SDK in order
         * to activate the push notifications
         * @param {any} cfg conf object that contains all settings needed by App
         * @param {any} cb a call be that will be called each time the device receive a push notification
         */
        function initialize(cfg, cb) {
            var dfd = $q.defer();
            if (window && window.plugins && window.plugins.OneSignal) {
                var OneSignal = window.plugins.OneSignal;
                OneSignal
                    .startInit(cfg.oneSignalID)
                    .handleNotificationOpened(cb)
                    .endInit();

                if (cfg.enableNotificationsWhenActive) {
                    OneSignal.enableNotificationsWhenActive(cfg.enableNotificationsWhenActive);
                }

                if (cfg.enableVibrate) {
                    OneSignal.enableVibrate(cfg.enableVibrate);
                }

                if (cfg.enableSound) {
                    OneSignal.enableSound(cfg.enableSound);
                }

                OneSignal.getIds(function(ids) {
                    if (!$storage.get('OneSignalUserID')) {
                        $storage.set('OneSignalUserID', ids.userId);
                        $storage.set('OneSignalPushToken', ids.pushToken);
                    }
                    dfd.resolve(ids);
                });

                if (cfg.registerForPushNotifications) {
                    OneSignal.registerForPushNotifications();
                }

                OneSignal.setSubscription(true);
                OneSignal.sendTag('App', 'CLO');
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }
        /**
         * merge both of the local and on-server configurations 
         * @param {any} oneSignalConf on-server configuration object
         * @returns a single object that contains all OneSignal configuration
         */

        function merge(oneSignalConf) {
            var mergedObj = lodash.mergeWith(platforms[target], oneSignalConf);
            /* jshint ignore:start */
            mergedObj.config.googleProjectNumber = (mergedObj.config && mergedObj.config.googleProjectNumber) ? mergedObj.config.googleProjectNumber.toString() : '';
            /* jshint ignore:end */
            return mergedObj;
        }
        /**
         * notification handler that will be executed each time the device receive a push notification
         */
        function handleNotification() {

        }


        function deactivateNotification() {
            if (window && window.plugins && window.plugins.OneSignal) {
                var OneSignal = window.plugins.OneSignal;
                OneSignal.setSubscription(false);
            }
        }

        function activateNotification() {
            if (window && window.plugins && window.plugins.OneSignal) {
                var OneSignal = window.plugins.OneSignal;
                OneSignal.setSubscription(true);
            }
        }

        return {
            'init': initialize,
            'merge': merge,
            'handle': handleNotification,
            'deactivateNotification': deactivateNotification,
            'activateNotification': activateNotification
        };
    }
})();
(function() {

    config.$inject = ['localStorageServiceProvider'];
    storageService.$inject = ['localStorageService'];
    angular
        .module('purple-wind.components')
        .config(config)
        .service('$storage', storageService);

    function config(localStorageServiceProvider) {
        localStorageServiceProvider
            .setPrefix('purple-wind')
            .setStorageType('localStorage')
            .setNotify(true, true);
    }

    function storageService(localStorageService) {
        function setItem(key, val) {
            return localStorageService.set(key, val);
        }

        function getItem(key) {
            return localStorageService.get(key);
        }

        function removeItem(key) {
            return localStorageService.remove(key);
        }

        function clearAll() {
            return localStorageService.clearAll();
        }
        return {
            'set': setItem,
            'get': getItem,
            'remove': removeItem,
            'clearAll': clearAll
        };
    }

})();
(function() {
    popupHandlerService.$inject = ['$ionicPopup', '$translate', '$storage', 'urls'];
    angular
        .module('purple-wind.components')
        .service('$popup', popupHandlerService);

    function popupHandlerService($ionicPopup, $translate, $storage, urls) {
        var popUp;
        return {
            'showCustomizedError': customizedError,
            'showPopUpError': showPopUpError,
            'showPopUpDialog': showPopUpDialog,
            'showBasicPopupDialog': showBasicPopupDialog,
            'showUpdateAlert': showUpdateAlert,
            'showBasicAlertDialog': showBasicAlertDialog
        };
        /**
         * customizedError customized the error so we can show the popUp alert
         * @param  {object} err
         * @return {object} error customized
         */
        function customizedError(err) {
            var error = {};
            if (err && typeof err === 'object') {
                error.status = err.status;
                error.alertTitle = 'TITLE_ERROR_' + error.status;
                error.alertMessage = 'MESSAGE_ERROR_' + error.status;
                error.cssClass = 'errorPopupClass';
            }
            showPopUpError(error);
            return error;
        }
        /**
         * showPopUpError show the pop up error
         * @param  {object} error
         */
        function showPopUpError(error) {
            if (!popUp) {
                popUp = $ionicPopup.alert({
                    title: $translate.instant(error.alertTitle),
                    template: $translate.instant(error.alertMessage),
                    okText: $translate.instant('CAPITO_TEXT'),
                    cssClass: error.cssClass || 'errorPopupClass'
                }).then(function() {
                    popUp = null;
                });
            }
        }

        /**
         * showPopUpDialog show the pop up dialog
         * @param  {object} dialog
         */
        function showPopUpDialog(dialog) {
            showBasicPopupDialog({
                title: $translate.instant(dialog.alertTitle),
                template: $translate.instant(dialog.alertMessage)
            });
        }

        /**
         * showBasicPopUpDialog show a customizable pop up dialog
         * @param  {object} dialog
         */
        function showBasicPopupDialog(dialogCfg) {
            dialogCfg.okText = dialogCfg.okText || $translate.instant('OK_TEXT');
            dialogCfg.cssClass = 'customPopupClass';
            return $ionicPopup.confirm(dialogCfg);
        }

        /**
         * showBasicPopUpDialog show a customizable pop up dialog
         * @param  {object} dialog
         */
        function showBasicAlertDialog(dialogCfg) {
            dialogCfg.okText = dialogCfg.okText || $translate.instant('OK_TEXT');
            dialogCfg.cssClass = 'customPopupClass';
            return $ionicPopup.alert(dialogCfg);
        }

        function checkUpdateInterval() {
            var today = new Date(),
                firstInvite = new Date($storage.get('firstUpdateInvite'));
            return parseInt((today - firstInvite) / (24 * 3600 * 1000));
        }

        function showUpdateAlert(cfg) {
            if (!popUp) {
                if (!$storage.get('firstUpdateInvite')) {
                    $storage.set('firstUpdateInvite', new Date());
                } else {
                    cfg.mandatory = checkUpdateInterval() > 7;
                }
                var alertbuttons = [{
                        text: $translate.instant('BUTTON_CANCEL'),
                        onTap: function(e) {
                            if (cfg.mandatory) {
                                e.preventDefault();
                            }
                        }
                    },
                    {
                        text: $translate.instant('BUTTON_UPDATE'),
                        onTap: function() {
                            cordova.plugins.market.open(urls['store-' + ionic.Platform.platform()]);
                        }
                    }
                ];

                if (cfg.mandatory) {
                    alertbuttons.splice(0, 1);
                }
                popUp = $ionicPopup.show({
                    title: $translate.instant('UPDATE_ALERT_TITLE'),
                    subTitle: cfg.mandatory ? $translate.instant('UPDATE_ALERT_SUBTITLE_MANDATORY') : $translate.instant('UPDATE_ALERT_SUBTITLE'),
                    buttons: alertbuttons
                }).then(function() {
                    popUp = null;
                });
            }
        }
    }
})();
(function() {
    svc.$inject = ['$ionicModal'];
    angular
        .module('purple-wind.components')
        .service('$modal', svc);

    function svc($ionicModal) {
        function loadTemplate(url, target, effect) {
            return $ionicModal.fromTemplateUrl(url, {
                scope: target,
                animation: effect
            });
        }

        return {
            load: loadTemplate
        };
    }
})();
(function() {
    svc.$inject = ['$cordovaGeolocation', 'geolocation'];
    angular
        .module('purple-wind.components')
        .service('$map', svc);

    function svc($cordovaGeolocation, geolocation) {

        function pinpoint() {
            return $cordovaGeolocation.getCurrentPosition(geolocation.config);
        }

        function load() {
            var map2load = geolocation.osm;
            map2load.icons = geolocation.icons;
            return map2load;
        }

        function calculate(pointA, pointB) {
            var R = geolocation.earthRadius;
            var dLat = getRad(pointB.lat - pointA.lat);
            var dLon = getRad(pointB.lon - pointA.lon);
            var lat1 = getRad(pointA.lat);
            var lat2 = getRad(pointB.lat);
            var a = (Math.sin(dLat / 2) * Math.sin(dLat / 2)) +
                (Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2));
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            return R * c;
        }

        function getRad(deg) {
            return deg * Math.PI / 180;
        }

        return {
            pinpoint: pinpoint,
            load: load,
            calculate: calculate
        };
    }
})();
(function() {
    svc.$inject = ['$q'];
    angular
        .module('purple-wind.components')
        .service('$permissions', svc);

    function svc($q) {
        /**
         * Returns true if the device setting for location is on.
         * 
         * - On Android this returns true if Location Mode is switched on. 
         * - On iOS this returns true if Location Services is switched on.
         * 
         * @returns promise
         */
        function isLocationEnabled() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.isLocationEnabled(function(data) {
                _dfd.resolve(data)
            }, function(err) {
                _dfd.reject(err)
            });
            return _dfd.promise;
        }
        /**
         * Checks if app is able to access device location.
         * 
         * - On iOS Mobile this returns true if both the device setting is enabled AND the application is authorized to use location.
         * When location is enabled, the locations returned are by a mixture GPS hardware, network triangulation and Wifi network IDs.
         * 
         * - On Android, this returns true if Location mode is enabled and any mode is selected (e.g. Battery saving, Device only, High accuracy) AND if the app is authorised to use location.
         * 
         * - When location is enabled, the locations returned are dependent on the location mode:
         * Battery saving = network triangulation and Wifi network IDs (low accuracy)
         * Device only = GPS hardware only (high accuracy)
         * High accuracy = GPS hardware, network triangulation and Wifi network IDs (high and low accuracy)
         * @returns promise
         */
        function isLocationAvailable() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.isLocationAvailable(function(data) {
                _dfd.resolve(data);
            }, function(err) {
                _dfd.reject(err);
            })
            return _dfd.promise;
        }
        /**
         * Checks if the application is authorized to use location.
         * 
         * @returns promise
         */
        function isLocationAuthorized() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.isLocationAuthorized(function(data) {
                _dfd.resolve(data);
            }, function(err) {
                _dfd.reject(err);
            });
            return _dfd.promise;
        }
        /**
         * Returns the location authorization status for the application.
         * 
         * Note for Android: 
         * this is intended for Android 6 / API 23 and above.
         * Calling on Android 5 / API 22 and below will always return GRANTED status as permissions are already granted at installation time.
         * 
         * @returns promise
         */
        function getLocationAuthorizationStatus() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.getLocationAuthorizationStatus(function(data) {
                _dfd.resolve(checkStatus(data));
            }, function(err) {
                _dfd.reject(err);
            });
            return _dfd.promise;
        }
        /**
         * checks the value of permission status
         * 
         * @param {String} status 
         * @returns true, if the permission is granted or 'when in use' (for iOS).false, if the permission was not requested or has been denied.
         */
        function checkStatus(status) {
            var _res = { 'permission': status };
            switch (status) {
                case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                    _res.status = false;
                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED:
                    _res.status = false;
                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                    _res.status = false;
                    break;
                case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                    _res.status = true;
                    break;
                case cordova.plugins.diagnostic.permissionStatus.GRANTED_WHEN_IN_USE:
                    _res.status = true;
                    break;
            }
            return _res;
        }
        /**
         * Requests location authorization for the application.
         * - Notes for iOS:
         * Calling this on iOS 7 or below will have no effect, as location permissions are are implicitly granted.
         * On iOS 8+, authorization can be requested to use location either "when in use" (only in foreground) or "always" (foreground and background).
         * This should only be called if authorization status is NOT_DETERMINED - calling it when in any other state will have no effect.
         * 
         * - Notes for Android:
         * This is intended for Android 6 / API 23 and above. Calling on Android 5 / API 22 and below will have no effect as the permissions are already granted at installation time.
         * The successCallback is invoked in response to the user's choice in the permission dialog and is passed the resulting authorization status.
         * 
         * @returns promise
         */
        function requestLocationAuthorization() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.requestLocationAuthorization(function(data) {
                    _dfd.resolve(checkStatus(data));
                },
                function(err) {
                    _dfd.reject(err);
                });
            return _dfd.promise;
        }

        return {
            'isLocationEnabled': isLocationEnabled,
            'isLocationAvailable': isLocationAvailable,
            'isLocationAuthorized': isLocationAuthorized,
            'getLocationAuthorizationStatus': getLocationAuthorizationStatus,
            'requestLocationAuthorization': requestLocationAuthorization
        };
    }
})();
(function() {
    svc.$inject = ['config', 'urls', '$http', 'lodash', '$storage'];
    angular
        .module('purple-wind.components')
        .service('$requester', svc);

    function svc(config, urls, $http, lodash, $storage) {
        /**
         * Send an http request to server
         * 
         * @param {any} endpoint endpoint to call, if the endpoint must define a method. Otherwise GET will be used by default 
         * @param {any} data object that will contain the data to send to server
         * @returns a promise to be resolved later
         */
        function request(endpoint, data) {
            var config = {
                'method': endpoint.method || 'GET',
                'url': endpoint.url,
                'data': data
            };
            var token = $storage.get('tokenID');
            if (token) {
                config.headers = {
                    Authorization: 'Bearer ' + token
                };
            }
            return $http(config);
        }
        /**
         * build an URL to be used for endpoint call
         * 
         * @param {any} domain the domain of the back-office
         * @param {any} url url of the endpoint
         * @param {any} params parameters ot the request
         * @returns an URL to be used for http requests
         */
        function buildURL(domain, url, params) {
            var protocol = (config.env.domain[config.env.target].https) ? 'https' : 'http',
                iterator = 0,
                separator = '';
            lodash.forIn(params, function(value, key) {
                separator = (iterator > 0) ? '&' : '?';
                url = url + separator + key + '=' + value;
                iterator++;
                return;
            });
            return protocol + '://' + domain + url;
        }
        /**
         * build an endpoint
         * 
         * @param {any} endpoint endpoint to call
         * @param {any} url a full url that is obtained by call buildURL method
         * @returns a copy of the endpoint to be used for request method
         */
        function buildEndPoint(endpoint, url) {
            var result = angular.copy(endpoint);
            result.url = url;
            return result;
        }

        /**
         * call an endpoint dynamically
         * 
         * @param {any} api the name of the api as specified in the back-office list
         * @param {any} data data to send 
         * @returns a promise to be resolved later
         */
        function call(api, data) {
            var endPoints = $storage.get('endpoints'),
                _endpointURL,
                _endpointAPI;
            if (endPoints[api]) {
                _endpointAPI = endPoints[api];
            }
            if (_endpointAPI && _endpointAPI.method.toString().toUpperCase() === 'GET') {
                _endpointURL = buildURL(config.env.domain[config.env.target].url, _endpointAPI.url, data);
                /* set variable {data} to null.
                   it has been put in the url.
                   there is no need it anymore
                */
                data = null;
            } else {
                _endpointURL = buildURL(config.env.domain[config.env.target].url, _endpointAPI.url);
            }
            endPoints[api] = buildEndPoint(_endpointAPI, _endpointURL);
            return request(endPoints[api], data);
        }

        function trimURL(url) {
            var trimmedURL = '',
                re1 = '((?:\\/[\\w\\.\\-]+)+)(\\/)',
                re2 = '(\\{id\\})';

            var p = new RegExp(re1 + re2, ['i']);
            var m = p.exec(url);
            if (m != null) {
                trimmedURL = m[1];
            }
            return trimmedURL;
        }
        return {
            'request': request,
            'buildURL': buildURL,
            'buildEndPoint': buildEndPoint,
            'api': call,
            'trimURL': trimURL
        };
    }
})();
(function() {
    svc.$inject = ['$requester', '$q'];
    angular
        .module('purple-wind.components')
        .service('$security', svc);

    function svc($requester, $q) {
        function authenticate(login, pwd) {
            var dfd = $q.defer();
            $requester
                .api('authenticate_user', {
                    'username': login,
                    'password': pwd,
                    'rememberMe': true
                })
                .then(function(success) {
                    dfd.resolve(success);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }

        function authenticateWithToken() {
            var dfd = $q.defer();
            $requester
                .api('authenticate_token', {})
                .then(function(success) {
                    dfd.resolve(success);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }
        return {
            'authenticateUser': authenticate,
            'authenticateToken': authenticateWithToken
        }
    }
})();
(function() {
    svc.$inject = ['$document', '$compile', '$rootScope', 'config', '$storage'];
    angular
        .module('purple-wind.components')
        .service('$styler', svc);

    function svc($document, $compile, $rootScope, config, $storage) {

        function injectStyle(path) {
            var html = '<link rel="stylesheet" type="text/css" href="' + path + '" >';
            angular
                .element($document[0].head)
                .append($compile(html)($rootScope));
        }

        function loadDefaultStyle() {
            var style = $storage.get('style') || config.style.default;
            console.log('loaded style ' + style);
            injectStyle(style);
        }

        function loadBankStyle() {
            var bank = $storage.get('reseau').toString().toLowerCase() || 'bp',
                href = 'css/app-' + bank + '.min.css';
            angular
                .element($document[0].head.getElementsByTagName('link')[0])
                .attr('href', 'css/app-' + bank + '.min.css');
            $storage.set('style', href);
        }
        return {
            'css': injectStyle,
            'default': loadDefaultStyle,
            'change': loadBankStyle
        };
    }
})();
(function() {
    service.$inject = ['$requester', '$storage', '$notification', '$state', 'config', 'urls', 'lodash', '$q'];
    angular
        .module('purple-wind.components')
        .service('$startup', service);

    function service($requester, $storage, $notification, $state, config, urls, lodash, $q) {
        function initServices() {
            var initURL = $requester.buildURL(
                config.env.domain[config.env.target].url,
                urls.init, {
                    version: config.env.domain[config.env.target].api
                });

            var initEndPoint = $requester.buildEndPoint(config.env.domain[config.env.target], initURL);
            return $requester.request(initEndPoint)
                .then(processOneSignalConfig)
                .then(doWhenInitSuccess, doWhenInitError);
        }

        function compareVersions(versionA, versionB) {
            var digitsA = lodash.split(versionA, '.'),
                digitsB = lodash.split(versionB, '.'),
                comparison0 = compare(digitsA[0], digitsB[0]),
                comparison1 = compare(digitsA[1], digitsB[1]);

            if (lodash.eq(versionA, versionB)) {
                return {};
            } else {
                if (comparison0 !== 0) {
                    return {
                        'mustUpdate': true,
                        'mandatory': true
                    };
                }
                if (comparison1 >= 0) {
                    return {
                        'mustUpdate': true,
                        'mandatory': false
                    };
                }
            }
        }

        function compare(itemA, itemB) {
            var _result;
            if (lodash.toNumber(itemA) === lodash.toNumber(itemB)) {
                _result = 0;
            }
            if (lodash.toNumber(itemA) > lodash.toNumber(itemB)) {
                _result = 1;
            }
            if (lodash.toNumber(itemA) < lodash.toNumber(itemB)) {
                _result = -1;
            }
            return _result;
        }

        function processOneSignalConfig(res) {
            var dfd = $q.defer(),
                platform = ionic.Platform.platform(),
                oneSignalID = res.data.oneSignal.onesignalID,
                config = $notification.merge(res.data.oneSignal[platform]);
            res.data.oneSignal = config;
            res.data.oneSignal.oneSignalID = oneSignalID;
            dfd.resolve(res.data);
            return dfd.promise;
        }

        function initNotifications(cfg) {
            var oneSignalConfig = $notification.merge(cfg);
            return $notification.init(oneSignalConfig, $notification.handle);
        }

        function doWhenInitSuccess(res) {
            $storage.set('endpoints', res.endpoints);
            $storage.set('oneSignal', res.oneSignal);
            $storage.set('tags', res.tags);
            return res;
        }

        function doWhenInitError() {
            if (!$storage.get('endpoints') && !$storage.get('oneSignal') && !$storage.get('tags')) {
                console.error('error on getting endpoints lists, oneSignal information or tags information');
            } else {
                console.log('endpoints lists, oneSignal information and tags information loaded from cache');
            }
        }

        function defaultState(route, mustUpdate) {
            if (mustUpdate) {
                $state.go(route, mustUpdate);
            } else {
                $state.go(route);
            }
        }

        return {
            'init': initServices,
            'notification': initNotifications,
            'defaultState': defaultState,
            'processAppInfo': compareVersions
        }
    }
})();
(function() {
    directive.$inject = ['$parse'];
    angular
        .module('purple-wind.components')
        .directive('passwordEq', directive);

    function directive($parse) {
        return {
            require: 'ngModel',
            link: function(scope, elem, attrs, ngModel) {
                if (typeof attrs.passwordEq === 'string') {
                    var parser = $parse(attrs.passwordEq),
                        password = parser(scope);
                    // Watch for changes to this input
                    scope.$watch(attrs.ngModel, function(newValue) {
                        if (typeof newValue !== 'undefined') {
                            ngModel.$setValidity(attrs.name, newValue === password.$viewValue);
                        }
                    });
                }

            }
        }
    }
})();
(function() {
    angular
        .module('purple-wind.components')
        .directive('autoComplete', exec);

    function exec() {
        return {
            restrict: 'A',
            link: function($scope, el) {
                el.bind('change', function(e) {
                    e.preventDefault();
                });
            }
        };
    }

})();
(function() {
    service.$inject = ['$storage', '$state', 'config', 'lodash', '$q', '$popup'];
    angular
        .module('purple-wind.components')
        .service('$update', service);

    function service($storage, $state, config, lodash, $q, $popup) {
        function show(cfg) {
            if (cfg && cfg.mustUpdate) {
                $popup.showUpdateAlert(cfg);
            }
        }

        return {
            'displayUpdateMessage': show
        }
    }
})();
(function() {
    svc.$inject = ['$storage', 'tagPage', 'tagButton'];
    angular
        .module('purple-wind.components')
        .service('$tag', svc);

    function svc($storage, tagPage, tagButton) {

        // Information du device mobile
        var device = null;
        var isMobile = false;

        // Informations de site AtInternet
        var tagInformationSite = {
            log: 'logc233',
            logSSL: 'logs1233',
            secure: true,
            ignoreEmptyChapterValue: true,
            domain: 'xiti.com'
        };

        // Informations global de site
        var tagInformationGlobal = {
            1: '', // Réseau: BP, CE ou BRED
            2: '', // Géolocalisation: 0=non-géolocalisé, 1=géolocalisé
            3: '', // ID OneSignal du device
            4: '', // OS du device
            5: '' // Marque et modèle du device
        };

        // Variable tagATInternet
        var tagATInternet = null;

        // Fonction qui retourne les informtions de site
        function getTagInformationSite() {
            /* jshint ignore:start */
            if (typeof tagInformationSite.site === 'undefined') { tagInformationSite.site = $storage.get('tags') === null ? '585413' : $storage.get('tags').atinternet; }
            /* jshint ignore:end */
            return tagInformationSite;
        }

        function getTagATInternet() {
            if (tagATInternet === null) { tagATInternet = new ATInternet.Tracker.Tag(getTagInformationSite()); }
            return tagATInternet;
        }

        // Fonction qui retourne les informations de tag par rapport à un nom de page
        function findTagInformationPage(nomPage) {
            return tagPage[nomPage];
        }

        // Fonction qui retourne les informations de tag par rapport à un click
        function findTagInformationClick(nomClick) {
            return tagButton[nomClick];
        }

        // Fonction qui enregistre une personne connectée
        function lSetUser(idClient) {
            // Récupération du tag ATInternet
            var lTagATInternet = getTagATInternet();

            // Positionnement des infos user
            lTagATInternet.identifiedVisitor.set({
                id: idClient,
                category: '1'
            });
        }

        // Fonction qui retire une personne connectée
        function lUnsetUser() {
            // Récupération du tag ATInternet
            var lTagATInternet = getTagATInternet();

            // Retrait des infos user
            lTagATInternet.identifiedVisitor.unset();
        }

        // Fonction d'envoi du tag de page à AT Internet
        function lAddGlobalInformation() {
            var reseau = $storage.get('reseau');
            var settings = $storage.get('settings');
            var OneSignalUserID = $storage.get('OneSignalUserID');

            // Indicateur global de site: Réseau (BP, CE ou BRED)
            tagInformationGlobal[1] = reseau === null ? '' : reseau.toUpperCase();

            if (isMobile) {
                // Indicateur global de site: Géolocalisation (0=non-géolocalisé, 1=géolocalisé)
                tagInformationGlobal[2] = (settings === null || settings.geolocalisation === null) ? '' : settings.geolocalisation;

                // Indicateur global de site: ID OneSignal du device
                tagInformationGlobal[3] = OneSignalUserID === null ? '' : OneSignalUserID;
            }
        }

        function lSendTagPageGo(tagInfoPage, detailPage) {
            // Récupération du tag ATInternet
            var lTagATInternet = getTagATInternet();

            // réinitilisation de la page
            lTagATInternet.page.reset();

            lTagATInternet.customVars.set({
                site: tagInformationGlobal
            });

            if (typeof detailPage !== 'undefined' && detailPage !== null) {
                lTagATInternet.customVars.set({
                    page: detailPage
                });
            }
            // Indicateurs de page
            lTagATInternet.page.set(tagInfoPage);

            // Envoi du Tag AT Internet
            lTagATInternet.dispatch();
        }

        function lSendTagPage(nomPage, tagChapitre, detailPage) {
            // console.log('tagPage: ', nomPage);

            // Récupération des informations de page pour AtInternet
            var tagInfoPage = findTagInformationPage(nomPage);

            // Modification des infos de page si nécessaire
            Object.keys(tagChapitre).forEach(function(key) {
                tagInfoPage[key] = tagChapitre[key];
            });

            if (typeof tagInfoPage !== 'undefined') {
                // Récupération des informations de mobile
                if (device === null) {
                    isMobile = (window.cordova);

                    if (isMobile) {
                        ionic.Platform.ready(function() {
                            // will execute when device is ready, or immediately if the device is already ready.
                            device = ionic.Platform.device();

                            // Indicateur global de site: OS du device
                            tagInformationGlobal[4] = isMobile ? (device.platform.toUpperCase() + ' ' + device.version) : 'web';

                            // Indicateur global de site: Marque et modèle du device
                            tagInformationGlobal[5] = device.manufacturer.toUpperCase() + ' ' + device.model.toUpperCase();
                            $storage.set('device', device);
                            // Autres indicateurs globaux: Réseau, Géolocalisation, ID OneSignal du device
                            lAddGlobalInformation();

                            // Envoi du Tag AT Internet
                            lSendTagPageGo(tagInfoPage, detailPage);
                        });
                    } else {
                        // Pas un mobile (device est un object vide {} par opposition à null)
                        device = {};

                        // Indicateurs globaux: Réseau, Géolocalisation, ID OneSignal du device
                        lAddGlobalInformation();

                        // Envoi du Tag AT Internet
                        lSendTagPageGo(tagInfoPage, detailPage);
                    }
                } else {
                    // Indicateurs globaux: Réseau, Géolocalisation, ID OneSignal du device
                    lAddGlobalInformation();

                    // Envoi du Tag AT Internet
                    lSendTagPageGo(tagInfoPage, detailPage);
                }
            }
        }

        // Fonction d'envoi du tag de click de bouton à AT Internet
        function lSendClickBouton(nomClick) {
            // Récupération des informations de click pour AtInternet
            var tagInfoClick = findTagInformationClick(nomClick);

            // console.log('tagButton: ', nomClick);

            if (typeof tagInfoClick !== 'undefined') {
                // Récupération du tag ATInternet
                var lTagATInternet = getTagATInternet();

                // Insertion de l'élément du DOM
                // tagInfoClick.elem = elementDom;

                // Envoi du tag
                return lTagATInternet.click.send(tagInfoClick);
            } else {
                return null;
            }
        }

        // Fonction d'envoi du tag de click de champs à AT Internet
        function lSendClickChamps(name, type, chapter1, chapter2, chapter3) {
            if (typeof name !== 'undefined') {
                // Récupération du tag ATInternet
                var lTagATInternet = getTagATInternet();

                // Insertion des informations à remonter dans le tag
                var tagInfoChamps = { name: name, type: type };

                tagInfoChamps.chapter1 = typeof chapter1 !== 'undefined' ? chapter1 : '';
                tagInfoChamps.chapter2 = typeof chapter2 !== 'undefined' ? chapter2 : '';
                tagInfoChamps.chapter3 = typeof chapter3 !== 'undefined' ? chapter3 : '';

                // Insertion de l'élément du DOM
                // tagInfoClick.elem = elementDom;

                // Envoi du tag
                return lTagATInternet.click.send(tagInfoChamps);
            } else {
                return null;
            }
        }

        return {
            setUser: lSetUser,
            unsetUser: lUnsetUser,

            sendTagPage: lSendTagPage,

            sendClickBouton: lSendClickBouton,
            sendClickChamps: lSendClickChamps
        }
    }
})();
(function() {
  execTagPage.$inject = ['$tag'];
  execTagPageOnClick.$inject = ['$tag'];
  angular
  .module('purple-wind.components')
  .directive('tagPage', execTagPage)
  .directive('tagPageOnClick', execTagPageOnClick);

  function lTagPage($tag, attrTagPage, attrTagChapitre){
    var lTagChapitre={};
    if (typeof attrTagChapitre !== 'undefined') lTagChapitre = JSON.parse(attrTagChapitre);
    $tag.sendTagPage(attrTagPage, lTagChapitre);
  }

  function execTagPage($tag) {
    return {
      restrict: 'EA',
      link: function($scope, elem, attrs) {
        // console.log('Tag-page directive:', attrs.tagPage, '; tagChapitre: ', attrs.tagChapitre);
        lTagPage($tag, attrs.tagPage, attrs.tagChapitre);
      }
    };
  }

  function execTagPageOnClick($tag) {
    return {
      restrict: 'EA',
      link: function($scope, elem, attrs) {
        elem.bind('click', function() {
          // console.log('Tag-page-on-click directive:', attrs.tagPageOnClick, '; tagChapitre: ', attrs.tagChapitre);
          lTagPage($tag, attrs.tagPageOnClick, attrs.tagChapitre);
        });
      }
    };
  }

})();
(function() {
  exec.$inject = ['$tag'];
  angular
  .module('purple-wind.components')
  .directive('tagButton', exec);

  function exec($tag) {
    return {
      restrict: 'A',
      link: function($scope, elem, attrs) {
        elem.bind('click', function() {
          // console.log('Tag-button directive:', attrs.tagButton);
          $tag.sendClickBouton(attrs.tagButton);
        });
      }
    };
  }

})();
(function() {
    angular
        .module('purple-wind.components')
        .directive('passwordStrengthBar', passwordStrengthBar);

    function passwordStrengthBar() {
        var directive = {
            replace: true,
            restrict: 'E',
            template: '<div id="strength">' +
                '<small >{{\'PASSWORD_STRENGTH\'|translate}}</small>' +
                '<ul id="strengthBar">' +
                '<li class="point"></li><li class="point"></li><li class="point"></li><li class="point"></li><li class="point"></li>' +
                '</ul>' +
                '</div>',
            scope: {
                passwordToCheck: '='
            },
            link: linkFunc
        };

        return directive;

        /* private helper methods*/

        function linkFunc(scope, iElement) {
            var strength = {
                colors: ['#F00', '#F90', '#FF0', '#9F0', '#0F0'],
                mesureStrength: function(p) {
                    var _force = 0;
                    var _regex = /[$-/:-?{-~!"^_`\[\]]/g; // "

                    var _lowerLetters = /[a-z]+/.test(p);
                    var _upperLetters = /[A-Z]+/.test(p);
                    var _numbers = /[0-9]+/.test(p);
                    var _symbols = _regex.test(p);

                    var _flags = [_lowerLetters, _upperLetters, _numbers, _symbols];
                    var _passedMatches = _flags.filter(function(el) {
                        return el === true;
                    }).length;

                    _force += 2 * p.length + ((p.length >= 10) ? 1 : 0);
                    _force += _passedMatches * 10;

                    // penalty (short password)
                    _force = (p.length <= 6) ? Math.min(_force, 10) : _force;

                    // penalty (poor variety of characters)
                    _force = (_passedMatches === 1) ? Math.min(_force, 10) : _force;
                    _force = (_passedMatches === 2) ? Math.min(_force, 20) : _force;
                    _force = (_passedMatches === 3) ? Math.min(_force, 40) : _force;

                    return _force;
                },
                getColor: function(s) {
                    var idx;
                    if (s <= 10) {
                        idx = 0;
                    } else if (s <= 20) {
                        idx = 1;
                    } else if (s <= 30) {
                        idx = 2;
                    } else if (s <= 40) {
                        idx = 3;
                    } else {
                        idx = 4;
                    }
                    return { idx: idx + 1, col: this.colors[idx] };
                }
            };
            scope.$watch('passwordToCheck', function(password) {
                var c, items;
                if (password) {
                    c = strength.getColor(strength.mesureStrength(password));
                    iElement.removeClass('ng-hide');
                    items = iElement.find('ul').children('li');
                    items.css({ 'background-color': '#DDD' });

                    items.splice(c.idx, items.length);
                    items.css({ 'background-color': c.col });

                } else {
                    c = strength.getColor(strength.mesureStrength(' '));
                    iElement.removeClass('ng-hide');
                    items = iElement.find('ul').children('li');
                    items.css({ 'background-color': '#DDD' });

                    items.splice(c.idx, items.length);
                    items.css({ 'background-color': c.col });
                }
            });
        }
    }
})();
(function() {
    angular
        .module('purple-wind.components')
        .constant('platforms', {
            // onesignalID: '9ef1d867-13cc-452f-be19-ebb6e0d4a42b',
            android: {
                config: {
                    // googleProjectNumber: 622612570868,
                    autoRegister: true
                },
                enableNotificationsWhenActive: true,
                enableVibrate: true,
                enableSound: true
            },
            ios: {
                config: {
                    autoRegister: false,
                    googleProjectNumber: '',
                },
                registerForPushNotifications: true,
                enableVibrate: true,
                enableSound: true
            }
        })
})();
(function() {
    angular
        .module('purple-wind.components')
        .constant('geolocation', {
            icons: {
                default: {
                    iconUrl: 'img/marker-icon.png',
                    iconRetinaUrl: 'img/marker-icon-2x.png',
                    iconSize: [30, 50]
                },
                bp: {
                    iconUrl: 'img/marker-icon-bp.png',
                    iconRetinaUrl: 'img/marker-icon-bp-2x.png',
                    iconSize: [22, 27]
                },
                bred: {
                    iconUrl: 'img/marker-icon-bp.png',
                    iconRetinaUrl: 'img/marker-icon-bp-2x.png',
                    iconSize: [22, 27]
                },
                ce: {
                    iconUrl: 'img/marker-icon-ce.png',
                    iconRetinaUrl: 'img/marker-icon-ce-2x.png',
                    iconSize: [22, 27]
                },
                center: {
                    default: {
                        iconUrl: 'img/marker-center.png',
                        iconSize: [15, 15],
                        shadowSize: [20, 20]
                    },
                    bp: {
                        iconUrl: 'img/marker-center-bp.png',
                        iconSize: [15, 15],
                        shadowSize: [20, 20]
                    },
                    bred: {
                        iconUrl: 'img/marker-center-bp.png',
                        iconSize: [15, 15],
                        shadowSize: [20, 20]
                    },
                    ce: {
                        iconUrl: 'img/marker-center-ce.png',
                        iconSize: [15, 15],
                        shadowSize: [20, 20]
                    }
                }
            },
            earthRadius: 6371,
            unit: 'K',
            config: {
                timeout: 10000,
                enableHighAccuracy: false
            },
            osm: {
                defaults: {
                    attributionControl: false,
                    zoomControl: false,
                    fadeAnimation: true,
                    markerZoomAnimation: true,
                    touchZoom: true,
                    doubleClickZoom: true
                },
                cluster: {
                    showCoverageOnHover: false,
                    zoomToBoundsOnClick: true,
                    maxClusterRadius: 30
                },
                markers: [],
                center: {
                    lat: 46.234725,
                    lng: 2.214828,
                    zoom: 5
                },
                tiles: {
                    url: 'http://{s}.tile.osm.org/{z}/{x}/{y}.png'
                },
                layers: {
                    baselayers: {
                        osm: {
                            name: 'OpenStreetMap',
                            url: 'http://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
                            type: 'xyz'
                        },
                        basemaps: {
                            name: 'BaseMaps',
                            url: 'http://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png'
                        }
                    }
                }
            }
        });
})();
(function() {
    angular
        .module('purple-wind.components')
        .constant('config', {
            permissions: {
                ACCESS_CHECKIN_PROPERTIES: 'android.permission.ACCESS_CHECKIN_PROPERTIES',
                ACCESS_COARSE_LOCATION: 'android.permission.ACCESS_COARSE_LOCATION',
                ACCESS_FINE_LOCATION: 'android.permission.ACCESS_FINE_LOCATION',
                ACCESS_LOCATION_EXTRA_COMMANDS: 'android.permission.ACCESS_LOCATION_EXTRA_COMMANDS',
                ACCESS_MOCK_LOCATION: 'android.permission.ACCESS_MOCK_LOCATION',
                ACCESS_NETWORK_STATE: 'android.permission.ACCESS_NETWORK_STATE',
                ACCESS_WIFI_STATE: 'android.permission.ACCESS_WIFI_STATE',
                ACCOUNT_MANAGER: 'android.permission.ACCOUNT_MANAGER',
                BLUETOOTH: 'android.permission.BLUETOOTH',
                CALL_PHONE: 'android.permission.CALL_PHONE',
                CAMERA: 'android.permission.CAMERA',
                CHANGE_NETWORK_STATE: 'android.permission.CHANGE_NETWORK_STATE',
                CHANGE_WIFI_STATE: 'android.permission.CHANGE_WIFI_STATE',
                CONTROL_LOCATION_UPDATES: 'android.permission.CONTROL_LOCATION_UPDATES',
                EXPAND_STATUS_BAR: 'android.permission.EXPAND_STATUS_BAR',
                FORCE_BACK: 'android.permission.FORCE_BACK',
                GET_ACCOUNTS: 'android.permission.GET_ACCOUNTS',
                INTERNET: 'android.permission.INTERNET',
                LOCATION_HARDWARE: 'android.permission.LOCATION_HARDWARE',
                MANAGE_ACCOUNTS: 'android.permission.MANAGE_ACCOUNTS',
                MANAGE_APP_TOKENS: 'android.permission.MANAGE_APP_TOKENS',
                MANAGE_DOCUMENTS: 'android.permission.MANAGE_DOCUMENTS',
                MASTER_CLEAR: 'android.permission.MASTER_CLEAR',
                MEDIA_CONTENT_CONTROL: 'android.permission.MEDIA_CONTENT_CONTROL',
                MODIFY_AUDIO_SETTINGS: 'android.permission.MODIFY_AUDIO_SETTINGS',
                MODIFY_PHONE_STATE: 'android.permission.MODIFY_PHONE_STATE',
                MOUNT_FORMAT_FILESYSTEMS: 'android.permission.MOUNT_FORMAT_FILESYSTEMS',
                MOUNT_UNMOUNT_FILESYSTEMS: 'android.permission.MOUNT_UNMOUNT_FILESYSTEMS',
                NFC: 'android.permission.NFC',
                PROCESS_OUTGOING_CALLS: 'android.permission.PROCESS_OUTGOING_CALLS',
                READ_CALENDAR: 'android.permission.READ_CALENDAR',
                READ_CALL_LOG: 'android.permission.READ_CALL_LOG',
                READ_CONTACTS: 'android.permission.READ_CONTACTS',
                READ_EXTERNAL_STORAGE: 'android.permission.READ_EXTERNAL_STORAGE',
                READ_PHONE_STATE: 'android.permission.READ_PHONE_STATE',
                READ_SMS: 'android.permission.READ_SMS',
                READ_SYNC_STATS: 'android.permission.READ_SYNC_STATS',
                SEND_SMS: 'android.permission.SEND_SMS',
                STATUS_BAR: 'android.permission.STATUS_BAR',
                USE_CREDENTIALS: 'android.permission.USE_CREDENTIALS',
                VIBRATE: 'android.permission.VIBRATE',
                WRITE_SECURE_SETTINGS: 'android.permission.WRITE_SECURE_SETTINGS',
                WRITE_SETTINGS: 'android.permission.WRITE_SETTINGS',
                WRITE_SMS: 'android.permission.WRITE_SMS'
            },
            style: {
                default: 'css/app-bp.min.css'
            },
            fake: {
                cgu: ''
            },
            env: {
                target: 'local',
                domain: {
                    local: {
                        root: '192.168.102.114:9090/', //Do not remove the last slash character
                        url: '192.168.102.114:9090/socle-clo-ws/',
                        api: '1',
                        method: 'GET',
                        https: false
                    },
                    recette: {
                        root: 'mesbonsplans.dev.intranatixis.com/', //Do not remove the last slash character
                        url: 'mesbonsplans.dev.intranatixis.com/socle-clo-ws/',
                        api: '1',
                        method: 'GET',
                        https: true
                    },
                    qualif: {
                        root: 'www.qua.mapdil.com/', //Do not remove the last slash character
                        url: 'www.qua.mapdil.com/socle-clo-ws/',
                        api: '1',
                        method: 'GET',
                        https: true
                    },
                    prod: {
                        root: 'www.mapdil.com/', //Do not remove the last slash character
                        url: 'www.mapdil.com/socle-clo-ws/',
                        api: '1',
                        method: 'GET',
                        https: true
                    }
                }
            }
        });
})();
(function() {
    angular
        .module('purple-wind.components')
        .constant('urls', {
            'init': 'api/app/init',
            'image_advertiser': 'images/photo/',
            'image_logo_small': 'images/logo_90_50/',
            'image_logo_big': 'images/logo_190_90/',
            'store-ios': 'id1251954900',
            'store-android': 'com.natixis.clo'
        });
})();
(function() {
  angular
  .module('purple-wind.components')
  .constant('tagPage', {
    'intro': {name: 'Malin', chapter1: 'Tutoriel', chapter2: '', chapter3: ''},
    'mobile': {name: 'Mobile', chapter1: 'Tutoriel', chapter2: '', chapter3: ''},
    'simple': {name: 'Simple', chapter1: 'Tutoriel', chapter2: '', chapter3: ''},
    'optin': {name: 'Opt-in', chapter1: 'Authentification', chapter2: '', chapter3: ''},
    'cgu': {name: 'CGU', chapter1: 'Authentification', chapter2: '', chapter3: ''},
    'enroll.email': {name: 'Saisie email', chapter1: 'Authentification', chapter2: '', chapter3: ''},
    'enroll.activation': {name: 'Code activation', chapter1: 'Authentification', chapter2: 'Utilisateurs', chapter3: ''},
    'enroll.password': {name: 'Création Mot de Passe', chapter1: 'Authentification', chapter2: 'Utilisateurs', chapter3: ''},
    'enroll.subscribe': {name: 'Prospect', chapter1: 'Authentification', chapter2: 'Prospects', chapter3: ''},
    'enroll.acknowledgment': {name: 'Remerciements prospect banque', chapter1: 'Authentification', chapter2: 'Prospects', chapter3: ''},
    'enroll.acknowledgment-other': {name: 'Remerciements prospect autre', chapter1: 'Authentification', chapter2: 'Prospects', chapter3: ''},
    'login.html': {name: 'Mot de passe autre device', chapter1: 'Authentification', chapter2: 'Utilisateurs', chapter3: ''},
    'app.offers.map': {name: 'Offres localisées', chapter1: 'Offres', chapter2: 'Vue carte', chapter3: ''},
    'app.offer-popup': {name: 'Pop up Offre', chapter1: 'Offres', chapter2: 'Vue carte', chapter3: ''},
    'app.offer-map': {name: 'Détails offre', chapter1: 'Offres', chapter2: 'Offre sélectionnée', chapter3: ''},
    'app.offers.list': {name: 'Offres listées', chapter1: 'Offres', chapter2: 'Vue liste', chapter3: ''},
    'app.offer-list': {name: 'Détails offre', chapter1: 'Offres', chapter2: 'Offre sélectionnée', chapter3: ''},
    'app.cashback': {name: 'Mes remboursements', chapter1: 'Remboursement', chapter2: '', chapter3: ''},
    'app.cashback.rembourse': {name: 'Total remboursé', chapter1: 'Remboursement', chapter2: '', chapter3: ''},
    'app.cashback.attente': {name: 'Total en attente', chapter1: 'Remboursement', chapter2: '', chapter3: ''},
    'app.cashback.refuse': {name: 'Total refusé', chapter1: 'Remboursement', chapter2: '', chapter3: ''},
    'app.account': {name: 'Mon compte', chapter1: 'Mon compte', chapter2: '', chapter3: ''},
    'app.faq': {name: 'FAQ', chapter1: 'Mon compte', chapter2: 'FAQ', chapter3: ''},
    'app.faq.detail': {name: 'FAQ', chapter1: 'Mon compte', chapter2: 'FAQ', chapter3: ''},
    'app.contact': {name: 'Contact par mail', chapter1: 'Mon compte', chapter2: 'Contactez-nous', chapter3: ''},
    'app.settings': {name: 'Préférences', chapter1: 'Mon compte', chapter2: 'Réglage du compte', chapter3: ''},
    'app.resetpwd': {name: 'Modifier mon mot de passe', chapter1: 'Mon compte', chapter2: 'Réglage du compte', chapter3: ''},
    'app.cgu': {name: 'CGU', chapter1: 'Mon compte', chapter2: '', chapter3: ''}
  })
  .constant('tagButton', {
    'intro_next_nav': {name: 'Page suivante', type: 'navigation', chapter1: 'Tutoriel', chapter2: 'Malin', chapter3: ''},
    'mobile_next_nav': {name: 'Page suivante', type: 'navigation', chapter1: 'Tutoriel', chapter2: 'Mobile', chapter3: ''},
    'mobile_prev_nav': {name: 'Page précédente', type: 'navigation', chapter1: 'Tutoriel', chapter2: 'Mobile', chapter3: ''},
    'simple_prev_nav': {name: 'Page précédente', type: 'navigation', chapter1: 'Tutoriel', chapter2: 'Simple', chapter3: ''},
    'intro_btn': {name: 'J\'ai compris', type: 'action', chapter1: 'Tutoriel', chapter2: 'Simple', chapter3: ''},
    'optin_refuse_btn': {name: 'Refuser', type: 'action', chapter1: 'Authentification', chapter2: 'Optin', chapter3: ''},
    'optin_accept_btn': {name: 'Accepter', type: 'action', chapter1: 'Authentification', chapter2: 'Optin', chapter3: ''},
    'cgu_refuse_btn': {name: 'Refuser', type: 'action', chapter1: 'Authentification', chapter2: 'CGU', chapter3: ''},
    'cgu_accept_btn': {name: 'Accepter', type: 'action', chapter1: 'Authentification', chapter2: 'CGU', chapter3: ''},
    'email_suite_btn': {name: 'Poursuivre', type: 'navigation', chapter1: 'Authentification', chapter2: 'Authentification', chapter3: ''},
    'auth_code_suite_btn': {name: 'Poursuivre', type: 'action', chapter1: 'Authentification', chapter2: 'Activation', chapter3: ''},
    'auth_resend_code_btn': {name: 'Renvoyer code activation', type: 'action', chapter1: 'Authentification', chapter2: 'Activation', chapter3: ''},
    'pwd_valid_btn': {name: 'Valider', type: 'action', chapter1: 'Authentification', chapter2: 'Mot de passe', chapter3: ''},
    'pwd_forget_btn': {name: 'MDP oublié', type: 'navigation', chapter1: 'Authentification', chapter2: 'Mot de passe', chapter3: ''},
    'locate_valid_btn': {name: 'Autoriser', type: 'action', chapter1: 'Accueil', chapter2: 'Données de localisation', chapter3: ''},
    'locate_refuse_btn': {name: 'Refuser', type: 'action', chapter1: 'Accueil', chapter2: 'Données de localisation', chapter3: ''},
    'enroll_subscribe_refuse_btn': {name: 'Annuler', type: 'action', chapter1: 'Authentification', chapter2: 'Enrolement', chapter3: ''},
    'enroll_subscribe_accept_btn': {name: 'Poursuivre', type: 'action', chapter1: 'Authentification', chapter2: 'Enrolement', chapter3: ''},
    'offer_map_btn': {name: 'Mode Carte', type: 'navigation', chapter1: 'Bons plans', chapter2: '', chapter3: ''},
    'offer_list_btn': {name: 'Mode Liste', type: 'navigation', chapter1: 'Bons plans', chapter2: '', chapter3: ''},
    'offer_popup_btn': {name: 'Pop up détails offre', type: 'navigation', chapter1: 'Bons plans', chapter2: '', chapter3: ''},
    'account_faq_btn': {name: 'FAQ', type: 'navigation', chapter1: 'Mon compte', chapter2: '', chapter3: ''},
    'account_contact_btn': {name: 'Contactez-nous', type: 'navigation', chapter1: 'Mon compte', chapter2: '', chapter3: ''},
    'account_reglages_btn': {name: 'Réglages', type: 'navigation', chapter1: 'Mon compte', chapter2: '', chapter3: ''},
    'account_cgu_btn': {name: 'CGU', type: 'navigation', chapter1: 'Mon compte', chapter2: '', chapter3: ''}
  });
})();