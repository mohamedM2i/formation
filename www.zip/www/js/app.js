(function() {
    angular
        .module(
            'purple-wind', [
                //app dependencies
                'ionic',
                'ui.router',
                'pascalprecht.translate',
                'ngCookies',
                'ngCordova',
                'ngLodash',
                'LocalStorageModule',
                //app components dependencies
                'purple-wind.components',
                'purple-wind.filters',
                'purple-wind.entities',
                //app modules dependencies
                'purple-wind.intro',
                'purple-wind.enroll',
                'purple-wind.cgu',
                'purple-wind.optin',
                'purple-wind.tabs',
                'angular-inview'
            ]);
})();
(function() {
    runner.$inject = ['$ionicPlatform', '$storage', '$styler', '$startup', '$rootScope', '$translate', '$tag', 'lodash', '$cordovaAppVersion', 'offers', 'HomeService'];
    angular
        .module('purple-wind')
        .run(runner);

    function runner($ionicPlatform, $storage, $styler, $startup, $rootScope, $translate, $tag, lodash, $cordovaAppVersion, offers, HomeService) {
        // TODO: à supprimer
        /*
        var countDigest = 1;
        console.log('Nb de cycle Digest:', countDigest);
        $rootScope.$watch(function() {
            countDigest++;
            console.log('Nb de cycle Digest:', countDigest);
        });
        */

        //Exec tag AT-Internet on View
        $rootScope.$on('$stateChangeSuccess', function(event, toState) {
            // console.log('Event $stateChangeSuccess: ' + toState.name);
            // handle event
            if (toState.name === 'app.home') {
                HomeService.tagPage(false);
            } else {
                $tag.sendTagPage(toState.name, {});
            }
        });

        //loads the default style in order to display content
        $styler.default();
        $translate('MONTHS').then(function(translation) {
            $storage.set('months', lodash.split(translation, ','));
        });
        $ionicPlatform.ready(startup);
        /* jshint ignore:start */
        var notificationOpenedCallback = function(jsonData) {};
        /* jshint ignore:end */
        /**
         * function that is executed at mobile app start 
         */
        function startup() {
            var route = $storage.get('landing_state') ? $storage.get('landing_state') : 'intro';
            if (window.StatusBar) {
                if (ionic.Platform.isIOS()) {
                    window.StatusBar.styleDefault();
                    // window.StatusBar.styleLightContent();
                    // window.StatusBar.overlaysWebView(false);
                }
                // window.StatusBar.backgroundColorByHexString('#E5E5E5');
                window.StatusBar.styleDefault();
            }

            if (ionic.Platform.isIOS() && cordova && cordova.plugins) {
                if (cordova.plugins.Keyboard) {
                    cordova.plugins.Keyboard.disableScroll(true);
                }
            }
            if (navigator && navigator.splashscreen) {
                navigator.splashscreen.hide();
            }

            $startup.init()
                .then(function(data) {
                    if (window.cordova) {
                        // On mobile device
                        $cordovaAppVersion.getVersionNumber().then(function(version) {
                            if (data && data.app) {
                                $startup.defaultState(route, {
                                    'update': $startup.processAppInfo(data.app.mobile, version)
                                });
                            } else {
                                $startup.defaultState(route);
                            }
                        });
                    } else {
                        // On browser local dev
                        $startup.defaultState(route);
                    }
                });


        }

        $rootScope.$on('$cordovaNetwork:online', function() {
            var list = $storage.get('offersToSync');
            lodash.forEach(list, function(id) {
                if (id) {
                    offers.consult(id);
                }
            });
        });

    }
})();
(function() {

    angular
        .module('purple-wind')
        .config(config);
    //injection of angular-translate module
    config.$inject = ['$translateProvider'];

    function config($translateProvider) {
        //configuring security
        //link: http://angular-translate.github.io/docs/#/guide/19_security
        $translateProvider.useSanitizeValueStrategy(null);
        //Loading translation files asynchronously
        //link: http://angular-translate.github.io/docs/#/guide/12_asynchronous-loading
        //resource files must :
        //- be placed within assests/i18n folder
        //- their names must begin with 'resources-'
        //- they must be JSON files
        $translateProvider.useStaticFilesLoader({
            prefix: 'i18n/resources-',
            suffix: '.json'
        });
        //defining a fall back language
        //the default language of the app is the french language
        $translateProvider.fallbackLanguage('fr-FR');

        //Set up the language negociation
        //Link: https://angular-translate.github.io/docs/#/guide/09_language-negotiation
        $translateProvider.registerAvailableLanguageKeys(['fr-FR'], {
            'fr': 'fr-FR'
        });

        //the app must be able to determine the preferred language by app start
        //device language is set using 'navigator.language' property
        //link:  https://developer.mozilla.org/en-US/docs/Web/API/NavigatorLanguage/language
        //$translateProvider.preferredLanguage(navigator.language || navigator.systemLanguage);
        $translateProvider.preferredLanguage('fr-FR');

        //the preferred language must be stored
        //laguage storage is done as the following
        // 1- localStorage
        // 2- Cookies
        // link: https://angular-translate.github.io/docs/#/guide/10_storages
        $translateProvider.useLocalStorage();
        //$translateProvider.useCookieStorage();
    }

})();
(function() {
  angular
  .module('purple-wind')
  .config(config);

  function config() {
    Date.prototype.getQuantiemeInYear = function getQuantiemeInYearFn(){
      var dateCourante = this;
      var dateDebutAnnee = new Date();

      // On affecte à la date du début de l'année, le mois 1, le jour 1 et l'année courante
      dateDebutAnnee.setDate(1);
      dateDebutAnnee.setMonth(0);
      dateDebutAnnee.setFullYear(dateCourante.getFullYear());

      // On calcule la différence entre les deux dates. Le résultat étant en millisecondes, il faut convertir les millisecondes en jours
      return Math.trunc(((dateCourante.getTime() - dateDebutAnnee.getTime()) / (24 * 3600 * 1000))+1);
    }
  }
})();
(function() {
    config.$inject = ['$ionicConfigProvider', '$httpProvider'];
    angular
        .module('purple-wind')
        .config(config);

    function config($ionicConfigProvider, $httpProvider) {
        //$http configuration
        $httpProvider.defaults.headers.common = {};
        $httpProvider.defaults.headers.post = {
            'Content-Type': 'application/json'
        };
        $httpProvider.defaults.headers.put = {
            'Content-Type': 'application/json'
        };
        $httpProvider.defaults.headers.patch = {};
        $httpProvider.defaults.timeout = 5000;
        //Configure tabs position set to bottom for both
        //Android and iOS
        $ionicConfigProvider.tabs
            .position('bottom')
            .style('standard');
        // Configure back button
        $ionicConfigProvider.backButton
            .previousTitleText(false)
            .text('');
    }
})();