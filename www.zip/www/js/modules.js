(function() {
    angular
        .module('purple-wind.intro', []);
})();
(function() {
    cfg.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.intro')
        .config(cfg);

    function cfg($stateProvider) {
        $stateProvider
            .state('intro', {
                url: '/intro',
                templateUrl: 'modules/intro/intro.html',
                controller: 'IntroCtrl',
                controllerAs: 'intro',
                params: {
                    'update': null
                }
            });
    }
})();
(function() {
    ctrl.$inject = ['$scope', '$storage', '$tag', '$state', '$update', '$stateParams'];
    angular
        .module('purple-wind.intro')
        .controller('IntroCtrl', ctrl);

    function ctrl($scope, $storage, $tag, $state, $update, $stateParams) {
        var vm = this;
        vm.options = {
            loop: false,
            effect: 'slide',
            speed: 500
        };

		    $update.displayUpdateMessage($stateParams.update);

        var sendTagPage=function(index){
            switch (index) {
                case 0:
                    $tag.sendTagPage('intro', {});
                    break;
                case 1:
                    $tag.sendTagPage('mobile', {});
                    break;
                case 2:
                    $tag.sendTagPage('simple', {});
                    break;
            }
        };

        var sendTagAction=function(index, nextPage){
            switch (index) {
                case 0:
                    $tag.sendClickBouton('intro_' + (nextPage ? 'next' : 'prev') + '_nav');
                    break;
                case 1:
                    $tag.sendClickBouton('mobile_' + (nextPage ? 'next' : 'prev') + '_nav');
                    break;
                case 2:
                    $tag.sendClickBouton('simple_' + (nextPage ? 'next' : 'prev') + '_nav');
                    break;
            }
        };

        /*
        $scope.$on('$ionicSlides.sliderInitialized', function(event, data) {
            // data.slider is the instance of Swiper
            // sendTagPage(data.slider.activeIndex);
        });
        */

        $scope.$on('$ionicSlides.slideChangeStart', function(event, data) {
            sendTagAction(data.slider.previousIndex, data.slider.activeIndex > data.slider.previousIndex);
            sendTagPage(data.slider.activeIndex);
        });
        $storage.set('landing_state', 'intro');
    }
})();
(function() {
    angular
        .module('purple-wind.enroll', []);
})();
(function() {
    cfg.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.enroll')
        .config(cfg);

    function cfg($stateProvider) {
        $stateProvider
            .state('enroll', {
                url: '/enroll',
                abstract: true,
                templateUrl: 'modules/enroll/enroll.html'
            })
            .state('enroll.password', {
                url: '/password',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-password.html',
                        controller: 'EnrollPasswordCtrl',
                        controllerAs: 'vm'
                    }
                },
                params: {
                    'code': null,
                    'mail': null,
                    'isReset': false,
                    'update': null
                }
            })
            .state('enroll.activation', {
                url: '/activation',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-activation.html',
                        controller: 'EnrollActivationCtrl',
                        controllerAs: 'vm'
                    }
                },
                params: {
                    'mail': null,
                    'reset': false
                }
            })
            .state('enroll.subscribe', {
                url: '/subscribe',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-subscribe.html',
                        controller: 'EnrollSubscribeCtrl',
                        controllerAs: 'vm'
                    }
                },
                params: {
                    'mail': null
                }
            })
            .state('enroll.acknowledgment', {
                url: '/acknowledgment',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-acknowledgment.html'
                    }
                },
                params: {
                    'mail': null
                }
            })
            .state('enroll.acknowledgment-other', {
                url: '/acknowledgment',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-acknowledgment-other.html'
                    }
                }
            })
            .state('enroll.email', {
                url: '/email',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-email.html',
                        controller: 'EnrollEmailCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();
(function() {
    ctrl.$inject = ['EnrollService', '$state', '$stateParams'];
    angular
        .module('purple-wind.enroll')
        .controller('EnrollActivationCtrl', ctrl);

    function ctrl(EnrollService, $state, $stateParams) {
        var vm = this;
        vm.mail = $stateParams.mail;
        vm.reset = $stateParams.reset;

        function redirect(route, params) {
            $state.go(route, params);
        }

        function activate(route) {
            if (!vm.reset) {
                EnrollService
                    .activate(vm.mail, vm.code)
                    .then(function() {
                        redirect(route, {
                            'mail': vm.mail,
                            'code': vm.code
                        });
                    }, handleActivationCodeInvalid);
            } else {
                redirect(route, {
                    'mail': vm.mail,
                    'code': vm.code
                });
            }
        }

        function initPassWord() {
            EnrollService.validate(vm.mail);
        }

        function handleActivationCodeInvalid() {
            vm.codeInvalid = true;
            var id = document.getElementById('usercode');
            angular.element(id).addClass('app-input-error');
        }
        vm.activateUser = activate;
        vm.resendCode = initPassWord;
    }
})();
(function() {
    ctrl.$inject = ['EnrollService', 'banksFactory', '$state', '$stateParams', '$modal', '$scope', '$update', '$tag', '$styler', '$startup', '$storage', 'deviceFactory'];
    angular
        .module('purple-wind.enroll')
        .controller('EnrollEmailCtrl', ctrl);

    function ctrl(EnrollService, banksFactory, $state, $stateParams, $modal, $scope, $update, $tag, $styler, $startup, $storage, deviceFactory) {
        var vm = this;
        EnrollService.saveRoute('enroll.email');
        $update.displayUpdateMessage($stateParams.update);

        vm.banksTranslationData = banksFactory.translationData();
        banksFactory.getAllFromServer();

        function go(route) {
            EnrollService
                .check(vm.mail)
                .then(function(mail) {
                    EnrollService
                        .validate(mail)
                        .then(function(res) {
                            EnrollService.saveEmail(vm.mail);
                            if (res.status === 200) {
                                openModal();
                            } else {
                                redirect(route, { 'mail': vm.mail });
                            }
                        }, handleNonExistantEmail);
                }, handleEmailInvalid);
        }

        function logIn() {
            EnrollService
                .authenticate(vm.mail, vm.password)
                .then(function(res) {
                    EnrollService.saveToken(res.data['id_token']);
                    $styler.change();
                    closeModal();
                    $startup.notification($storage.get('oneSignal'));
                    redirect('app.home');
                }, handleCredentialsInvalid);
        }

        $modal.load('modules/login/login.html', $scope, 'slide-in-up')
            .then(function(modal) {
                vm.modal = modal;
            });

        function openModal() {
            if (vm.modal) {
                $tag.sendTagPage('login.html', {});
                vm.modal.show();
            }
        }

        function closeModal() {
            if (vm.modal) {
                vm.modal.hide();
            }
        }

        // Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function() {
            if (vm.modal) {
                vm.modal.remove();
            }
        });

        function redirect(route, params) {
            $state.go(route, params);
        }

        function handleEmailInvalid() {
            vm.emailInvalid = true;
            var id = document.getElementById('useremail');
            angular.element(id).addClass('app-input-error');
        }

        function handleNonExistantEmail(error) {
            if (error.status >= 400) {
                redirect('enroll.subscribe', { mail: vm.mail });
            } else {
                handleEmailInvalid();
            }
        }

        function handleCredentialsInvalid() {
            vm.credentialsInvalid = true;
            var id = document.getElementById('userpwd');
            angular.element(id).addClass('app-input-error');
        }

        function resendPW() {
            EnrollService
                .initPassWord(vm.mail)
                .then(function() {
                    closeModal();
                })
                .then(function() {
                    redirect('enroll.activation', { 'mail': vm.mail, 'reset': true });
                });
        }
        vm.forgottenPassword = resendPW;
        vm.logIn = logIn;
        vm.closeModal = closeModal;
        vm.checkMail = go;
    }
})();
(function() {
    ctrl.$inject = ['EnrollService', '$state', '$stateParams', '$ionicHistory', '$scope', '$startup', 'deviceFactory', '$storage', '$styler'];
    angular
        .module('purple-wind.enroll')
        .controller('EnrollPasswordCtrl', ctrl);

    function ctrl(EnrollService, $state, $stateParams, $ionicHistory, $scope, $startup, deviceFactory, $storage, $styler) {
        var vm = this;
        vm.mail = $stateParams.mail;
        vm.code = $stateParams.code;
        vm.isReset = $stateParams.isReset;
        vm.isPasswordInvalid = false;

        $scope.$on('$ionicView.enter', function() {
            $scope.$apply(function() {
                vm.confirm_pwd = '';
                vm.password = null;
                vm.oldPassword = '';
                vm.isPasswordInvalid = false;
            });

        });

        function redirect(route, params) {
            $state.go(route, params);
        }


        function passwordInvalid() {
            vm.isPasswordInvalid = true;
        }

        function subscribe() {
            EnrollService
                .validatePassword(vm.password)
                .then(function() {
                    vm.isPasswordInvalid = false;
                    if (vm.isReset) {
                        EnrollService
                            .changePassWord({
                                'newPassword': vm.password,
                                'oldPassword': vm.oldPassword
                            }).then(function() {
                                $ionicHistory.goBack();
                            });
                    } else {
                        EnrollService
                            .finishSubscription({
                                'email': vm.mail,
                                'newPassword': vm.password,
                                'key': vm.code.toString()
                            })
                            .then(function() {
                                EnrollService
                                    .authenticate(vm.mail, vm.password)
                                    .then(function(res) {
                                        EnrollService.saveToken(res.data['id_token']);
                                        $styler.change();
                                        $startup.notification($storage.get('oneSignal'));
                                        redirect('app.home');
                                    });
                            });
                    }

                }, passwordInvalid);

        }
        vm.updateColor = function() {

        }
        vm.subscribe = subscribe;
    }
})();
(function() {
    ctrl.$inject = ['EnrollService', '$state', '$stateParams', '$ionicHistory'];
    angular
        .module('purple-wind.enroll')
        .controller('EnrollSubscribeCtrl', ctrl);

    function ctrl(EnrollService, $state, $stateParams, $ionicHistory) {
        var vm = this;
        vm.mail = $stateParams.mail;

        vm.banksTranslationData = EnrollService.translationData();
        vm.banks = EnrollService.getBanksList();

        vm.groups = [{
            items: [],
            show: true
        }];

        vm.toggleGroup = function(group) {
            group.show = !group.show;
        };
        vm.isGroupShown = function(group) {
            return group.show;
        };

        function redirect(route, params) {
            $state.go(route, params);
        }

        vm.precedent = function() {
            $ionicHistory.goBack();
        }

        vm.signUp = function() {
            if (vm.establishment) {
                if (vm.establishment !== 'Other') {
                    EnrollService.signUp(vm.mail, vm.establishment).then(function() {
                        redirect('enroll.acknowledgment');
                    });
                } else {
                    redirect('enroll.acknowledgment-other');
                }
            }
        }

    }
})();
(function() {
    service.$inject = ['$q', '$requester', '$storage', '$security', 'banksFactory', 'lodash'];
    angular
        .module('purple-wind.enroll')
        .service('EnrollService', service);

    function service($q, $requester, $storage, $security, banksFactory, lodash) {
        /**
         * check if an e-mail address is legit or not asynchronously
         * back on regular expression
         * @param {any} email email to check
         * @returns promise
         */
        function validateEmail(email) {
            var dfd = $q.defer(),
                re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (re.test(email)) {
                dfd.resolve(email);
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }

        function validatePassword(password) {
            var dfd = $q.defer();
            var _regex = /[$-/:-?{-~!"^_`\[\]]/g;
            var _lowerLetters = /[a-z]+/.test(password);
            var _upperLetters = /[A-Z]+/.test(password);
            var _numbers = /[0-9]+/.test(password);
            var _symbols = _regex.test(password);
            var pLength = password.length >= 4;
            if (pLength) {
                dfd.resolve(password);
            } else {
                dfd.reject();
            }

            return dfd.promise;
        }

        /**
         * call the validation api on server to check if user exists:
         * - user exists and activated
         * - user exists but not activated
         * - user does not exist
         * @param {any} email email to check
         * @returns promise to handle. PS: status codes from 4xx and above should be handled as a reject.
         */
        function validateOnServer(email) {
            var dfd = $q.defer();
            $requester
                .api('validate_user', email)
                .then(function(res) {
                    if (res.status < 400) {
                        $storage.set('reseau', res.data);
                        dfd.resolve(res);
                    } else {
                        dfd.reject(res);
                    }
                }, function(err) {
                    dfd.reject(err);
                });
            return dfd.promise;
        }
        /**
         * saves the user email address on localStorage
         * @param {any} email email to store
         * @returns promise
         */
        function saveEmail(email) {
            var dfd = $q.defer();
            if ($storage.set('email', email)) {
                dfd.resolve();
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }
        /**
         * activate an user with a key that is sent
         * to user by e-mail
         * @param {string} email email address
         * @param {string} key activation key 
         * @returns promise
         */
        function activateUser(email, key) {
            var dfd = $q.defer();
            $requester
                .api('activate_user', {
                    'email': email,
                    'key': key
                })
                .then(function(success) {
                        if (success.status < 500) {
                            dfd.resolve(success.data);
                        } else {
                            dfd.reject(success.data);
                        }
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }
        /**
         * authenticate an user using credentials
         * @param {string} login user login
         * @param {string} pwd user password
         * @returns promise to handle
         */
        function authenticate(login, pwd) {
            return $security.authenticateUser(login, pwd);
        }



        function signUp(email, banque) {
            var dfd = $q.defer();
            $requester
                .api('inscription', {
                    'email': email,
                    'banque': banque
                })
                .then(function(success) {
                        dfd.resolve(success);
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }

        /**
         * finalize the subscription process by sending
         * informations about the new user
         * @param {object} data object that has : email {string},newPassword {string}, key {key} 
         * @returns promise to handle
         */
        function finishPassWord(data) {
            var dfd = $q.defer();
            $requester
                .api('finish_password', data)
                .then(function(success) {
                        dfd.resolve(success);
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }

        /**
         * Modifie the user password
         * @param {object} data object that has : oldPassword {string},newPassword {string}
         * @returns promise to handle
         */
        function changePassWord(data) {
            var dfd = $q.defer();
            $requester
                .api('change_password', data)
                .then(function(success) {
                        dfd.resolve(success);
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }

        /**
         * initialize the password retrieval process in the backoffice
         * @param {string} email user email
         * @returns promise to handle
         */
        function initPassWord(email) {
            var dfd = $q.defer();
            $requester
                .api('init_password', {
                    'mail': email
                })
                .then(function(success) {
                        dfd.resolve(success);
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }

        /**
         * saves the user token on localStorage
         * @param {string} token token to store
         * @returns promise
         */
        function saveToken(token) {
            var dfd = $q.defer();
            if ($storage.set('tokenID', token)) {
                dfd.resolve();
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }

        /**
         * saves the latest route to be used as a startup route
         * @param {string} route 
         * @returns promise
         */
        function saveRoute(route) {
            var dfd = $q.defer();
            if ($storage.set('landing_state', route)) {
                dfd.resolve();
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }

        function getBanksList() {
            return banksFactory.getAllFromFactory();
        }

        function translationData() {
            return banksFactory.translationData();
        }

        return {
            'activate': activateUser,
            'check': validateEmail,
            'validatePassword': validatePassword,
            'validate': validateOnServer,
            'saveEmail': saveEmail,
            'authenticate': authenticate,
            'finishSubscription': finishPassWord,
            'initPassWord': initPassWord,
            'saveToken': saveToken,
            'changePassWord': changePassWord,
            'saveRoute': saveRoute,
            'signUp': signUp,
            'getBanksList': getBanksList,
            'translationData': translationData
        }
    }
})();
(function() {
    angular
        .module('purple-wind.cgu', []);
})();
(function() {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.cgu')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('cgu', {
                url: '/cgu',
                templateUrl: 'modules/cgu/cgu.html',
                controller: 'CguCtrl',
                controllerAs: 'cgu'
            })
            .state('app.cgu', {
                url: '/cgu',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/cgu/cgu-account.html',
                        controller: 'CguCtrl',
                        controllerAs: 'cgu'
                    }
                }
            });
    }
})();
(function() {
    ctrl.$inject = ['$state', 'CguService'];
    angular
        .module('purple-wind.cgu')
        .controller('CguCtrl', ctrl);

    function ctrl($state, CguService) {
        var cgu = this;

        function enroll() {
            CguService.accepted();
        }

        cgu.enroll = enroll;
    }
})();
(function() {
    svc.$inject = ['$q', '$requester', '$storage', 'config'];
    angular
        .module('purple-wind.cgu')
        .service('CguService', svc);

    function svc($q, $requester, $storage, config) {
        function cgu() {
            return config.fake.cgu;
        }

        function optin() {
            return config.fake.cgu;
        }

        function accept() {
            return $storage.set('cguAccepted', true);
        }
        return {
            loadCGU: cgu,
            loadOptin: optin,
            accepted: accept
        };
    }
})();
(function() {
    angular
        .module('purple-wind.optin', []);
})();
(function() {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.optin')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('optin', {
                url: '/optin',
                templateUrl: 'modules/optin/optin.html',
                controller: 'OptinCtrl',
                controllerAs: 'optin'
            });
    }
})();
(function() {
    ctrl.$inject = ['$state', 'OptinService'];
    angular
        .module('purple-wind.optin')
        .controller('OptinCtrl', ctrl);

    function ctrl($state, OptinService) {
        var vm = this;

        function goToCGUs() {
            OptinService
                .accepted()
                .then(function() {
                    $state.go('cgu');
                });
        }
        vm.goToCGUs = goToCGUs;
    }
})();
(function() {
    svc.$inject = ['$q', '$requester', '$storage'];
    angular
        .module('purple-wind.optin')
        .service('OptinService', svc);

    function svc($q, $requester, $storage) {

        function accept() {
            var dfd = $q.defer();
            var res = $storage.set('optinAccepted', true);
            if (res) {
                dfd.resolve();
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }
        return {
            accepted: accept
        };
    }
})();
(function() {
    angular
        .module('purple-wind.entities', []);
})();
(function() {
    offersFactory.$inject = ['$requester', '$q', '$storage', 'lodash', 'urls', 'config'];
    angular
        .module('purple-wind.entities')
        .factory('offers', offersFactory);

    function offersFactory($requester, $q, $storage, lodash, urls, config) {
        /**
         * gets the full set of offers, process it in order to return only the sale location that have offers
         * Important: if the data is not reachable from servers, the data is retrieved from cache 
         * @returns a promise that contains processed data
         */
        function getAll() {
            var deferred = $q.defer();
            var address = $storage.get('email');
            if (inCache()){
                deferred.resolve(loadDataFromCache());
                return deferred.promise;
            } else {
                return $requester
                        .api('offers', { 'email': address })
                        .then(processData, loadDataFromCache);
            }
        }
        /**
         * get an offer from cache
         * P.S: As discussed, no need to call WS to get offer detail for now
         * @param {number} id Id of the target offer
         * @returns target offer 
         */
        function get(id) {
            var offer = lodash.find($storage.get('offers'), function(offer) {
                return offer.id === lodash.toNumber(id);
            });
            return offer;
        }


        function processData(result) {
            var data = lodash.forEach(result.data, transform);
            return data;
        }

        function transform(obj) {
            obj = transformCategories(obj);
            obj = transformImagesUrls(obj);
            return obj;
        }

        function transformCategories(obj) {
            obj.categories = [];
            lodash.forEach(obj.annonceur.categories, function(category) {
                obj.categories.push({
                    'name': category,
                    'icon': iconize(category)
                });
            });
            return obj;
        }

        function iconize(category) {
            return 'app-' + category.toString().toLowerCase().replace(/[\u0300-\u036f]/g, '');
        }
        /**
         * loads offers data from cache
         * @returns Array of sale locations stored previously
         */
        function loadDataFromCache() {
            var cache = $storage.get('offers');
            return lodash.toArray(cache);
        }
        /**
         * save the offers in cache
         * @param {object} response server response 
         * @returns offers collection
         */
        function saveDataInCache(data) {
            var dateCourante = new Date();
            $storage.set('offers', data);
            $storage.set('date_offers',dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
            return data;
        }

        /**
         * Offers is in cache and up to date ?
         * @returns {boolean}
        */
        function inCache(){
            var dateCourante = new Date();
            var dateStorage = $storage.get('date_offers');
            return (dateStorage !== null) && (dateStorage === dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
        }

      /**
       * Update the consult information of an offer from cache
       * @param id
       */
        function consultOfferInCache(id){
            var offersCollection = $storage.get('offers');
            lodash.forEach(offersCollection, function(item) {
                if (item.id === lodash.toNumber(id)) {
                    item.consulte = true;
                }
            });
            $storage.set('offers', offersCollection);
        }

        /**
         * transforms offer and add 3 new attributes:
         * annonceur.image_advertiser
         * annonceur.image_logo_small
         * annonceur.image_logo_big
         * @param {object} obj offer to transform
         * @returns transformed object
         */
        function transformImagesUrls(obj) {
            var ia = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_advertiser']) + obj.annonceur.photo;
            obj = lodash.set(obj, 'annonceur.image_advertiser', ia);
            var ils = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_logo_small']) + obj.annonceur.logoAnnonceur;
            obj = lodash.set(obj, 'annonceur.image_logo_small', ils);
            var ilb = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_logo_big']) + obj.annonceur.logoAnnonceur;
            obj = lodash.set(obj, 'annonceur.image_logo_big', ilb);
            return obj;
        }

        function consult(id) {
            var address = $storage.get('email');
            return $requester.api('offer_consult', { 'email': address, 'idOffre': id });
        }

        return {
            'getAll': getAll,
            'get': get,
            'consult': consult,
            'consultOfferInCache': consultOfferInCache,
            'save': saveDataInCache
        };
    }
})();
(function() {
    salelocationsFactory.$inject = ['$requester', '$q', '$storage', 'lodash', 'urls', 'config'];
    angular
        .module('purple-wind.entities')
        .factory('saleLocations', salelocationsFactory);

    function salelocationsFactory($requester, $q, $storage, lodash, urls, config) {
        function getAll() {
            var deferred = $q.defer();
            if (inCache()){
                deferred.resolve(loadDataFromCache());
                return deferred.promise;
            } else {
                return $requester
                .api('sale_locations')
                .then(filterEmptySaleLocations, loadDataFromCache)
                .then(processData);
            }
        }

        /**
         * loads sale locations data from cache
         * @returns Array of sale locations stored previously
         */
        function loadDataFromCache() {
            var cache = $storage.get('sale_locations');
            return lodash.toArray(cache);
        }

        function saveDataInCache(data) {
            var dateCourante = new Date();
            $storage.set('sale_locations', data);
            $storage.set('date_sale_locations',dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
            return data;
        }

        /**
         * Sale is in cache and up to date ?
         * @returns {boolean}
         */
        function inCache(){
            var dateCourante = new Date();
            var dateStorage = $storage.get('date_sale_locations');
            return (dateStorage !== null) && (dateStorage === dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
        }

        function filterEmptySaleLocations(result) {
            return lodash.filter(result.data, function(saleLocation) {
                return (saleLocation.offres && saleLocation.offres.length > 0);
            });
        }

        function processData(result) {
            var data = lodash.forEach(result, transform);
            return data;
        }

        function transform(obj) {
            obj = transformImagesUrls(obj);
            obj = transformCoordinates(obj);
            return obj;
        }
        /**
         * transforms offer and add 3 new attributes:
         * annonceur.image_advertiser
         * annonceur.image_logo_small
         * annonceur.image_logo_big
         * @param {any} obj 
         * @returns 
         */
        function transformImagesUrls(obj) {
            var ia = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_advertiser']) + obj.annonceur.photo;
            obj = lodash.set(obj, 'annonceur.image_advertiser', ia);
            var ils = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_logo_small']) + obj.annonceur.logoAnnonceur;
            obj = lodash.set(obj, 'annonceur.image_logo_small', ils);
            var ilb = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_logo_big']) + obj.annonceur.logoAnnonceur;
            obj = lodash.set(obj, 'annonceur.image_logo_big', ilb);
            return obj;
        }

        function transformCoordinates(obj) {
            obj = lodash.set(obj, 'lat', lodash.toNumber(obj.latitude || obj.lat));
            lodash.unset(obj, 'latitude');
            obj = lodash.set(obj, 'lng', lodash.toNumber(obj.longitude || obj.lng));
            lodash.unset(obj, 'longitude');
            return obj;
        }
        return {
            'getAll': getAll,
            'save': saveDataInCache
        };
    }
})();
(function() {
    angular
        .module('purple-wind.entities')
        .factory('user', userFactory);

    function userFactory() {
        function create() {
            return {
                'email': ''
            };
        }
        return {
            'new': create
        };
    }
})();
(function() {
    banksFactory.$inject = ['$requester', '$q', '$storage', '$filter', 'lodash'];
    angular
        .module('purple-wind.entities')
        .factory('banksFactory', banksFactory);

    function banksFactory($requester, $q, $storage, $filter, lodash) {
        var banks = [];
        var banksTranslationData = '';

        /**
         * Get the full set of banks from the server
         * Important: if the data is not reachable from servers, the data is retrieved from cache
         * @returns a promise that contains processed data
         */
        function getAllFromServer() {
            function processData(result) {
                function addBank(obj) {
                    return banks.push({ name: obj.nom, fullName: obj.nomComplet });
                }

                banks = [];
                lodash.forEach(result.data, addBank);
                $storage.set('banks', banks);
                return banks;
            }

            return $requester
                .api('banks')
                .then(processData, loadDataFromCache);
        }

        /**
         * loads banks data from cache
         * @returns Array of sale locations stored previously
         */
        function loadDataFromCache() {
            var cache = $storage.get('banks');
            return lodash.toArray(cache);
        }

        /**
         * Get the full set of banks from the memory
         * Important: if the data is not reachable from servers, the data is retrieved from a var ou from the cache
         * @returns an array of banks
         */
        function getAllFromFactory() {
            if (banks.length === 0) { loadDataFromCache(); }
            return banks;
        }


        /**
         * Get the full set of banks from the memory
         * Important: if the data is not reachable from servers, the data is retrieved from a var ou from the cache
         * @returns an string with all banks
         */
        function translationData() {
            if (banksTranslationData.length === 0) {
                lodash.forEach(banks, addBankTranslationData);
            }

            return { banks: banksTranslationData };
        }

        function addBankTranslationData(bank, key) {
            banksTranslationData += 'de ' + bank.fullName + ((key === banks.length - 2) ? ' ' + $filter('translate')('OR') + ' ' : ((key < banks.length - 2) ? ', ' : ''));
        }

        return {
            'getAllFromServer': getAllFromServer,
            'getAllFromFactory': getAllFromFactory,
            'translationData': translationData
        };
    }
})();
(function() {
    deviceFactory.$inject = ['$requester'];
    angular
        .module('purple-wind.entities')
        .factory('deviceFactory', deviceFactory);

    function deviceFactory($requester) {
        function uploadOneSignalData(data) {
            $requester.api('devices', data);
        }

        return {
            'uploadOneSignalData': uploadOneSignalData
        };
    }
})();
(function() {
    categoriesFactory.$inject = ['$requester', '$q', '$storage', '$filter', 'lodash'];
    angular
        .module('purple-wind.entities')
        .factory('categoriesFactory', categoriesFactory);

    function categoriesFactory($requester, $q, $storage, $filter, lodash) {
        var categories;

        function getAllFromServer() {
            var deferred = $q.defer();
            if (inCache()){
                deferred.resolve(loadDataFromCache());
                return deferred.promise;
            } else {
                return $requester
                .api('categories')
                .then(processData, loadDataFromCache);
            }
        }

        function processData(result) {
            var dateCourante = new Date();
            categories = [];
            lodash.forEach(result.data, processCategories);
            $storage.set('categories', categories);
            $storage.set('date_categories',dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
            return categories;
        }

        function processCategories(item) {
            item.image = 'app-' + item.nom.toString().toLowerCase().replace(/[\u0300-\u036f]/g, '');
            categories.push(item);
        }

        /**
         * loads categories data from cache
         * @returns Array of categories stored previously
         */
        function loadDataFromCache() {
            var cache = $storage.get('categories');
            return lodash.toArray(cache);
        }

        /**
         * Categories is in cache and up to date ?
         * @returns {boolean}
         */
        function inCache(){
            var dateCourante = new Date();
            var dateStorage = $storage.get('date_categories');
            return (dateStorage !== null) && (dateStorage === dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
        }

        /**
         * Get the full set of categories from the memory
         * Important: if the data is not reachable from servers, the data is retrieved from a var ou from the cache
         * @returns an array of categories
         */
        function getAllFromFactory() {
            if (categories.length === 0) { loadDataFromCache(); }
            return categories;
        }


        return {
            'getAllFromServer': getAllFromServer,
            'getAllFromFactory': getAllFromFactory,
            'processCategories': processCategories
        };
    }
})();
(function() {
    angular
        .module('purple-wind.tabs', []);
})();
(function() {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app', {
                url: '/app',
                abstract: true,
                templateUrl: function() {
                    return 'modules/root/root.html';
                }
            });
    }
})();
(function() {
    routes.$inject = ['$stateProvider', '$logProvider'];
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider, $logProvider) {
        // Desactivation des logs de Leaflet
        // TODO: retirer le commentaire de la ligne précédente
        // (Ligne à priori initile depuis qu'on n'utilise plus la directive Leaflet !!!)
        // $logProvider.debugEnabled(false);

        $stateProvider
            .state('app.home', {
                url: '/home',
                views: {
                    'tab-offers': {
                        templateUrl: 'modules/home/home.html',
                        controller: 'HomeCtrl',
                        controllerAs: 'home'
                    }
                },
                params: {
                    update: null
                }
            });
    }
})();
(function() {
    ctrl.$inject = ['$scope', 'HomeService', '$state', '$stateParams', '$storage', '$update', '$timeout', 'lodash', '$ionicScrollDelegate', '$map', '$rootScope'];
    angular
        .module('purple-wind.tabs')
        .controller('HomeCtrl', ctrl);

    function ctrl($scope, HomeService, $state, $stateParams, $storage, $update, $timeout, lodash, $ionicScrollDelegate, $map, $rootScope) {
        var home = this;
        home.toggleMap = false;
        home.pull = false;
        home.backup = {};

        home.sortItems = [ {id : 1 , nom : 'Plus proche' , icon : 'icon-apps-proche' , disabled : true} , 
                            {id : 2 , nom : 'Bientôt expiré' , icon : 'icon-apps-expire', disabled : false} ,
                            {id : 3 , nom : 'Plus récent' , icon : 'icon-apps-recent', disabled : false} , 
                            {id : 4, nom : 'Plus avantageux' , icon : 'icon-apps-coin-euro', disabled : false} ];
        home.selectedSortId=0;


        home.isDrowerSort = false ;

        if (window.cordova) HomeService.processNotificationData();

        $update.displayUpdateMessage($stateParams.update);
        $storage.set('landing_state', 'app.home');

        var helper_list_understood = $storage.get('helper_list_understood') || false,
            helper_map_understood = $storage.get('helper_map_understood') || false;

        home.map = HomeService.loadMap();

        HomeService
            .loadOffers()
            .then(function(data) {
                
                home.map.markers = HomeService.buildMarkers(data.saleLocations);
                home.backup.markers = home.map.markers;

                home.appSettings = $storage.get('settings');
                if(home.appSettings.geolocation){
                    HomeService.calculateDistance(data);
                    $scope.$broadcast('resortEvent',{ id : 1 } );
                }

                home.offers = data.offers;
                home.backup.offers = home.offers;
                home.data = data ;
            });

            function calculateDistance(){

                if(home.data){
                    HomeService.calculateDistance(home.data);
                    home.offers = home.data.offers;
                    home.backup.offers = home.offers;
                    if( home.selectedSortId < 2){
                         $scope.$broadcast('resortEvent',{ id : 1 } );
                    }
                }       
                $timeout(recalculateCurrentPosition,5000);
            }

            function recalculateCurrentPosition(){
                $timeout(recalculateCurrentPosition,5000);

                $map.pinpoint().then(function(position){
                    
                    var inMemoryPosition = $storage.get('lastcalculatedPosition');
                    if(inMemoryPosition && inMemoryPosition.coords){
                        var coords = {lat: position.coords.latitude,
                            lon: position.coords.longitude
                              };
                        var coords2 = {lat: inMemoryPosition.coords.latitude,
                                lon: inMemoryPosition.coords.longitude
                                  };
                       var distance = $map.calculate(coords , coords2);
                       if(distance > 0.01){
                         $scope.$broadcast('recalculateCurrentPosition', {position : position});
                       }

                       if(distance > 0.1 ){

                        $storage.set('lastcalculatedPosition', position);
                       
                       
                        HomeService.recalculateDistance(home.data, position);
                       

                        home.offers = home.data.offers;
                        home.backup.offers = home.offers;
                       
                       }
                    }else {
                        $storage.set('lastcalculatedPosition', position);     
                    } 
                });
                
            }

        ionic.on('calculateDistanceinit', calculateDistance);   
    
        $timeout(recalculateCurrentPosition,5000);

        HomeService.getCategories().then(function(data) {
            home.categories = data;
        });

        function toggleView() {
            home.toggleMap = !home.toggleMap;
            if (!home.toggleMap && !helper_list_understood) {
                $timeout(openHelperList, 1000);
            }
            HomeService.tagPage(true);
        }

        function switchIcon() {
            return home.toggleMap ? 'icon-apps-listes' : 'icon-apps-cartes';
        }


        function openHelperList() {
            HomeService
                .openHelperList()
                .then(function() {
                    helper_list_understood = true;
                    $storage.set('helper_list_understood', helper_list_understood);
                });
        }

        function openHelperMap() {
            HomeService
                .openHelperMap()
                .then(function() {
                    helper_map_understood = true;
                    $storage.set('helper_map_understood', helper_map_understood);
                });
        }

        function getCategories(data) {
            var _selection = processCategories(data);
            filterOffers(_selection);
            filterMarkers(_selection);
            home.filterOn = true;
        }

        function setSort(data) {  
           home.selectedSortId=data[0].id;
           $scope.$broadcast('resortEvent',{ id : data[0].id } );
        }

        function removeSort(data) {
            $scope.$broadcast('resortEvent',{ id : 0 } );
        }


        function processCategories(data) {
            var _res = [];
            lodash.forEach(data, function(item) {
                _res.push(item.nom);
            });
            return _res;
        }

        function removeCategories(data) {
            var _selection = processCategories(data);
            if (data.length === 0) {
                home.map.markers = home.backup.markers;
                home.offers = home.backup.offers;
                home.filterOn = false;
            } else {
                filterOffers(_selection);
                filterMarkers(_selection);
            }
        }

        function filterMarkers(categories) {
            home.map.markers = lodash.filter(home.backup.markers, function(marker) {
                return lodash.difference(marker.categories, categories).length !== marker.categories.length;
            });
        }

        function filterOffers(categories) {
            home.offers = lodash.filter(home.backup.offers, function(offer) {
                return lodash.difference(offer.annonceur.categories, categories).length !== offer.annonceur.categories.length;
            });
        }

        ionic.on('popUpOnpened', function() {
            if (!helper_map_understood) {
                $timeout(openHelperMap, 1000);
            }
        });

        home.onTouch = function() {
            if (home.pull) {
                home.pull = false;
            }
        };

        home.toggleDrawer = function(current) {
            $timeout(function ()  {
                toggleDrawerExe(current)
            }, 1);
            
        };

        function toggleDrawerExe(current){
           
            if(home.isDrowerSort === current){
                home.pull = !home.pull;
            } else  {
                home.pull = true ;
            }
            home.isDrowerSort = current;
            if (home.pull) $ionicScrollDelegate.scrollTop(true);
        };

        /*
        $scope.$on('$ionicView.beforeEnter', function() {
            if (home.offers) {
                home.offers = $storage.get('offers');
                home.backup.offers = home.offers;
            }
        });
        */

        home.switchIcon = switchIcon;
        home.toggleView = toggleView;
        home.getCategories = getCategories;
        home.setSort=setSort;
        home.removeSort=removeSort;
        home.removeCategories = removeCategories;
    }
})();
(function () {
    svc.$inject = ['$q', '$filter', '$permissions', '$map', 'categoriesFactory', 'deviceFactory', 'saleLocations', 'offers', 'lodash', 'config', 'geolocation', '$storage', '$translate', '$tag', '$popup'];
    angular
        .module('purple-wind.tabs')
        .service('HomeService', svc);

    function svc($q, $filter, $permissions, $map, categoriesFactory, deviceFactory, saleLocations, offers, lodash, config, geolocation, $storage, $translate, $tag, $popup) {
        var toggleMap = true;

        /**
         * load map configuration
         * @returns object
         */
        function loadMap() {
            var _cfg = $map.load();
            _cfg.network = $storage.get('reseau').toString().toLowerCase();
            return _cfg;
        }

        /**
         * loads all the sale locations and offers
         * @returns promise
         */
        function loadOffers() {
            return $q.all([
                saleLocations.getAll(),
                offers.getAll()
            ]).then(calculeSaleLocationsForOffres)
                .then(processData)
                .then(processDisplayData)
                .then(saveDataInCache);

        }

        function loadCategories() {
            return categoriesFactory.getAllFromServer();
        }

        function saveDataInCache(data) {
            saleLocations.save(data.saleLocations);
            offers.save(data.offers);
            return data;
        }

        /**
         * calculate the number of participating sale points
         * @param {number} offerId target offer
         * @returns total of participating sale points for the target offer
         */
        function getSaleLocationsCount(offerId, list) {
            var saleLocations = list;
            var res = [];
            lodash.forEach(saleLocations, function (location) {
                lodash.find(location.offres, function (id) {
                    if (id === lodash.toNumber(offerId)) {
                        res.push(location);
                    }
                });
            });
            return res.length;
        }

        function calculeSaleLocationsForOffres(data) {
            var offers = [];
            lodash.forEach(data[1], function (offer) {
                offer.saleLocationsCount = getSaleLocationsCount(offer.id, data[0]);
                offers.push(offer);
            });

            data[1] = offers;
            return data;
        }

        function processData(arr) {
            return {
                'saleLocations': distinctObjects(arr[0]),
                'offers': arr[1]
            };
        }

        function distinctObjects(objects){
            var distinctObj = [];
            var distinctids = [];

            for(var i = 0 ; i < objects.length ; i++){
                if(distinctids.indexOf(objects[i].id) < 0 ){
                    distinctObj.push(objects[i]);
                    distinctids.push(objects[i].id);

                }
            }
            return distinctObj;
         }

        function processDisplayData(data) {
            var offer;
            lodash.forEach(data.saleLocations, function (location) {
                offer = getOfferFrom(data.offers, location.offres[0]);
                if (offer) {
                    location.categories = offer.annonceur.categories;
                    location.multiple = offer.multiple;
                    if (offer.multiple) {
                        location.cashBack = (offer.maxCashBackPourcentage > 0) ? offer.maxCashBackPourcentage : offer.maxCashBackFixe;
                        location.cashBackSymbol = (offer.maxCashBackPourcentage > 0) ? '%' : '€';
                    } else {
                        location.cashBack = (offer.cashBackPourcentage > 0) ? offer.cashBackPourcentage : offer.cashBackFixe;
                        location.cashBackSymbol = (offer.cashBackPourcentage > 0) ? '%' : '€';
                    }

                    location.cashBackOfferID = offer.id;
                }
            });
            return data;
        }

        function getOfferFrom(collection, id) {
            return lodash.find(collection, function (item) {
                return item.id === id;
            })
        }

        function centerMap(position, zoom) {
            var dfd = $q.defer();
            if (position.latitude && position.longitude) {
                dfd.resolve({
                    lat: position.latitude,
                    lng: position.longitude,
                    zoom: zoom
                });
            } else {
                dfd.reject('No position');
            }
            return dfd.promise;
        }

        function buildMarker(annonceur, icon, translations) {
            var marker = {
                lat: annonceur.lat,
                lng: annonceur.lng,
                icon: icon,
                categories: annonceur.categories
            };
            if (translations) {
                marker.group = annonceur.codePostal.substr(0, 2);
                marker.message = buildPopUp(annonceur, translations);
                marker.popupOptions = { closeButton: false }
            }
            return marker;
        }

        function buildMarkers(saleLocations, volatile) {
            var _markers = [],
                _translate = {
                    'MAP_POPUP_OPENING': $translate.instant('MAP_POPUP_OPENING'),
                    'MAP_POPUP_LINK': $translate.instant('MAP_POPUP_LINK'),
                    'OFFER_DETAIL_CASHBACK': $translate.instant('OFFER_DETAIL_CASHBACK')
                };
            lodash.forEach(saleLocations, function (location) {
                _markers.push(buildMarker(location, geolocation.icons.default, _translate));
            });
            if (!volatile) {
                $storage.set('markers', _markers);
            }
            return _markers;
        }

        function buildCategory(annonceur) {
            var _res = '<div class="row">';
            lodash.forEach(annonceur.categories, function (category) {
                var _icon = 'app-' + category.toString().toLowerCase().replace(/[\u0300-\u036f]/g, '');
                _res += '<i class="icon ' + _icon + ' icon-category"></i><p class="icon-category">' + category + '</p>';
            });
            _res += '</div>'
            return _res;
        }

        function buildPopUp(annonceur, translations) {
            return '<div class="row no-padding"><div class="col"><div class="offer-popup-title">' + annonceur.annonceur.nom + '</div>' +
               '</div><div class="col popup-eye-container offer-visualized"><i class="icon app-vu popup-eye offer-visualized"><class="icon app-vu offer-status offer-visualized"></i></div></div>' +
                '<div class="col no-padding">' +
                buildCategory(annonceur) +
                '<div class="row"><i class="icon app-boutique icon-text"></i><p class="icon-text">' + annonceur.adresse1 + '</p></div>' +
                '<div class="row next-row"><p class="icon-text">' + annonceur.codePostal + ' ' + $filter('capitalize')(annonceur.ville, true) + '</p></div>' +
                (lodash.isNull(annonceur.horaires) ? '' : '<div class="row next-row"><p class="icon-text">' + translations.MAP_POPUP_OPENING + ': ' + annonceur.horaires.toLowerCase() + '</p></div>') +
                '<div class="row"><div class="col col-60 no-padding"><a class="button button-icon button-clear ion-arrow-right-b offer-popup-link" href="#/app/map/' + annonceur.cashBackOfferID + '">' + translations.MAP_POPUP_LINK + '</a></div>' +
                '<div class="col col-33 no-padding offer-popup-cashback">'+(annonceur.multiple ? '<div class="ng-binding" style="font-size: small">jusqu\'à</div>' : '') + $filter('cashback')(annonceur.cashBack, true) + annonceur.cashBackSymbol + '</div></div><div class="no-padding offer-popup-cashback-text">' + translations.OFFER_DETAIL_CASHBACK + '</div></div>';
        }

        function offerConsulted(id) {
            return offers.consult(id);
        }

        function saveOfferId(id) {
            var offersToSync = $storage.get('offersToSync') || [];
            offersToSync.push(id);
            $storage.set('offersToSync', lodash.uniq(offersToSync));
        }

        function tagPage(toggleToggle) {
            if (toggleToggle) { toggleMap = !toggleMap; }
            if (toggleMap) {
                $tag.sendTagPage('app.offers.map', {});
            } else {
                $tag.sendTagPage('app.offers.list', {});
            }
        }

        function getLocations(offerId) {
            var _saleLocations = $storage.get('sale_locations'),
                _res = [];
            lodash.forEach(_saleLocations, function (location) {
                if (lodash.indexOf(location.offres, offerId) >= 0) {
                    _res.push(location);
                }
            });
            return buildMarkers(_res, true);
        }

        function openHelperList() {
            return $popup.showBasicAlertDialog({
                'templateUrl': 'modules/helper/helper-list.html',
                'okText': $translate.instant('UNDERSTOOD_BTN')
            });
        }

        function openHelperMap() {
            return $popup.showBasicAlertDialog({
                'templateUrl': 'modules/helper/helper-map.html',
                'okText': $translate.instant('UNDERSTOOD_BTN')
            });
        }

        function processCategories(list) {
            return categoriesFactory.processCategories(list);
        }

        function getLocationList(offerId , saleLocations){
            _res = [];
             lodash.forEach(saleLocations, function(location) {
                if (lodash.indexOf(location.offres, offerId) >= 0) {
                    _res.push(location);
                }
            });
          return _res;
        }
 
         function getMinDistance(saleLocations){
            var minDistance ;
            if(saleLocations.length > 0){
              minDistance = saleLocations[0].distance ;
             lodash.forEach(saleLocations, function (location){
                 if(location.distance < minDistance){
                     minDistance = location.distance;
                 }
                 
             });
            }
             return minDistance;
         }
 
        function calculateDistance(data){
 
             $map.pinpoint().then(function (location) {
 
                var coords = {lat: location.coords.latitude,
                              lon: location.coords.longitude
                                };
 
                lodash.forEach(data.saleLocations, function(location) {
                    location.distance = $map.calculate(coords, { lat: location.lat , lon : location.lng});
               });
 
                 lodash.forEach(data.offers, function(offer) {
                   var result = getLocationList(offer.id , data.saleLocations);
                   offer.minDistance = getMinDistance(result);
                });
 
                           
 
             });
        }

        function recalculateDistance(data, location){

                var coords = {lat: location.coords.latitude,
                                lon: location.coords.longitude
                                };

                lodash.forEach(data.saleLocations, function(location) {
                    if(location.distance < 10){
                       location.distance = $map.calculate(coords, { lat: location.lat , lon : location.lng});
                    }
                });

                lodash.forEach(data.offers, function(offer) {
                    var result = getLocationList(offer.id , data.saleLocations);
                    offer.minDistance = getMinDistance(result);
                });
            
                                      
            
         }

        function processNotificationData() {
            // debugger;
            var _oneSignalUserID = $storage.get('OneSignalUserID'),
                _oneSignalPushToken = $storage.get('OneSignalPushToken'),
                _device = $storage.get('device');
            deviceFactory.uploadOneSignalData({
                'userUid': _oneSignalUserID,
                'notificationUid': _oneSignalPushToken,
                'marque': _device.manufacturer,
                'model': _device.model
            });
        }

        return {
            'loadMap': loadMap,
            'loadOffers': loadOffers,
            'centerMap': centerMap,
            'buildMarker': buildMarker,
            'buildMarkers': buildMarkers,
            'offerConsulted': offerConsulted,
            'saveOfferId': saveOfferId,
            'tagPage': tagPage,
            'getLocations': getLocations,
            'openHelperList': openHelperList,
            'openHelperMap': openHelperMap,
            'getCategories': loadCategories,
            'processCategories': processCategories,
            'processNotificationData': processNotificationData,
            'calculateDistance':calculateDistance,
            'recalculateDistance':recalculateDistance

        };
    }
})();
(function() {
    route.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(route);

    function route($stateProvider) {
        $stateProvider
            .state('app.offer-list', {
                url: '/list/:offerId',
                views: {
                    'tab-offers': {
                        templateUrl: 'modules/offer/offer.html',
                        controller: 'OfferCtrl',
                        controllerAs: 'vm'
                    }
                }
            })
            .state('app.offer-map', {
                url: '/map/:offerId',
                views: {
                    'tab-offers': {
                        templateUrl: 'modules/offer/offer.html',
                        controller: 'OfferCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();
(function () {
    ctrl.$inject = ['$state', '$stateParams', 'offers', 'HomeService'];
    angular
        .module('purple-wind.tabs')
        .controller('OfferCtrl', ctrl);

    function ctrl($state, $stateParams, offers, HomeService) {
        var vm = this;
        vm.offer = offers.get($stateParams.offerId);
        vm.shownItem = false;

        if (vm.offer.multiple) { 
            for(var i=0 ; i<vm.offer.ids.length ; i++ ){
                HomeService
                .offerConsulted(vm.offer.ids[i])
                .catch(function () {
                    HomeService.saveOfferId(vm.offer.ids[i]);
                });
            }
        } else {
            HomeService
                .offerConsulted($stateParams.offerId)
                .catch(function () {
                    HomeService.saveOfferId($stateParams.offerId);
                });
        }

        var locations = HomeService.getLocations(Number.parseInt($stateParams.offerId));

        vm.showLocations = function () {
            var _nextState = 'app.locations';
            $state.go(_nextState, {
                'locations': locations,
                'vendor': vm.offer.annonceur.nom
            });
        };

        vm.openExternal= function(lien){
            cordova.InAppBrowser.open(lien,'_system');
            return false;

        };

        vm.toggleItem = function () {
            vm.shownItem = !vm.shownItem;
        };

    }
})();
(function() {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.favorite', {
                url: '/favorite',
                views: {
                    'tab-favorites': {
                        templateUrl: 'modules/favorite/favorite.html',
                        controller: 'listCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();
(function() {
    ctrl.$inject = ['$scope', '$permissions', 'config'];
    angular
        .module('purple-wind.tabs')
        .controller('FavoriteCtrl', ctrl);

    function ctrl($scope, $permissions, config) {

        function doWhenPermissionGranted(status) {
            console.log('Granted' + status);
        }

        function doWhenPermissionDenied(status) {
            console.error('denied' + status);
        }

        $permissions.request([
                config.permissions.READ_SMS
            ],
            doWhenPermissionGranted,
            doWhenPermissionDenied
        );

    }
})();
(function() {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.cashback', {
                url: '/cashback',
                views: {
                    'tab-cashback': {
                        templateUrl: 'modules/cashback/cashback.html',
                        controller: 'CashBackCtrl',
                        controllerAs: 'vm'
                    }
                },
                resolve: {
                    cb: ['CashbackService', function cbFn(CashbackService){
                        return CashbackService.getData();
                    }]
                }
            });
    }
})();
(function() {
    ctrl.$inject = ['CashbackService', 'cb', '$scope'];
    angular
        .module('purple-wind.tabs')
        .controller('CashBackCtrl', ctrl);

    function ctrl(CashbackService, cb, $scope) {
        var vm = this;
        // vm.nocashback = false;
        var data = CashbackService.build(cb);

        vm.cartes = [];

        vm.loading=false;
        
                vm.loadTotal = function(datas){
                     vm.gainRemboursee =0;
                     vm.gainEnCours=0;
                     vm.gainRefusee=0;
                     vm.cartes = [];
                    datas.forEach(function(ele){
                        vm.gainRemboursee += ele.gainRemboursee.montant;
                        vm.gainEnCours += ele.gainEnCours.montant;
                        vm.gainRefusee += ele.gainRefusee.montant;
                        vm.cartes.push({typeCarte : ele.typeCarte, numDesensibilise : ele.numDesensibilise })
                    });
        
                }
        
                vm.loadTotal(data);
                
                vm.loadGain = function (index) {
                    vm.loading=true;
                    vm.numDesensibilise = data[index].numDesensibilise;
                    vm.typeCarte = data[index].typeCarte;
                    vm.getGains(data[index]);
                    vm.loading=false;
                }
        
                vm.getGains=function (data) {
                    var list = [];
        
                    data.gainRemboursee.gainMois.forEach(function(element) {
                        element.gains.forEach(function(el){
                            el.type=1;
                            el.logo=CashbackService.getSalesLocationLogo(el.enseigne);
                            list.push(el);
                        });
                    });
        
                     data.gainEnCours.gainMois.forEach(function(element) {
                        element.gains.forEach(function(el){
                            el.type=0;
                            el.logo=CashbackService.getSalesLocationLogo(el.enseigne);
                            list.push(el);
                        });
                    });
        
                     data.gainRefusee.gainMois.forEach(function(element) {
                        element.gains.forEach(function(el){
                            el.type=-1;
                            el.logo=CashbackService.getSalesLocationLogo(el.enseigne);
                            list.push(el);
                        });
                    });
        
        
                    vm.gains=list;
        
        
                }
        
                vm.loadGain(0);
        
                
        
                 $scope.$on('$ionicSlides.slideChangeStart', function(event, data) {
                    $scope.$apply(vm.loadGain(data.slider.activeIndex)); 
                });
        
        
                vm.toggleGroup = function (group) {
                    group.show = !group.show;
                };
                vm.isGroupShown = function (group) {
                    return (group) ? group.show : false;
                };
        
                vm.options = {
                    loop: false,
                    effect: 'slide',
                    speed: 500
                };
        

      
    }
})();
(function() {
    service.$inject = ['$q', '$requester', 'lodash', '$storage'];
    angular
        .module('purple-wind.tabs')
        .service('CashbackService', service);

    function service($q, $requester, lodash, $storage) {
        function getCashBackList() {
            var dfd = $q.defer();
            $requester
                .api('cashbacks', { 'email': $storage.get('email') })
                .then(function(success) {
                    dfd.resolve(success.data);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }

        function buildCashBackAccordions(data) {
            lodash.forEach(data, function(element) {
                element.gainEnCours.show = true;
                element.gainRemboursee.show = true;
                lodash.forEach(element.gainEnCours.gainMois, function(gain) {
                    gain.show = false;
                    lodash.forEach(gain.gains, function(transaction) {
                        transaction.show = false;
                    });
                });
                lodash.forEach(element.gainRemboursee.gainMois, function(gain) {
                    gain.show = false;
                    lodash.forEach(gain.gains, function(transaction) {
                        transaction.show = false;
                    });
                });
            });

            return data;
        }

        function getSalesLocationLogo(nom) {
            var offers = $storage.get('offers');
            var logo = '';

            for (var i = 0; i < offers.length; i++) {
                if (offers[i].annonceur.nom == nom) {
                    logo=offers[i].annonceur.image_logo_small;
                    break;
                }
            }

            return logo;
        }

        return {
            'getData': getCashBackList,
            'getSalesLocationLogo': getSalesLocationLogo,
            'build': buildCashBackAccordions
        };

    }
})();
(function() {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.account', {
                url: '/account',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/account/account.html',
                        controller: 'AccountCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();
(function() {
    ctrl.$inject = ['AccountService', '$scope', '$cordovaAppVersion'];
    angular
        .module('purple-wind.tabs')
        .controller('AccountCtrl', ctrl);

    function ctrl(AccountService, $scope, $cordovaAppVersion) {
        var vm = this;
        vm.appName = '';
        vm.versionNumber = '';

        if (window.cordova){
            $cordovaAppVersion.getAppName().then(function(appName) {
                vm.appName = appName;
            });
            $cordovaAppVersion.getVersionNumber().then(function(versionNumber) {
                vm.versionNumber = 'v' + versionNumber;
            });
        }

        $scope.$on('$ionicView.beforeEnter', function() {
            AccountService
                .getData()
                .then(function(cb) {
                    vm.numDesensibilise = cb.carteDTOs[0].numero;
                    vm.typeCarte = cb.carteDTOs[0].typeCarte;
                    vm.img = setCardImg(vm.numDesensibilise);
                });
        });

        function setCardImg(typeCarte) {
            return Number.parseInt(typeCarte.substring(0, 1)) === 4 ? 'visa2' : 'mastercard';
        }
    }
})();
(function() {
    svc.$inject = ['$q', '$requester'];
    angular
        .module('purple-wind.tabs')
        .service('AccountService', svc);

    function svc($q, $requester) {
        function getCardsList() {
            var dfd = $q.defer();
            $requester
                .api('account_info')
                .then(function(success) {
                    dfd.resolve(success.data);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }


        return {
            'getData': getCardsList
        };

    }
})();
(function() {
    ctrl.$inject = ['$stateParams', 'FaqService'];
    angular
        .module('purple-wind.tabs')
        .controller('FaqCtrl', ctrl);

    function ctrl($stateParams, FaqService) {
        var vm = this;
        vm.mail = $stateParams.mail;

        FaqService
            .getData()
            .then(function(data) {
                vm.groups = FaqService.build(data);
            });

        vm.toggleGroup = function(group) {
            group.show = !group.show;
        };
        vm.isGroupShown = function(group) {
            return (group) ? group.show : false;
        };
    }
})();
(function() {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.faq', {
                url: '/faq',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/faq/faq.html',
                        controller: 'FaqCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();
(function() {
    service.$inject = ['$q', '$requester', 'lodash'];
    angular
        .module('purple-wind.tabs')
        .service('FaqService', service);

    function service($q, $requester, lodash) {
        function getFAQs() {
            var dfd = $q.defer();
            $requester
                .api('faq')
                .then(function(success) {
                    dfd.resolve(success.data);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }

        function buildAccordion(data) {
            lodash.forEach(data, function(element) {
                element.show = false;
                lodash.forEach(element.questionFAQS, function(question) {
                    question.show = false;
                });
            });
            return data;
        }

        return {
            'getData': getFAQs,
            'build': buildAccordion
        };

    }
})();
(function() {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.cgu')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.contact', {
                url: '/contact',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/contact/contact-phone.html'
                    }
                }
            });
    }
})();
(function () {
    ctrl.$inject = ['$state', '$requester', '$storage'];
    angular
        .module('purple-wind.tabs')
        .controller('FeedbackCtrl', ctrl);

    function ctrl($state, $requester, $storage) {
        var vm = this;
        vm.titre = '';
        vm.commentaire = '';
        vm.email = $storage.get('email');


        vm.valider = function () {
                if (vm.titre != '' && vm.commentaire != '') {
                    $requester.api('feedback', { 'titre': vm.titre, 'comment': vm.commentaire, 'clientId': 16954});
                    $state.go('app.account');
                };
                 
        
        };

        



    }
})();
(function() {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.feedback', {
                url: '/feedback',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/feedback/feedback.html',
                        controller: 'FeedbackCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();
(function() {
    ctrl.$inject = ['$state', 'SettingsService', '$scope', '$notification', '$permissions'];
    angular
        .module('purple-wind.tabs')
        .controller('SettingsCtrl', ctrl);

    function ctrl($state, SettingsService, $scope, $notification, $permissions) {
        var vm = this;
        vm.isIOS = ionic.Platform.isIOS();
        //TODO - this should be moved to service
        vm.setNotification = function() {
            vm.currentSettings.notifications = vm.self.notifications;
            SettingsService.save(vm.currentSettings);
            if (vm.currentSettings.notifications === true) {
                $notification.activateNotification();
            } else {
                $notification.deactivateNotification();
            }
        };

        function callbackCheck(data) {
            vm.hasPermission = data.status;
        }

        //TODO - this should be moved to service
        vm.setGeolocalisation = function() {
            if(!vm.isIOS){
            vm.currentSettings.geolocation = vm.self.geolocation;
            SettingsService.save(vm.currentSettings);
            if (vm.currentSettings.geolocation === true) {
                ionic.trigger('activateGeolocEvent');
            } else {
                ionic.trigger('deactivateGeolocEvent');
            }
        }
        };


        vm.self = {}
        vm.currentSettings = SettingsService.load();

        function redirect(route, params) {
            $state.go(route, params);
        }

        vm.changePassword = function() {
            redirect('app.resetpwd');
        };

        //TODO - this should be moved to service 
        $scope.$on('$ionicView.beforeEnter', function() {
            if (window.cordova) {
                $permissions.getLocationAuthorizationStatus().then(callbackCheck);
            } else {
                vm.hasPermission = true;
            }
        })
        $scope.$on('$ionicView.enter', function() {
            if (vm.currentSettings) {
                vm.self.notifications = (typeof vm.currentSettings.notifications !== 'undefined') ? vm.currentSettings.notifications : true;
                vm.self.geolocation = (typeof vm.currentSettings.geolocation !== 'undefined') ? vm.currentSettings.geolocation : true;
            } else {
                vm.currentSettings = SettingsService.init();
                vm.currentSettings.geolocalisation = vm.hasPermission;
                vm.self.geolocation = vm.currentSettings.geolocation;
                SettingsService.save(vm.currentSettings);
            }
        });
    }
})();
(function () {
    routes.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.settings', {
                url: '/settings',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/settings/settings.html',
                        controller: 'SettingsCtrl',
                        controllerAs: 'vm'
                    }
                }
            })
            .state('app.resetpwd', {
                url: '/reset-pwd',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/enroll/enroll-password.html',
                        controller: 'EnrollPasswordCtrl',
                        controllerAs: 'vm'
                    }
                },
                params: {
                    'code': null,
                    'mail': null,
                    'isReset': true
                }
            });
    }
})();
(function() {
    service.$inject = ['$storage'];
    angular
        .module('purple-wind.tabs')
        .service('SettingsService', service);

    function service($storage) {

        function save(settings) {
            $storage.set('settings', settings);
        }

        function load() {
            return $storage.get('settings');
        }

        function init() {
            return {
                'notifications': true,
                'geolocation': true
            };
        }


        return {
            'save': save,
            'load': load,
            'init': init
        };
    }
})();
(function() {
    ctrl.$inject = ['$scope', '$stateParams', 'HomeService'];
    angular
        .module('purple-wind.tabs')
        .controller('OfferMapCtrl', ctrl);

    function ctrl($scope, $stateParams, HomeService) {
        var vm = this;
        vm.map = HomeService.loadMap();
        vm.vendor = $stateParams.vendor;

        $scope.$on('$ionicView.afterEnter', function() {
            vm.markers = $stateParams.locations;
        });
    }
})();
(function() {
    route.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(route);

    function route($stateProvider) {
        $stateProvider
            .state('app.locations', {
                url: '/locations',
                views: {
                    'tab-offers': {
                        templateUrl: 'modules/offer-map/offer-map.html',
                        controller: 'OfferMapCtrl',
                        controllerAs: 'offermap'
                    }
                },
                params: {
                    locations: null,
                    vendor: ''
                }
            });
    }
})();
(function() {
    ctrl.$inject = ['$scope', '$storage', '$tag', '$state', '$update', '$stateParams'];
    angular
        .module('purple-wind.tabs')
        .controller('TutorialCtrl', ctrl);

    function ctrl($scope, $storage, $tag, $state, $update, $stateParams) {
        var vm = this;
        vm.options = {
            loop: false,
            effect: 'slide',
            speed: 500
        };

        $update.displayUpdateMessage($stateParams.update);

        var sendTagPage = function(index) {
            switch (index) {
                case 0:
                    $tag.sendTagPage('intro', {});
                    break;
                case 1:
                    $tag.sendTagPage('mobile', {});
                    break;
                case 2:
                    $tag.sendTagPage('simple', {});
                    break;
            }
        };

        var sendTagAction = function(index, nextPage) {
            switch (index) {
                case 0:
                    $tag.sendClickBouton('intro_' + (nextPage ? 'next' : 'prev') + '_nav');
                    break;
                case 1:
                    $tag.sendClickBouton('mobile_' + (nextPage ? 'next' : 'prev') + '_nav');
                    break;
                case 2:
                    $tag.sendClickBouton('simple_' + (nextPage ? 'next' : 'prev') + '_nav');
                    break;
            }
        };

        $scope.$on('$ionicSlides.slideChangeStart', function(event, data) {
            sendTagAction(data.slider.previousIndex, data.slider.activeIndex > data.slider.previousIndex);
            sendTagPage(data.slider.activeIndex);
        });

    }
})();
(function() {
    cfg.$inject = ['$stateProvider'];
    angular
        .module('purple-wind.tabs')
        .config(cfg);

    function cfg($stateProvider) {
        $stateProvider
            .state('app.tutorial', {
                url: '/tutorial',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/tutorial/tutorial.html',
                        controller: 'TutorialCtrl',
                        controllerAs: 'intro',
                    }
                },
                params: {
                    'update': null
                }
            });
    }
})();
(function() {
    angular
        .module('purple-wind.components')
        .component('mapDisplay', {
            template: function($element, $attrs) {
                return '<div id="' + $attrs.mapId + '" on-double-tap="$ctrl.dblTap($event)" data-tap-disabled="true"></div>'
            },
            controller: 'mapCtrl',
            bindings: {
                mapId: '@',
                cfg: '=',
                markers: '<'
            }
        });
})();
(function() {
    ctrl.$inject = ['$document', 'lodash', 'geolocation', '$tag', '$map', '$storage', '$permissions', '$timeout', '$scope'];
    angular
        .module('purple-wind.tabs')
        .controller('mapCtrl', ctrl);

    function ctrl($document, lodash, geolocation, $tag, $map, $storage, $permissions, $timeout, $scope) {
        var vm = this,
            mapCenter = geolocation.osm.center,
            mapComponent,
            markersLayer,
            settings = $storage.get('settings');

        if (!settings) {
            settings = {
                'notifications': true,
                'geolocation': false
            };
            $storage.set('settings', settings);
        }

        function initMap(id, cfg) {
            var _layer0 = L.tileLayer(vm.cfg.layers.baselayers.osm.url, {
                id: vm.cfg.layers.baselayers.osm.name,
                detectRetina: true,
                crossOrigin: true
            });
            mapComponent = L
                .map(id, {
                    attributionControl: cfg.defaults.attributionControl,
                    zoomControl: cfg.defaults.zoomControl,
                    fadeAnimation: cfg.defaults.fadeAnimation,
                    markerZoomAnimation: cfg.defaults.markerZoomAnimation,
                    tap: true,
                    touchZoom: cfg.defaults.touchZoom || 'center',
                    doubleClickZoom: cfg.defaults.doubleClickZoom || 'center',
                    tapTolerance: 5,
                    layers: [
                        _layer0
                    ]
                });
            //Listner for map component
            mapComponent.on('popupopen', function() {
                ionic.trigger('popUpOnpened');
            })
        }

        function doWhenDoubleClick() {
            mapComponent.zoomIn();
        }

        function setMapCenter(center) {
            if (mapComponent) {
                mapComponent.setView([center.lat, center.lng], center.zoom);
            }
        }

        function setMapCenterMarker(center) {
            if (vm._centerLayer) {
                mapComponent.removeLayer(vm._centerLayer);
            }
            vm._centerLayer = L.marker([center.lat, center.lng], {
                icon: L.icon(geolocation.icons.center[vm.cfg.network]),
                zIndexOffset: 9999
            }).addTo(mapComponent);
        }

        /**
         * sets an array of markers on map
         * using the cluster grouping
         * @param {Array} markers 
         */
        function setMarkersOnMap(markers) {
            var _cluster = L.markerClusterGroup(geolocation.osm.cluster);
            lodash.forEach(markers, function(marker) {
                _cluster.addLayer(buildMarker(marker));
            });
            if (mapComponent) {
                markersLayer = _cluster;
                mapComponent.addLayer(_cluster);
            }
        }

        function removeMarkers() {
            markersLayer.removeFrom(mapComponent);
        }

        /**
         * builds a marker that can be put on the map
         * using coordinates
         * @param {any} marker 
         * @returns a marker to be put on leaflet map
         */
        function buildMarker(marker) {
            var _marker = L.marker([marker.lat, marker.lng], {
                    icon: L.icon(geolocation.icons[vm.cfg.network])
                }),
                _popup = L.popup({
                    closeButton: false
                })
                .setContent(marker.message);

            _marker.bindPopup(_popup);
            _marker.on('click', function() {
                $tag.sendClickBouton('offer_popup_btn');
                $tag.sendTagPage('app.offer-popup', {});
            });
            return _marker;
        }

        /**
         * adds the button that pinpoints the device on map
         */
        function addControl() {
            
            var CenterButton = L.Control.extend({
                    onAdd: function() {
                        var _btn = L.DomUtil.create('button');
                        _btn.className = 'icon app-position icon-location-big'
                        L.DomEvent.on(_btn, 'click', function() {
                            $map.pinpoint().then(doWhenGeolocationControlTap);
                        });
                        return _btn;
                    },
                    onRemove: function() {
                        L.DomUtil.remove(this);
                        L.DomEvent.off(this)
                    }
                }),
                _btn = function(opts) {
                    return new CenterButton(opts);
                };

                ionic.trigger('calculateDistanceinit');  

            vm._centerBtn = _btn({ position: 'bottomright' }).addTo(mapComponent);
        }

        function doWhenGeolocationControlTap(location) {
            vm._centerCoords = {
                lat: location.coords.latitude,
                lng: location.coords.longitude
            };
            mapComponent.setView([vm._centerCoords.lat, vm._centerCoords.lng]);
            setMapCenterMarker(vm._centerCoords);
            settings.geolocation = true;
            $storage.set('settings', settings);
        }

        /**
         * Callback executed when the component pinpoints 
         * 
         * @param {any} location 
         */
        function doWhenLocationFound(location) {
            vm._centerCoords = {
                lat: location.coords.latitude,
                lng: location.coords.longitude
            };
            mapComponent.setView([vm._centerCoords.lat, vm._centerCoords.lng], 13);
            setMapCenterMarker(vm._centerCoords);
            settings.geolocation = true;
            $storage.set('settings', settings);
        }

        /**
         * occurs when app pinpoint device location
         */
        function doWhenGeolocationActivated() {
            var _setting = {
                'notifications': true,
                'geolocation': true
            }
            $storage.set('settings', _setting);
            addControl();
        }

        function doWhenGeolocationDisabled() {
            var _setting = {
                'notifications': true,
                'geolocation': false
            }
            $storage.set('settings', _setting);
            if (vm._centerLayer) {
                mapComponent.removeLayer(vm._centerLayer);
            }
            if (vm._centerBtn) {
                mapComponent.removeControl(vm._centerBtn);
            }
        }
        /**
         * request permission from user
         * @param {any} permission 
         * @returns promise
         */
        function requestPermission() {
            return $permissions.requestLocationAuthorization();
        }

        function doWhenPermissionGranted() {
            var storageLocateBtn = $storage.get('locate_btn');
            if ((storageLocateBtn === null) || (storageLocateBtn === false)) {
                $tag.sendClickBouton('locate_valid_btn');
            }
            $map.pinpoint().then(doWhenLocationFound);
        }

        function doWhenPermissionDenied() {
            var storageLocateBtn = $storage.get('locate_btn');
            if (storageLocateBtn === null) {
                $tag.sendClickBouton('locate_refuse_btn');
            }
            if (!settings) {
                settings = {
                    'notifications': true,
                    'geolocation': false
                };
                $storage.set('settings', settings);
            }
            doWhenGeolocationDisabled();
        }

        function recalculateCurrentPosition(event, obj){
            vm._centerCoords = {
                lat: obj.position.coords.latitude,
                lng: obj.position.coords.longitude
            };
            setMapCenterMarker(vm._centerCoords);
        }

        $scope.$on('recalculateCurrentPosition',recalculateCurrentPosition);

        function checkDeviceStatus() {
            return $permissions.isLocationEnabled();
        }

        function checkAppStatus() {
            return $permissions.isLocationAvailable();
        }

        function checkLocationAuthorizationStatus() {
            return $permissions.getLocationAuthorizationStatus();
        }

        /**
         * ask for user approval for access to device geolocation feature.
         * PS: the OS popup for approval appear only once, it does not appear when again if user denies it
         * 
         * @param {Object} requestStatus 
         * @returns function argument for chaining
         */
        function applyApprovalToSettings(requestStatus) {
            if (settings) {
                settings.geolocation = requestStatus.status;
                $storage.set('settings', settings);
            }
            $storage.set('locate_btn', requestStatus.status);
            return requestStatus;
        }

        /**
         * double tap event listner
         * zoom on center when user double tap on map
         */
        vm.dblTap = doWhenDoubleClick;

        /**
         * Lifecyle -> Event fired when the component is initialized
         */
        vm.$onInit = function() {
            initMap(vm.mapId, vm.cfg);
            setMapCenter(mapCenter);
            //check if running on device
            if (window.cordova) {
                checkDeviceStatus()
                    .then(function(deviceStatus) {
                        //if geolocation feature is enabled on device
                        //then check app access to geolocation 
                        if (deviceStatus) {
                            if (!settings.geolocation) {
                                requestPermission()
                                    .then(applyApprovalToSettings)
                                    .then(function(requestStatus) {
                                        if (requestStatus.status) {
                                            doWhenPermissionGranted();
                                            doWhenGeolocationActivated();
                                        } else {
                                            //if request denied, only map and markers should be processed
                                            doWhenPermissionDenied();
                                            doWhenGeolocationDisabled();
                                        }
                                    });
                            } else {
                                //if request granted, a secondary checkpoint must be performed in order to handle user
                                //disabling of geolocation from outside the app
                                checkAppStatus()
                                    .then(function(appStatus) {
                                        //if app has access to geolocation
                                        //then get geolocation
                                        if (appStatus) {
                                            doWhenPermissionGranted();
                                            addControl();
                                        } else {
                                            //occurs when geolocation is disabled for app
                                            doWhenGeolocationDisabled();
                                        }
                                    });
                            }
                        } else {
                            doWhenGeolocationDisabled();
                        }
                    });
            }
        };
        /**
         * Lifecycle -> Event fired when update occurs on component binded data
         */
        vm.$onChanges = function(data) {
            //occurs when markers parameter changes
            if (data.markers && data.markers.currentValue) {
                //if the list of marker provided to map component length not empty then put on map
                if (markersLayer) {
                    removeMarkers();
                }
                setMarkersOnMap(data.markers.currentValue);
            }
        };

        //listner for activate/disable geolocation using external settings
        ionic.on('activateGeolocEvent', doWhenGeolocationActivated);
        ionic.on('deactivateGeolocEvent', doWhenGeolocationDisabled);
    }
})();
(function() {
    angular
        .module('purple-wind.components')
        .component('offerList', {
            templateUrl: 'webcomponents/list/list.html',
            controller: 'listCtrl',
            bindings: {
                offers: '='
            }
        });
})();
(function() {
    ctrl.$inject = ['HomeService', 'offers', '$state', '$storage', 'lodash', '$scope', '$timeout'];
    angular
        .module('purple-wind.tabs')
        .controller('listCtrl', ctrl);

    function ctrl(HomeService, offers, $state, $storage, lodash, $scope, $timeout) {
        var vm = this;

        vm.filtersState = '';
        vm.reverse = false;


        function resortEventMethode(event, obj){
            if(obj.id == 0){
                vm.filtersState = 'minDistance';
                vm.reverse = false;
            } else if(obj.id == 1){
                vm.filtersState = 'minDistance';
                vm.reverse = false;
            } else if(obj.id == 2) {
                vm.filtersState = 'dateFin';
                vm.reverse = false;
            } else if (obj.id == 3) {
                vm.filtersState = 'dateDebut';
                vm.reverse = true;
            } else if (obj.id == 4) {
                vm.filtersState = 'cashBackPourcentage';
                vm.reverse = true;
            }
        }

        $scope.$on('resortEvent',resortEventMethode);

        function updateOffer(id) {
            offers.consultOfferInCache(id);
            lodash.forEach(vm.offers, function(item) {
                if (item.id === lodash.toNumber(id)) {
                    item.consulte = true;
                }
            });
        }

        $scope.$on('sortChange', function (event , obj){
            vm.filtersState = obj.name;
            vm.reverse = obj.reverse ;
         })

        vm.goToDetail = function(id) {
            updateOffer(id);
            $state.go('app.offer-list', { offerId: id });
        }

        vm.animate=function(offer){

            offer.consulte = true;
        }

        vm.inview= function(index, inview, offer){
            if (offer.multiple) { 
                for(var i=0 ; i<offer.ids.length ; i++ ){
                    HomeService
                    .offerConsulted(offer.ids[i])
                    .catch(function () {
                        HomeService.saveOfferId(offer.ids[i]);
                    });
                }
            } else {
                HomeService
                    .offerConsulted(offer.id)
                    .catch(function () {
                        HomeService.saveOfferId(offer.id);
                    });
            }
            $timeout(vm.animate(offer),1000);
        }
    }
})();
(function() {
    angular
        .module('purple-wind.tabs')
        .component('drawer', {
            templateUrl: 'webcomponents/drawer/drawer.html',
            controller: 'drawerCtrl',
            bindings: {
                toggle: '<',
                mode: '<',
                items: '<',
                onSelect: '&',
                onRemove: '&'
            }
        });
})();

(function() {
    angular
        .module('purple-wind.tabs')
        .component('drawerSort', {
            templateUrl: 'webcomponents/drawer/drawer.sort.html',
            controller: 'drawerSortCtrl',
            bindings: {
                toggle: '<',
                mode: '<',
                items: '<',
                onSelect: '&',
                onRemove: '&'
            }
        });
})();
(function() {
    ctrl.$inject = ['$document', 'lodash', '$tag', '$storage', '$scope'];
    angular
        .module('purple-wind.tabs')
        .controller('drawerCtrl', ctrl);

    function ctrl($document, lodash, $tag, $storage, $scope) {
        var vm = this,
            mode = true,
            toggle = false;

        vm.options = {
            slidesPerView: 5,
            freeMode: true,
            loop: false
        };

        function createCategoriesList(items) {
            return lodash.chunk(items, 4);
        }

        function openDrawer(mapMode) {
            var _drawer = $document[0].getElementById('drawercomp');
            _drawer.style['height'] = '100%';
            _drawer.style['transition'] = '0.5s';
            _drawer.style['padding'] = '10px';
            _drawer.style['visibility'] = 'visible';
            _drawer.style['opacity'] = '1';
            _drawer.style['position'] = mapMode ? 'fixed' : 'initial';
        }

        function closeDrawer() {
            var _drawer = $document[0].getElementById('drawercomp');
            _drawer.style['height'] = '0%';
            _drawer.style['padding'] = '0';
            _drawer.style['transition'] = '0.5s';
            _drawer.style['visibility'] = 'hidden';
            _drawer.style['opacity'] = '0';
        }

        vm.selectedItems = [];
        /**
         * Lifecyle -> Event fired when the component is initialized
         */
        // vm.$onInit = function() {
            vm.items = createCategoriesList(vm.items);
        // };
        /**
         * Lifecycle -> Event fired when update occurs on component binded data
         */
        vm.$onChanges = function(data) {
            if (data.mode) {
                mode = data.mode.currentValue;
            }
            if (data.toggle) {
                toggle = data.toggle.currentValue;
            }
            if (data.items && data.items.currentValue && data.items.currentValue.length > 0) {
                vm.items = createCategoriesList(data.items.currentValue);
            }
            if (toggle) {
                openDrawer(mode);
            } else {
                closeDrawer();
            }
        };

        vm.select = function(item) {
            item.selected = !item.selected || false;
            if (item.selected) {
                vm.selectedItems = lodash.concat(vm.selectedItems, item);
                vm.onSelect({ data: vm.selectedItems });
            } else {
                vm.selectedItems = lodash.pull(vm.selectedItems, item);
                vm.onRemove({ data: vm.selectedItems });
            }
        }
    }
})();



(function() {
    ctrlSort.$inject = ['$document', 'lodash', '$tag', '$storage', '$scope', '$map', '$rootScope', '$translate', '$popup'];
    angular
        .module('purple-wind.tabs')
        .controller('drawerSortCtrl', ctrlSort);

    function ctrlSort($document, lodash, $tag, $storage, $scope, $map, $rootScope, $translate, $popup) {
        var vm = this,
            mode = true,
            toggle = false;

        vm.options = {
            slidesPerView: 5,
            freeMode: true,
            loop: false
        };
        vm.distanceItem;

        function createList(items) {
            vm.distanceItem = items[0];
            return lodash.chunk(items, 2);
        }

        function openDrawer(mapMode) {
            var _drawer = $document[0].getElementById('drawercomp');
            _drawer.style['height'] = '100%';
            _drawer.style['transition'] = '0.5s';
            _drawer.style['padding'] = '10px';
            _drawer.style['visibility'] = 'visible';
            _drawer.style['opacity'] = '1';
            _drawer.style['position'] = mapMode ? 'fixed' : 'initial';
        }

        function closeDrawer() {
            var _drawer = $document[0].getElementById('drawercomp');
            _drawer.style['height'] = '0%';
            _drawer.style['padding'] = '0';
            _drawer.style['transition'] = '0.5s';
            _drawer.style['visibility'] = 'hidden';
            _drawer.style['opacity'] = '0';
        }

        vm.selectedItems = [];
        /**
         * Lifecyle -> Event fired when the component is initialized
         */
        // vm.$onInit = function() {
            vm.items = createList(vm.items);
        // };
        /**
         * Lifecycle -> Event fired when update occurs on component binded data
         */
        vm.$onChanges = function(data) {
            if (data.mode) {
                mode = data.mode.currentValue;
            }
            if (data.toggle) {
                toggle = data.toggle.currentValue;
            }
            if (data.items && data.items.currentValue && data.items.currentValue.length > 0) {
                vm.items = createList(data.items.currentValue);
            }
            if (toggle) {
                openDrawer(mode);
            } else {
                closeDrawer();
            }
        };

        init();

        function notSelected(){
            var result = true ;
            lodash.forEach(vm.items, function(item) {
                if(result){
                    lodash.forEach(item, function(itemS) {
                        if(result){
                            if(itemS.selected){
                                result = false ;
                            }
                        }
                 });
                }
                
            });

            return result;

        } 

        function init(){
            if(notSelected()){
                $map.pinpoint().then(function (location) {
                    vm.distanceItem.disabled = false ;
                    vm.select(vm.distanceItem);
                });
                $rootScope.isFirstTime = false ;
            } 
        } 

        function deselectOther(currentItem){
            lodash.forEach(vm.items, function(item) {      
                lodash.forEach(item, function(itemS) {
                    if(itemS.id != currentItem.id){
                        itemS.selected = false ;
                    }
                });      
            });
        }

        function openHelperLocalisation() {
            return $popup.showBasicAlertDialog({
                'templateUrl': 'modules/helper/helper-localisation.html',
                'okText': $translate.instant('OK')
            });
        }

        vm.select = function(item) {

        if(!item.disabled){
            item.selected = !item.selected || false;
            if (item.selected) {
                deselectOther(item);
                vm.selectedItems = [];
                vm.selectedItems.push(item);
                vm.onSelect({ data: vm.selectedItems });
            } else {
                vm.selectedItems = lodash.pull(vm.selectedItems, item);
                vm.onRemove({ data: vm.selectedItems });
            }
        } else {
            openHelperLocalisation();
        }
        }
    }
})();
(function() {
    angular
        .module('purple-wind.components')
        .component('tutorialSlide1', {
            template: function($element, $attrs) {
                return '<div class="intro-title" >' + $attrs.slideTitle + '</div>' +
                    '<div class="intro-image-container"><img class="intro-image" src="' + $attrs.slideImage + '"></div>' +
                    '<div class="col col-center no-padding" ><div class="row">' +
                    '<h3 class="text-center">' + $attrs.slideTeaser + '</h3>' +
                    '</div></div>'
            },
            bindings: {
                'slideTitle': '@',
                'slideImage': '@',
                'slideTeaser': '@'
            }
        });
})();
(function() {
    angular
        .module('purple-wind.components')
        .component('tutorialSlide2', {
            template: function($element, $attrs) {
                return '<div class="intro-title">' + $attrs.slideTitle + '</div>' +
                    '<div class="intro-image-container"><img class="intro-image" src="' + $attrs.slideImage + '"></div>' +
                    '<div class="col col-center no-padding" ><div class="row">' +
                    '<div class="col col-center">' +
                    '<h3 class="text-center">' + $attrs.slideStep + '</h3></div></div>' +
                    '<div class="row"><div class="col col-center">' +
                    '<h3 class="text-center">' + $attrs.slideTeaser + '</h3></div></div></div>';
            },
            bindings: {
                'slideTitle': '@',
                'slideImage': '@',
                'slideStep': '@',
                'slideTeaser': '@'
            }
        });
})();
(function() {
    angular
        .module('purple-wind.components')
        .component('tutorialSlide3', {
            template: function($element, $attrs) {
                var _slideBtn;
                if ($attrs.slideButton) {
                    _slideBtn = '<div class="row">' +
                        '<button class ="button button-outline button-block button-intro" ui-sref="' + $attrs.slideRoute + '"' +
                        'tag-button="intro_btn" >' + $attrs.slideButton + '</button></div>';
                } else {
                    _slideBtn = '';
                }

                return '<div class="intro-title">' + $attrs.slideTitle + '</div>' +
                    '<div class="intro-image-container"><img class="intro-image" src="' + $attrs.slideImage + '"></div>' +
                    '<div class="col col-center no-padding" ><div class="row">' +
                    '<h3 class="text-center">' + $attrs.slideStep + '</h3></div></div>' +
                    '<div class="col col-center"><div class="row" ><div class="col col-center">' +
                    '<h3 class="text-center">' + $attrs.slideTeaser + '</h3></div></div>' + _slideBtn + '</div>';

            },
            bindings: {
                'slideTitle': '@',
                'slideImage': '@',
                'slideStep': '@',
                'slideTeaser': '@',
                'slideButton': '@',
                'slideRoute': '@'
            }
        });
})();
(function() {
    angular
        .module('purple-wind.components')
        .component('treeGrid', {
            templateUrl: 'webcomponents/treegrid/treegrid.html',
            controller: 'treegridCtrl',
            bindings: {
                'title': '@',
                'tagPage': '@',
                'src': '<'
            }
        });
})();
(function() {
    angular
        .module('purple-wind.tabs')
        .controller('treegridCtrl', ctrl);

    function ctrl() {
        var vm = this;

        vm.toggleGroup = function(group) {
            group.show = !group.show;
        };

        vm.isGroupShown = function(group) {
            return (group) ? group.show : false;
        };

        /**
         * Lifecyle -> Event fired when the component is initialized
         */
        /*
        vm.$onInit = function() {
            // debugger;
            console.log(vm);
        };
        */

        /**
         * Lifecycle -> Event fired when update occurs on component binded data
         */
        vm.$onChanges = function(data) {
            if (data && data.src && data.src.currentValue) {
                vm.parent = data.src.currentValue;
            }
        };
    }
})();
// # Angular-Inview
// - Author: [Nicola Peduzzi](https://github.com/thenikso)
// - Repository: https://github.com/thenikso/angular-inview
// - Install with: `npm install angular-inview`
// - Version: **3.0.0**
(function() {
'use strict';

// An [angular.js](https://angularjs.org) directive to evaluate an expression if
// a DOM element is or not in the current visible browser viewport.
// Use it in your AngularJS app by including the javascript and requireing it:
//
// `angular.module('myApp', ['angular-inview'])`
var moduleName = 'angular-inview';
angular.module(moduleName, [])

// ## in-view directive
//
// ### Usage
// ```html
// <any in-view="{expression}" [in-view-options="{object}"]></any>
// ```
.directive('inView', ['$parse', inViewDirective])

// ## in-view-container directive
.directive('inViewContainer', inViewContainerDirective);

// ## Implementation
function inViewDirective ($parse) {
  return {
    // Evaluate the expression passet to the attribute `in-view` when the DOM
    // element is visible in the viewport.
    restrict: 'A',
    require: '?^^inViewContainer',
    link: function inViewDirectiveLink (scope, element, attrs, container) {
      // in-view-options attribute can be specified with an object expression
      // containing:
      //   - `offset`: An array of values to offset the element position.
      //     Offsets are expressed as arrays of 4 numbers [top, right, bottom, left].
      //     Like CSS, you can also specify only 2 numbers [top/bottom, left/right].
      //     Instead of numbers, some array elements can be a string with a percentage.
      //     Positive numbers are offsets outside the element rectangle and
      //     negative numbers are offsets to the inside.
      //   - `viewportOffset`: Like the element offset but appied to the viewport.
      //   - `generateDirection`: Indicate if the `direction` information should
      //     be included in `$inviewInfo` (default false).
      //   - `generateParts`: Indicate if the `parts` information should
      //     be included in `$inviewInfo` (default false).
      //   - `throttle`: Specify a number of milliseconds by which to limit the
      //     number of incoming events.
      var options = {};
      if (attrs.inViewOptions) {
        options = scope.$eval(attrs.inViewOptions);
      }
      if (options.offset) {
        options.offset = normalizeOffset(options.offset);
      }
      if (options.viewportOffset) {
        options.viewportOffset = normalizeOffset(options.viewportOffset);
      }

      // Build reactive chain from an initial event
      var viewportEventSignal = signalSingle({ type: 'initial' })

      // Merged with the window events
      .merge(signalFromEvent(window, 'checkInView click ready wheel mousewheel DomMouseScroll MozMousePixelScroll resize scroll touchmove mouseup keydown'))

      // Merge with container's events signal
      if (container) {
        viewportEventSignal = viewportEventSignal.merge(container.eventsSignal);
      }

      // Throttle if option specified
      if (options.throttle) {
        viewportEventSignal = viewportEventSignal.throttle(options.throttle);
      }

      // Map to viewport intersection and in-view informations
      var inviewInfoSignal = viewportEventSignal

      // Inview information structure contains:
      //   - `inView`: a boolean value indicating if the element is
      //     visible in the viewport;
      //   - `changed`: a boolean value indicating if the inview status
      //     changed after the last event;
      //   - `event`: the event that initiated the in-view check;
      .map(function(event) {
        var viewportRect;
        if (container) {
          viewportRect = container.getViewportRect();
          // TODO merge with actual window!
        } else {
          viewportRect = getViewportRect();
        }
        viewportRect = offsetRect(viewportRect, options.viewportOffset);
        var elementRect = offsetRect(element[0].getBoundingClientRect(), options.offset);
        var isVisible = !!(element[0].offsetWidth || element[0].offsetHeight || element[0].getClientRects().length);
        var info = {
          inView: isVisible && intersectRect(elementRect, viewportRect),
          event: event,
          element: element,
          elementRect: elementRect,
          viewportRect: viewportRect
        };
        // Add inview parts
        if (options.generateParts && info.inView) {
          info.parts = {};
          info.parts.top = elementRect.top >= viewportRect.top;
          info.parts.left = elementRect.left >= viewportRect.left;
          info.parts.bottom = elementRect.bottom <= viewportRect.bottom;
          info.parts.right = elementRect.right <= viewportRect.right;
        }
        return info;
      })

      // Add the changed information to the inview structure.
      .scan({}, function (lastInfo, newInfo) {
        // Add inview direction info
        if (options.generateDirection && newInfo.inView && lastInfo.elementRect) {
          newInfo.direction = {
            horizontal: newInfo.elementRect.left - lastInfo.elementRect.left,
            vertical: newInfo.elementRect.top - lastInfo.elementRect.top
          };
        }
        // Calculate changed flag
        newInfo.changed =
          newInfo.inView !== lastInfo.inView ||
          !angular.equals(newInfo.parts, lastInfo.parts) ||
          !angular.equals(newInfo.direction, lastInfo.direction);
        return newInfo;
      })

      // Filters only informations that should be forwarded to the callback
      .filter(function (info) {
        // Don't forward if no relevant infomation changed
        if (!info.changed) {
          return false;
        }
        // Don't forward if not initially in-view
        if (info.event.type === 'initial' && !info.inView) {
          return false;
        }
        return true;
      });

      // Execute in-view callback
      var inViewExpression = $parse(attrs.inView);
      var dispose = inviewInfoSignal.subscribe(function (info) {
        scope.$applyAsync(function () {
          inViewExpression(scope, {
            '$inview': info.inView,
            '$inviewInfo': info
          });
        });
      });

      // Dispose of reactive chain
      scope.$on('$destroy', dispose);
    }
  }
}

function inViewContainerDirective () {
  return {
    restrict: 'A',
    controller: ['$element', function ($element) {
      this.element = $element;
      this.eventsSignal = signalFromEvent($element, 'scroll');
      this.getViewportRect = function () {
        return $element[0].getBoundingClientRect();
      };
    }]
  }
}

// ## Utilities

function getViewportRect () {
  var result = {
    top: 0,
    left: 0,
    width: window.innerWidth,
    right: window.innerWidth,
    height: window.innerHeight,
    bottom: window.innerHeight
  };
  if (result.height) {
    return result;
  }
  var mode = document.compatMode;
  if (mode === 'CSS1Compat') {
    result.width = result.right = document.documentElement.clientWidth;
    result.height = result.bottom = document.documentElement.clientHeight;
  } else {
    result.width = result.right = document.body.clientWidth;
    result.height = result.bottom = document.body.clientHeight;
  }
  return result;
}

function intersectRect (r1, r2) {
  return !(r2.left > r1.right ||
           r2.right < r1.left ||
           r2.top > r1.bottom ||
           r2.bottom < r1.top);
}

function normalizeOffset (offset) {
  if (!angular.isArray(offset)) {
    return [offset, offset, offset, offset];
  }
  if (offset.length == 2) {
    return offset.concat(offset);
  }
  else if (offset.length == 3) {
    return offset.concat([offset[1]]);
  }
  return offset;
}

function offsetRect (rect, offset) {
  if (!offset) {
    return rect;
  }
  var offsetObject = {
    top: isPercent(offset[0]) ? (parseFloat(offset[0]) * rect.height / 100) : offset[0],
    right: isPercent(offset[1]) ? (parseFloat(offset[1]) * rect.width / 100) : offset[1],
    bottom: isPercent(offset[2]) ? (parseFloat(offset[2]) * rect.height / 100) : offset[2],
    left: isPercent(offset[3]) ? (parseFloat(offset[3]) * rect.width / 100) : offset[3]
  };
  // Note: ClientRect object does not allow its properties to be written to therefore a new object has to be created.
  return {
    top: rect.top - offsetObject.top,
    left: rect.left - offsetObject.left,
    bottom: rect.bottom + offsetObject.bottom,
    right: rect.right + offsetObject.right,
    height: rect.height + offsetObject.top + offsetObject.bottom,
    width: rect.width + offsetObject.left + offsetObject.right
  };
}

function isPercent (n) {
  return angular.isString(n) && n.indexOf('%') > 0;
}

// ## QuickSignal FRP
// A quick and dirty implementation of Rx to have a streamlined code in the
// directives.

// ### QuickSignal
//
// - `didSubscribeFunc`: a function receiving a `subscriber` as described below
//
// Usage:
//     var mySignal = new QuickSignal(function(subscriber) { ... })
function QuickSignal (didSubscribeFunc) {
  this.didSubscribeFunc = didSubscribeFunc;
}

// Subscribe to a signal and consume the steam of data.
//
// Returns a function that can be called to stop the signal stream of data and
// perform cleanup.
//
// A `subscriber` is a function that will be called when a new value arrives.
// a `subscriber.$dispose` property can be set to a function to be called uppon
// disposal. When setting the `$dispose` function, the previously set function
// should be chained.
QuickSignal.prototype.subscribe = function (subscriber) {
  this.didSubscribeFunc(subscriber);
  var dispose = function () {
    if (subscriber.$dispose) {
      subscriber.$dispose();
      subscriber.$dispose = null;
    }
  }
  return dispose;
}

QuickSignal.prototype.map = function (f) {
  var s = this;
  return new QuickSignal(function (subscriber) {
    subscriber.$dispose = s.subscribe(function (nextValue) {
      subscriber(f(nextValue));
    });
  });
};

QuickSignal.prototype.filter = function (f) {
  var s = this;
  return new QuickSignal(function (subscriber) {
    subscriber.$dispose = s.subscribe(function (nextValue) {
      if (f(nextValue)) {
        subscriber(nextValue);
      }
    });
  });
};

QuickSignal.prototype.scan = function (initial, scanFunc) {
  var s = this;
  return new QuickSignal(function (subscriber) {
    var last = initial;
    subscriber.$dispose = s.subscribe(function (nextValue) {
      last = scanFunc(last, nextValue);
      subscriber(last);
    });
  });
}

QuickSignal.prototype.merge = function (signal) {
  return signalMerge(this, signal);
};

QuickSignal.prototype.throttle = function (threshhold) {
  var s = this, last, deferTimer;
  return new QuickSignal(function (subscriber) {
    var chainDisposable = s.subscribe(function () {
      var now = +new Date,
          args = arguments;
      if (last && now < last + threshhold) {
        clearTimeout(deferTimer);
        deferTimer = setTimeout(function () {
          last = now;
          subscriber.apply(null, args);
        }, threshhold);
      } else {
        last = now;
        subscriber.apply(null, args);
      }
    });
    subscriber.$dispose = function () {
      clearTimeout(deferTimer);
      if (chainDisposable) chainDisposable();
    };
  });
};

function signalMerge () {
  var signals = arguments;
  return new QuickSignal(function (subscriber) {
    var disposables = [];
    for (var i = signals.length - 1; i >= 0; i--) {
      disposables.push(signals[i].subscribe(function () {
        subscriber.apply(null, arguments);
      }));
    }
    subscriber.$dispose = function () {
      for (var i = disposables.length - 1; i >= 0; i--) {
        if (disposables[i]) disposables[i]();
      }
    }
  });
}

// Returns a signal from DOM events of a target.
function signalFromEvent (target, event) {
  return new QuickSignal(function (subscriber) {
    var handler = function (e) {
      subscriber(e);
    };
    var el = angular.element(target);
    event.split(' ').map(e => el[0].addEventListener(e, handler, true));
    subscriber.$dispose = function () {
      event.split(' ').map(e => el[0].removeEventListener(e, handler, true));
    };
  });
}

function signalSingle (value) {
  return new QuickSignal(function (subscriber) {
    setTimeout(function() { subscriber(value); });
  });
}

// Module loaders exports
if (typeof define === 'function' && define.amd) {
  define(['angular'], moduleName);
} else if (typeof module !== 'undefined' && module && module.exports) {
  module.exports = moduleName;
}

})();
