(function() {
    var dfltPluginCfg = { "sourceFile": "download", "info": true };
    var dfltGlobalCfg = { "site": 571453, "log": "logc233", "logSSL": "logs1233", "domain": "xiti.com", "secure": false, "pixelPath": "/hit.xiti", "disableCookie": false, "cookieSecure": false, "cookieDomain": "", "preview": false, "plgs": ["Clicks", "ClientSideUserId", "ContextVariables", "IdentifiedVisitor", "Offline", "Page"], "lazyLoadingPath": "", "documentLevel": "document", "redirect": false, "activateCallbacks": true, "medium": "", "ignoreEmptyChapterValue": false, "base64Storage": false };
    (function(a, b) {
        a.ATInternet = a.ATInternet || {};
        a.ATInternet.Tracker = a.ATInternet.Tracker || {};
        a.ATInternet.Tracker.Plugins = a.ATInternet.Tracker.Plugins || {}
    })(window);
    window.ATInternet.Utils = new function() {
        function a(b) {
            var l = typeof b;
            if ("object" !== l || null === b) return "string" === l && (b = '"' + b + '"'), String(b);
            var h, g, c = [],
                e = b && b.constructor === Array;
            for (h in b) b.hasOwnProperty(h) && (g = b[h], l = typeof g, "function" !== l && "undefined" !== l && ("string" === l ? g = '"' + g.replace(/[^\\]"/g, '\\"') + '"' : "object" === l && null !== g && (g = a(g)), c.push((e ? "" : '"' + h + '":') + String(g))));
            return (e ? "[" : "{") + String(c) + (e ? "]" : "}")
        }
        var b = this;
        b.cloneSimpleObject = function l(a, b) {
            if ("object" !== typeof a || null ===
                a || a instanceof Date) return a;
            var c = new a.constructor || a.constructor(),
                e;
            for (e in a) a.hasOwnProperty(e) && (void 0 === e || b && void 0 === a[e] || (c[e] = l(a[e])));
            return c
        };
        b.jsonSerialize = function(l) { return "undefined" !== typeof JSON && JSON.stringify ? JSON.stringify(l) : a(l) };
        b.jsonParse = function(a) {
            try {
                if ("undefined" !== typeof JSON && JSON.parse) return JSON.parse(a);
                var b;
                b = null === a ? a : "string" === typeof a ? (new Function("return " + a))() : !1;
                return b
            } catch (g) { return null }
        };
        b.arrayIndexOf = function(a, b) {
            return Array.indexOf ?
                a.indexOf(b) : function(a) {
                    if (null == this) throw new TypeError;
                    var c = Object(this),
                        e = c.length >>> 0;
                    if (0 === e) return -1;
                    var d = 0;
                    1 < arguments.length && (d = Number(arguments[1]), d != d ? d = 0 : 0 != d && Infinity != d && -Infinity != d && (d = (0 < d || -1) * Math.floor(Math.abs(d))));
                    if (d >= e) return -1;
                    for (d = 0 <= d ? d : Math.max(e - Math.abs(d), 0); d < e; d++)
                        if (d in c && c[d] === a) return d;
                    return -1
                }.apply(a, [b])
        };
        b.genGuid = function(a) {
            var b = new Date,
                g = function(a) { a -= 100 * Math.floor(a / 100); return 10 > a ? "0" + a : a };
            return g(b.getHours()) + "" + g(b.getMinutes()) +
                "" + g(b.getSeconds()) + "" + function(a) { return Math.floor(Math.random() * Math.pow(10, a)) }(a - 6)
        };
        b.getObjectKeys = function(a) {
            var b = [],
                g;
            for (g in a) a.hasOwnProperty(g) && b.push(g);
            return b
        };
        b.completeFstLevelObj = function(a, b, g) {
            if (a) {
                if (b)
                    for (var c in b) !b.hasOwnProperty(c) || a[c] && !g || (a[c] = b[c])
            } else a = b;
            return a
        };
        b.isPreview = function() { return window.navigator && "preview" === window.navigator.loadPurpose };
        b.isPrerender = function(a) {
            var h, g = !1,
                c = ["webkit", "ms"];
            if ("prerender" === document.visibilityState) h = "visibilitychange";
            else
                for (var e = 0; e < c.length; e++) "prerender" === document[c[e] + "VisibilityState"] && (h = c[e] + "visibilitychange");
            if ("undefined" !== typeof h) {
                var d = function(e) {
                    a(e);
                    b.removeEvtListener(document, h, d)
                };
                b.addEvtListener(document, h, d);
                g = !0
            }
            return g
        };
        var k = b.addEvtListener = function(a, b, g) { a.addEventListener ? a.addEventListener(b, g, !1) : a.attachEvent && a.attachEvent("on" + b, g) };
        b.removeEvtListener = function(a, b, g) { a.removeEventListener ? a.removeEventListener(b, g, !1) : a.detachEvent && a.detachEvent("on" + b, g) };
        b.loadScript =
            function(a, b) {
                var g;
                b = b || function() {};
                g = document.createElement("script");
                g.type = "text/javascript";
                g.src = a.url;
                g.async = !1;
                g.defer = !1;
                g.onload = g.onreadystatechange = function(a) { a = a || window.event; if ("load" === a.type || /loaded|complete/.test(g.readyState) && (!document.documentMode || 9 > document.documentMode)) g.onload = g.onreadystatechange = g.onerror = null, b(null, a) };
                g.onerror = function(a, c, l) {
                    g.onload = g.onreadystatechange = g.onerror = null;
                    b({ msg: "script not loaded", event: a })
                };
                var c = document.head || document.getElementsByTagName("head")[0];
                c.insertBefore(g, c.lastChild)
            };
        b.hashcode = function(a) {
            var b = 0;
            if (0 === a.length) return b;
            for (var g = 0; g < a.length; g++) var c = a.charCodeAt(g),
                b = (b << 5) - b + c,
                b = b & b;
            return b
        };
        b.setLocation = function(a) {
            var b = a.location;
            a = window[a.target] || window;
            b && (a.location.href = b)
        };
        b.dispatchCallbackEvent = function(a) {
            var b = document.createEvent("Event");
            b.initEvent("ATCallbackEvent", !0, !0);
            b.name = a;
            document.dispatchEvent(b)
        };
        b.addCallbackEvent = function(a) {
            document.createEvent("Event").initEvent("ATCallbackEvent", !0, !0);
            k(document,
                "ATCallbackEvent", a)
        }
    };
    var BuildManager = function(a) {
            var b = this,
                k = function(a, c, b) { a = "&" + a + "="; return { param: a, paramSize: a.length, str: c, strSize: c.length, truncate: b } },
                f = function(c, d) {
                    var b = "",
                        l = 0,
                        f = !0,
                        r;
                    for (r in c)
                        if (c.hasOwnProperty(r)) {
                            var p = c[r];
                            if (p) {
                                var f = !1,
                                    g = d - l;
                                if (p.strSize + p.paramSize < g) b += p.param + p.str, l += p.strSize + p.paramSize, c[r] = void 0, f = !0;
                                else {
                                    p.truncate ? (b += p.param + p.str.substr(0, g), c[r].str = p.str.substr(g, p.strSize - 1), c[r].strSize = c[r].str.length) : p.strSize + p.paramSize > d && (a.emit("Tracker:Hit:Build:Error", {
                                        lvl: "ERROR",
                                        msg: 'Too long parameter "' + p.param + '"',
                                        details: { value: p.str }
                                    }), c[r].str = c[r].str.substr(0, d - p.paramSize - 1), c[r].strSize = c[r].str.length);
                                    break
                                }
                            } else f = !0
                        }
                    return [b, f ? null : c]
                },
                l = ["ati", "atc", "pdtl", "stc", "dz"],
                h = function(c, b, g) {
                    var h = function(a) {
                            if (a === {}) return "";
                            var c = [],
                                b;
                            b = {};
                            var e = 0,
                                d = !1,
                                g = void 0,
                                r, n, h;
                            for (h in a)
                                if (a.hasOwnProperty(h)) {
                                    var q = a[h].value;
                                    "function" === typeof q && (q = q());
                                    q = q instanceof Array ? q.join(a[h].options.separator || ",") : "object" === typeof q ? window.ATInternet.Utils.jsonSerialize(q) :
                                        "undefined" === typeof q ? "undefined" : q.toString();
                                    a[h].options.encode && (q = encodeURIComponent(q));
                                    var t = k(h, q, -1 < window.ATInternet.Utils.arrayIndexOf(l, h)),
                                        e = e + (t.paramSize + t.strSize);
                                    if (a[h].options.last) 1490 < q.length && q.substr(0, 1490), r = h, n = t;
                                    else if (b[h] = t, 1500 < b[h].paramSize + b[h].strSize && !b[h].truncate) {
                                        d = !0;
                                        g = h;
                                        break
                                    }
                                }
                            r && (b[r] = n);
                            b = [b, e, d, g];
                            a = b[0];
                            if (b[2]) b = b[3], a = a[b], a.str = a.str.substr(0, 1450), a.strSize = 1450, e = {}, e.mherr = k("mherr", "1", !1), e[b] = a, c.push(f(e, 1500)[0]);
                            else if (b = f(a, 1500), null ===
                                b[1]) c = b[0];
                            else
                                for (c.push(b[0]); null !== b[1];) b = f(a, 1500), c.push(b[0]);
                            return c
                        },
                        t = "";
                    a.buffer.presentInFilters(b, "hitType") || (b = a.buffer.addInFilters(b, "hitType", ["page"]));
                    b = a.buffer.addInFilters(b, "hitType", ["all"]);
                    var r;
                    if (c) {
                        b = a.buffer.addInFilters(b, "permanent", !0);
                        b = a.buffer.get(b, !0);
                        for (r in c) c.hasOwnProperty(r) && (b[r] = { value: c[r], options: {} });
                        t = h(b)
                    } else
                        for (r in b = a.buffer.get(b, !0), t = h(b), b) b.hasOwnProperty(r) && !b[r].options.permanent && a.buffer.del(r);
                    g && g(t)
                },
                g = function(c) {
                    var b = a.getConfig("secure"),
                        l = "https:" === document.location.protocol,
                        l = b || l ? a.getConfig("logSSL") : a.getConfig("log"),
                        g = a.getConfig("baseURL"),
                        f = a.getConfig("domain"),
                        r = a.getConfig("pixelPath"),
                        p = a.getConfig("site");
                    (g || l && f && r) && p ? c && c(null, (g ? g : (b ? "https://" : "//") + l + ("." + f) + r) + ("?s=" + p)) : c && c({ message: "Config error" })
                },
                c = function(a, c, b) {
                    g(function(l, g) {
                        l ? b && b(l) : h(a, c, function(a) {
                            var c = [],
                                e = window.ATInternet.Utils.genGuid(13);
                            if (a instanceof Array)
                                if (1 === a.length) c.push(g + "&mh=1-2-" + e + a[0]);
                                else
                                    for (var d = 1; d <= a.length; d++) c.push(g +
                                        "&mh=" + d + "-" + a.length + "-" + e + a[d - 1]);
                            else c.push(g + a);
                            b && b(null, c)
                        })
                    })
                };
            b.send = function(e, d) {
                c(e, d, function(c, e) {
                    if (c) a.emit("Tracker:Hit:Build:Error", { lvl: "ERROR", msg: c.message, details: { hits: e } });
                    else
                        for (var d = 0; d < e.length; d++) b.sendUrl(e[d])
                })
            };
            b.sendUrl = function(c) {
                var b = function(c, b) { return function() { return function(e) { a.emit(c, { lvl: -1 === c.indexOf("Error") ? "INFO" : "ERROR", details: { hit: b, event: e } }) } }() },
                    l = new Image;
                l.onload = b("Tracker:Hit:Sent:Ok", c);
                l.onerror = b("Tracker:Hit:Sent:Error", c);
                l.src =
                    c
            }
        },
        TriggersManager = function() {
            function a(a, b, g) { for (var c = [], e = 0; e < a.length; e++) a[e].callback(b, g), a[e].singleUse || c.push(a[e]); return c }

            function b(a, f, g, c) {
                var e = a.shift();
                if ("*" === e) return f["*"] = f["*"] || [], f["*"].push({ callback: g, singleUse: c }), f["*"].length - 1;
                if (0 === a.length) return b([e, "*"], f, g, c);
                f["*"] = f["*"] || [];
                f[e] = f[e] || {};
                return b(a, f[e], g, c)
            }

            function k(b, f, g, c) { var e = f.shift(); "*" !== e && (0 === f.length ? k(b, [e, "*"], g, c) : g[e] && (g[e]["*"] = a(g[e]["*"], b, c), k(b, f, g[e], c))) }
            var f = {};
            this.on = function(a,
                h, g) { g = g || !1; return b(a.split(":"), f, h, g) };
            this.emit = function(b, h) {
                f["*"] && (f["*"] = a(f["*"], b, h));
                k(b, b.split(":"), f, h)
            }
        },
        PluginsManager = function(a) {
            var b = {},
                k = {},
                f = 0,
                l = {},
                h = 0,
                g = this.load = function(e, d) {
                    "function" === typeof d ? "undefined" === typeof a.getConfig.plgAllowed || 0 === a.getConfig.plgAllowed.length || -1 < a.getConfig.plgAllowed.indexOf(e) ? (b[e] = new d(a), k[e] && b[e] && (k[e] = !1, f--, b[e + "_ll"] && c(e + "_ll"), 0 === f && a.emit("Tracker:Plugin:Lazyload:File:Complete", { lvl: "INFO", msg: "LazyLoading triggers are finished" })),
                        a.emit("Tracker:Plugin:Load:" + e + ":Ok", { lvl: "INFO" })) : a.emit("Tracker:Plugin:Load:" + e + ":Error", { lvl: "ERROR", msg: "Plugin not allowed", details: {} }) : a.emit("Tracker:Plugin:Load:" + e + ":Error", { lvl: "ERROR", msg: "not a function", details: { obj: d } });
                    return a
                },
                c = this.unload = function(c) { b[c] ? (b[c] = void 0, a.emit("Tracker:Plugin:Unload:" + c + ":Ok", { lvl: "INFO" })) : a.emit("Tracker:Plugin:Unload:" + c + ":Error", { lvl: "ERROR", msg: "not a known plugin" }); return a },
                e = this.isLazyloading = function(a) { return a ? !0 === k[a] : 0 !== f },
                d =
                function(a) { return q(a) ? (n(a), !0) : !1 },
                n = function(c) {
                    k[c] = !0;
                    f++;
                    ATInternet.Utils.loadScript({ url: a.getConfig("lazyLoadingPath") + c + ".js" })
                },
                q = function(a) { return !b[a] && !e(a) && (b[a + "_ll"] ? !0 : !1) },
                t = function(a) {
                    l[a] ? l[a]++ : l[a] = 1;
                    h++
                };
            this.isExecWaitingLazyloading = function() { return 0 !== h };
            a.exec = this.exec = function(c, d, f, g) {
                var k = null,
                    s = function(a, c, e, d) {
                        c = c.split(".");
                        b[a] && b[a][c[0]] && (k = 1 < c.length && b[a][c[0]][c[1]] ? b[a][c[0]][c[1]].apply(b[a], e) : b[a][c[0]].apply(b[a], e));
                        d && d(k)
                    },
                    u = function(c, b, e, d) {
                        t(c);
                        a.onTrigger("Tracker:Plugin:Load:" + c + ":Ok", function() {
                            s(c, b, e, function(b) {
                                l[c]--;
                                h--;
                                0 === h && a.emit("Tracker:Plugin:Lazyload:Exec:Complete", { lvl: "INFO", msg: "All exec waiting for lazyloading are done" });
                                d && d(b)
                            })
                        }, !0)
                    };
                q(c) ? (u(c, d, f, g), n(c)) : e(c) ? u(c, d, f, g) : s(c, d, f, g)
            };
            this.waitForDependencies = function(c, e) {
                var f = function(a) { for (var c = { mcount: 0, plugins: {} }, e = 0; e < a.length; e++) b.hasOwnProperty(a[e]) || (c.mcount++, c.plugins[a[e]] = !0); return c }(c);
                if (0 === f.mcount) a.emit("Tracker:Plugin:Dependencies:Loaded", { lvl: "INFO", details: { dependencies: c } }), e();
                else
                    for (var g in f.plugins) f.plugins.hasOwnProperty(g) && (a.emit("Tracker:Plugin:Dependencies:Error", { lvl: "WARNING", msg: "Missing plugin " + g }), a.onTrigger("Tracker:Plugin:Load:" + g, function(a, c) {
                        var b = a.split(":"),
                            d = b[3];
                        "Ok" === b[4] && (f.plugins[d] = !1, f.mcount--, 0 === f.mcount && e())
                    }, !0), d(g))
            };
            this.init = function() { for (var a in ATInternet.Tracker.pluginProtos) ATInternet.Tracker.pluginProtos.hasOwnProperty(a) && g(a, ATInternet.Tracker.pluginProtos[a]) }
        },
        CallbacksManager =
        function(a) {
            var b = {};
            this.init = function() {
                if (a.getConfig("activateCallbacks")) {
                    var f = a.getConfig("callbacks");
                    (function() {
                        if ("undefined" !== typeof f && f.include instanceof Array)
                            for (var a = 0; a < f.include.length; a++) ATInternet.Callbacks && ATInternet.Callbacks.hasOwnProperty(f.include[a]) && (b[f.include[a]] = { "function": ATInternet.Callbacks[f.include[a]] }, ATInternet.Tracker.callbackProtos[f.include[a]] || (ATInternet.Tracker.callbackProtos[f.include[a]] = b[f.include[a]]));
                        else
                            for (a in ATInternet.Callbacks) ATInternet.Callbacks.hasOwnProperty(a) &&
                                (b[a] = { "function": ATInternet.Callbacks[a] }, ATInternet.Tracker.callbackProtos[a] || (ATInternet.Tracker.callbackProtos[a] = b[a]));
                        if ("undefined" !== typeof f && f.exclude instanceof Array)
                            for (a = 0; a < f.exclude.length; a++) b[f.exclude[a]] && (b[f.exclude[a]] = void 0);
                        for (var h in b) b.hasOwnProperty(h) && b[h] && k(h, b[h]["function"])
                    })();
                    ATInternet.Utils.addCallbackEvent(function(a) {
                        if (a.name) {
                            var b = !0;
                            "undefined" !== typeof f && (f.include instanceof Array && -1 === ATInternet.Utils.arrayIndexOf(f.include, a.name) && (b = !1),
                                f.exclude instanceof Array && -1 !== ATInternet.Utils.arrayIndexOf(f.exclude, a.name) && (b = !1));
                            if (ATInternet.Callbacks && ATInternet.Callbacks.hasOwnProperty(a.name)) {
                                var g = {};
                                g[a.name] = { "function": ATInternet.Callbacks[a.name] };
                                b && k(a.name, g[a.name]["function"]);
                                ATInternet.Tracker.callbackProtos[a.name] || (ATInternet.Tracker.callbackProtos[a.name] = g[a.name])
                            }
                        }
                    })
                }
            };
            var k = this.load = function(b, l) {
                "function" === typeof l ? (new l(a), a.emit("Tracker:Callback:Load:" + b + ":Ok", { lvl: "INFO", details: { obj: l } })) : a.emit("Tracker:Callback:Load:" +
                    b + ":Error", { lvl: "ERROR", msg: "not a function", details: { obj: l } });
                return a
            }
        },
        BufferManager = function(a) {
            var b = {};
            this.set = function(a, f, g) {
                g = g || {};
                g.hitType = g.hitType || ["page"];
                b[a] = { value: f, options: g }
            };
            var k = function(a, b, f) { return (a = window.ATInternet.Utils.cloneSimpleObject(a[b])) && !f ? a.value : a },
                f = function h(a, c) {
                    if (!(a && c instanceof Array && a instanceof Array)) return [];
                    if (0 === a.length) return c;
                    var e = a[0],
                        d, f = [],
                        k = window.ATInternet.Utils.cloneSimpleObject(a);
                    k.shift();
                    for (var t = 0; t < c.length; t++)
                        if ("object" !==
                            typeof e[1]) b[c[t]] && b[c[t]].options[e[0]] === e[1] && f.push(c[t]);
                        else {
                            d = e[1].length;
                            for (var r = 0; r < d; r++)
                                if (b[c[t]] && b[c[t]].options[e[0]] instanceof Array && 0 <= window.ATInternet.Utils.arrayIndexOf(b[c[t]].options[e[0]], e[1][r])) { f.push(c[t]); break }
                        }
                    return h(k, f)
                };
            this.get = function(a, g) {
                var c = {};
                if ("string" === typeof a) c = k(b, a, g);
                else
                    for (var e = f(a, window.ATInternet.Utils.getObjectKeys(b)), d = 0; d < e.length; d++) c[e[d]] = k(b, e[d], g);
                return c
            };
            this.presentInFilters = function g(a, b) {
                return a && 0 !== a.length ? a[0][0] ===
                    b ? !0 : g(a.slice(1), b) : !1
            };
            this.addInFilters = function c(a, b, f, k) {
                if (!a || 0 === a.length) return k ? [] : [
                    [b, f]
                ];
                var t = a[0][0],
                    r = a[0][1];
                t === b && (r instanceof Array && !(-1 < window.ATInternet.Utils.arrayIndexOf(r, f[0])) && r.push(f[0]), k = !0);
                return [
                    [t, r]
                ].concat(c(a.slice(1), b, f, k))
            };
            this.del = function(a) { b[a] = void 0 };
            this.clear = function() { b = {} }
        },
        Tag = function(a, b, k) {
            b = b || {};
            var f = this;
            f.version = "5.6.1";
            var l = window.ATInternet.Utils.cloneSimpleObject(b);
            f.triggers = new TriggersManager(f);
            f.emit = f.triggers.emit;
            f.onTrigger =
                f.triggers.on;
            var h = window.ATInternet.Utils.cloneSimpleObject(dfltGlobalCfg) || {},
                g;
            for (g in a) a.hasOwnProperty(g) && (h[g] = a[g]);
            f.getConfig = function(a) { return h[a] };
            f.setConfig = function(a, b, d) { void 0 !== h[a] && d || (f.emit("Tracker:Config:Set:" + a, { lvl: "INFO", details: { bef: h[a], aft: b } }), h[a] = b) };
            f.configPlugin = function(a, b, d) {
                h[a] = h[a] || {};
                for (var g in b) b.hasOwnProperty(g) && void 0 === h[a][g] && (h[a][g] = b[g]);
                d && (d(h[a]), f.onTrigger("Tracker:Config:Set:" + a, function(a, b) { d(b.details.aft) }));
                return h[a]
            };
            f.getContext =
                function(a) { return l[a] };
            f.setContext = function(a, b) {
                f.emit("Tracker:Context:Set:" + a, { lvl: "INFO", details: { bef: l[a], aft: b } });
                l[a] = b
            };
            f.delContext = function(a, b) {
                f.emit("Tracker:Context:Deleted:" + a + ":" + b, { lvl: "INFO", details: { key1: a, key2: b } });
                if (a) l.hasOwnProperty(a) && (b ? l[a] && l[a].hasOwnProperty(b) && (l[a][b] = void 0) : l[a] = void 0);
                else if (b)
                    for (var d in l) l.hasOwnProperty(d) && l[d] && l[d].hasOwnProperty(b) && (l[d][b] = void 0)
            };
            f.plugins = new PluginsManager(f);
            f.buffer = new BufferManager(f);
            f.setParam = f.buffer.set;
            f.getParams = function(a) { return f.buffer.get(a, !1) };
            f.getParam = f.buffer.get;
            f.delParam = f.buffer.del;
            f.builder = new BuildManager(f);
            f.sendHit = f.builder.send;
            f.sendUrl = f.builder.sendUrl;
            f.callbacks = new CallbacksManager(f);
            f.setParam("ts", function() { return (new Date).getTime() }, { permanent: !0, hitType: ["all"] });
            f.getConfig("disableCookie") && f.setParam("idclient", "xxxxxx-NO", { permanent: !0, hitType: ["all"] });
            f.getConfig("medium") && f.setParam("medium", f.getConfig("medium"), { permanent: !0, hitType: ["all"] });
            f.plugins.init();
            f.callbacks.init();
            ATInternet.Tracker.instances.push(f);
            f.emit("Tracker:Ready", { lvl: "INFO", msg: "Tracker initialized", details: { tracker: f, args: { config: a, context: b, callback: k } } });
            k && k(f)
        };
    ATInternet.Tracker.Tag = Tag;
    ATInternet.Tracker.instances = [];
    ATInternet.Tracker.pluginProtos = {};
    ATInternet.Tracker.addPlugin = function(a, b) { b = b || ATInternet.Tracker.Plugins[a]; if (!ATInternet.Tracker.pluginProtos[a]) { ATInternet.Tracker.pluginProtos[a] = b; for (var k = 0; k < ATInternet.Tracker.instances.length; k++) ATInternet.Tracker.instances[k].plugins.load(a, b) } };
    ATInternet.Tracker.delPlugin = function(a) { if (ATInternet.Tracker.pluginProtos[a]) { ATInternet.Tracker.pluginProtos[a] = void 0; for (var b = 0; b < ATInternet.Tracker.instances.length; b++) ATInternet.Tracker.instances[b].plugins.unload(a) } };
    ATInternet.Tracker.callbackProtos = {};
}).call(window);;
(function() {
    var dfltPluginCfg = { "info": true };
    var dfltGlobalCfg = {};
    window.ATInternet.Tracker.Plugins.Clicks = function(a) {
        var b = function(a) {
                var b = "";
                switch (a) {
                    case "exit":
                        b = "S";
                        break;
                    case "download":
                        b = "T";
                        break;
                    case "action":
                        b = "A";
                        break;
                    case "navigation":
                        b = "N"
                }
                return b
            },
            k = function(b) {
                var f = b.name;
                a.exec("Utils", "manageChapters", [b, "chapter", 3], function(a) { f = a + (f ? f : "") });
                return f
            },
            f = function(f) {
                var h = { p: k(f), s2: f.level2 || "", click: b(f.type) || "" },
                    g = a.getContext("page") || {};
                h.pclick = k(g);
                h.s2click = g.level2 || "";
                f.customObject && a.exec("Utils", "customObjectToString", [f.customObject],
                    function(a) { h.stc = a });
                a.sendHit(h, [
                    ["hitType", ["click"]]
                ])
            };
        a.click = {};
        a.clickListener = this.clickListener = {};
        a.click.send = this.send = function(b) {
            var h = !0;
            a.plugins.exec("TechClicks", "manageClick", [b.elem], function(a) { h = a });
            f(b);
            return h
        };
        a.clickListener.send = this.clickListener.send = function(b) {
            if (b.elem) {
                var h;
                a.plugins.exec("TechClicks", "isFormSubmit", [b.elem], function(a) { h = a ? "submit" : "click" });
                ATInternet.Utils.addEvtListener(b.elem, h, function(g) {
                    a.plugins.exec("TechClicks", "manageClick", [b.elem,
                        g
                    ]);
                    f(b)
                })
            }
        };
        a.click.set = this.set = function(f) {
            a.dispatchSubscribe("click");
            a.setContext("click", { name: k(f), level2: f.level2 || "", customObject: f.customObject });
            a.setParam("click", b(f.type) || "", { hitType: ["click"] })
        };
        a.click.onDispatch = this.onDispatch = function() {
            var b = { hitType: ["click"] };
            a.setParam("p", a.getContext("click").name, b);
            a.setParam("s2", a.getContext("click").level2, b);
            var f = a.getContext("click").customObject;
            f && a.setParam("stc", f, { hitType: ["click"], encode: !0 });
            f = a.getContext("page") || {};
            a.setParam("pclick",
                k(f), b);
            a.setParam("s2click", f.level2 || "", b);
            a.sendHit(null, [
                ["hitType", ["click"]]
            ]);
            a.setContext("click", void 0)
        }
    };
    window.ATInternet.Tracker.addPlugin("Clicks");
}).call(window);;
(function() {
    var dfltPluginCfg = { "clientSideMode": "required", "userIdCookieDuration": 397, "userIdExpirationMode": "fixed", "info": true };
    var dfltGlobalCfg = {};
    window.ATInternet.Tracker.Plugins.ClientSideUserId = function(a) {
        var b = {},
            k = void 0,
            f = null;
        a.configPlugin("ClientSideUserId", dfltPluginCfg || {}, function(a) { b = a });
        var l = function() {
                k = a.getContext("userIdentifier");
                a.exec("Cookies", "get", ["atuserid"], function(a) { f = a })
            },
            h = function(b, c) {
                a.setParam("idclient", b, { permanent: !0, hitType: ["all"] });
                g(b, c)
            },
            g = function(c, d) {
                if ("relative" === b.userIdExpirationMode || "fixed" === b.userIdExpirationMode && null === f) {
                    var g = new Date;
                    g.setTime(g.getTime() + 864E5 * b.userIdCookieDuration);
                    a.exec("Cookies", "set", ["atuserid", c, { end: g, path: "/" }]);
                    a.exec("Cookies", "get", ["atuserid", !0], function(b) { d || c === b || a.setParam("idclient", c + "-NO", { permanent: !0, hitType: ["all"] }) })
                }
            },
            c = function() { var a = !1; if ("required" === b.clientSideMode) { var c = navigator.userAgent; if (/Safari/.test(c) && !/Chrome/.test(c) || /iPhone|iPod|iPad/.test(c)) a = !0 } else "always" === b.clientSideMode && (a = !0); return a };
        a.plugins.waitForDependencies(["Cookies"], function() {
            l();
            var e = "";
            if (c()) {
                var d = !1;
                "undefined" !== typeof k ? (e = k, d = !0) :
                    e = null !== f ? f : ATInternet.Utils.genGuid(13);
                h(e, d)
            }
            a.emit("ClientSideUserId:Ready", { lvl: "INFO", details: { clientSideMode: b.clientSideMode, userIdFromContext: k, userIdFromCookie: f, userId: e } })
        });
        a.clientSideUserId = {};
        a.clientSideUserId.set = function(a) { c() && h(a, !0) }
    };
    window.ATInternet.Tracker.addPlugin("ClientSideUserId");
}).call(window);;
(function() {
    var dfltPluginCfg = { "domainAttribution": true, "info": true };
    var dfltGlobalCfg = { "redirectionLifetime": 30 };
    window.ATInternet.Tracker.Plugins.ContextVariables = function(a) {
        var b = "",
            k = null,
            f = "",
            l = "",
            h = {};
        a.configPlugin("ContextVariables", dfltPluginCfg || {}, function(a) { h = a });
        a.setConfig("redirectionLifetime", dfltGlobalCfg.redirectionLifetime, !0);
        var g = function(b, c, d) {
                var e = null;
                a.plugins.exec(b, c, d, function(a) { e = a });
                return e
            },
            c = function(a, b) { return g("Utils", a, b) },
            e = function(b, c) {
                var d = null;
                a.plugins.exec("Cookies", b, c, function(a) { d = a });
                return d
            },
            d = function() {
                a.setParam("hl", function() {
                    var a = new Date;
                    return a.getHours() +
                        "x" + a.getMinutes() + "x" + a.getSeconds()
                }, { permanent: !0, hitType: ["all"] })
            },
            n = function(a) {
                var c = "",
                    c = "acc_dir" === b ? "" : null != b ? b : "acc_dir" === k ? "" : k ? k : a.referrer;
                return c.replace(/[<>]/g, "").substring(0, 1600).replace(/&/g, "$")
            };
        a.plugins.waitForDependencies(["Cookies", "Utils"], function() {
            f = "set" + (h.domainAttribution ? "" : "Private");
            l = "get" + (h.domainAttribution ? "" : "Private");
            var g = c("getLocation", []);
            b = c("getQueryStringValue", ["xtref", g]);
            void 0 === b && (b = "");
            if (a.getConfig("redirect")) {
                var g = c("getDocumentLevel", []),
                    g = null != b ? b : g.referrer || "acc_dir",
                    t;
                if (t = g) {
                    t = { path: "/", end: a.getConfig("redirectionLifetime") };
                    var r = e(l, [
                        ["atredir"]
                    ]);
                    null !== r ? t = !("object" !== typeof r || r instanceof Array) : (e(f, ["atredir", {}, t]), t = !0)
                }
                t && e(f, [
                    ["atredir", "ref"], g
                ])
            } else {
                k = e(l, [
                    ["atredir", "ref"]
                ]);
                e("del", [
                    ["atredir", "ref"]
                ]);
                a.setParam("vtag", a.version, { permanent: !0, hitType: ["all"] });
                a.setParam("ptag", "js", { permanent: !0, hitType: ["all"] });
                g = "";
                try {
                    g += window.screen.width + "x" + window.screen.height + "x" + window.screen.pixelDepth + "x" +
                        window.screen.colorDepth
                } catch (p) {}
                a.setParam("r", g, { permanent: !0, hitType: ["all"] });
                g = "";
                window.innerWidth ? g += window.innerWidth + "x" + window.innerHeight : document.body.offsetWidth && (g += document.body.offsetWidth + "x" + document.body.offsetHeight);
                a.setParam("re", g, { permanent: !0, hitType: ["all"] });
                d();
                a.setParam("lng", navigator.language || navigator.userLanguage, { permanent: !0, hitType: ["all"] });
                g = window.ATInternet.Utils.genGuid(13);
                a.setParam("idp", g, { permanent: !0, hitType: ["page", "clickzone"] });
                a.setParam("jv",
                    navigator.javaEnabled() ? "1" : "0", { hitType: ["page"] });
                g = c("getDocumentLevel", []);
                a.setParam("ref", n(g), { permanent: !0, last: !0, hitType: ["page"] })
            }
            a.emit("ContextVariables:Ready", { lvl: "INFO" })
        })
    };
    window.ATInternet.Tracker.addPlugin("ContextVariables");
}).call(window);;
(function() {
    var dfltPluginCfg = { "info": false };
    var dfltGlobalCfg = {};
    window.ATInternet.Tracker.Plugins.Cookies = function(a) {
        var b = {},
            k = {
                _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                encode: function(a) {
                    var b = "",
                        c, d, e, g, f, h, n = 0;
                    for (a = k._utf8_encode(a); n < a.length;) c = a.charCodeAt(n++), d = a.charCodeAt(n++), e = a.charCodeAt(n++), g = c >> 2, c = (c & 3) << 4 | d >> 4, f = (d & 15) << 2 | e >> 6, h = e & 63, isNaN(d) ? f = h = 64 : isNaN(e) && (h = 64), b = b + this._keyStr.charAt(g) + this._keyStr.charAt(c) + this._keyStr.charAt(f) + this._keyStr.charAt(h);
                    return b
                },
                decode: function(a) {
                    var b = "",
                        c, d, e,
                        g, f, h = 0;
                    for (a = a.replace(/[^A-Za-z0-9\+\/\=]/g, ""); h < a.length;) c = this._keyStr.indexOf(a.charAt(h++)), d = this._keyStr.indexOf(a.charAt(h++)), g = this._keyStr.indexOf(a.charAt(h++)), f = this._keyStr.indexOf(a.charAt(h++)), c = c << 2 | d >> 4, d = (d & 15) << 4 | g >> 2, e = (g & 3) << 6 | f, b += String.fromCharCode(c), 64 != g && (b += String.fromCharCode(d)), 64 != f && (b += String.fromCharCode(e));
                    return b = k._utf8_decode(b)
                },
                _utf8_encode: function(a) {
                    a = a.replace(/\r\n/g, "\n");
                    for (var b = "", c = 0; c < a.length; c++) {
                        var d = a.charCodeAt(c);
                        128 > d ? b += String.fromCharCode(d) :
                            (127 < d && 2048 > d ? b += String.fromCharCode(d >> 6 | 192) : (b += String.fromCharCode(d >> 12 | 224), b += String.fromCharCode(d >> 6 & 63 | 128)), b += String.fromCharCode(d & 63 | 128))
                    }
                    return b
                },
                _utf8_decode: function(a) { for (var b = "", c = 0, d, e, g; c < a.length;) d = a.charCodeAt(c), 128 > d ? (b += String.fromCharCode(d), c++) : 191 < d && 224 > d ? (e = a.charCodeAt(c + 1), b += String.fromCharCode((d & 31) << 6 | e & 63), c += 2) : (e = a.charCodeAt(c + 1), g = a.charCodeAt(c + 2), b += String.fromCharCode((d & 15) << 12 | (e & 63) << 6 | g & 63), c += 3); return b }
            },
            f = this.getCookie = function(b) {
                return !a.getConfig("disableCookie") &&
                    b && "string" === typeof b && (b = RegExp("(?:^| )" + b + "=([^;]+)").exec(document.cookie) || null) ? (b = b[1], b = a.getConfig("base64Storage") ? k.decode(b) : decodeURIComponent(b), b) : null
            },
            l = this.setCookie = function(b, c, d) {
                if (!a.getConfig("disableCookie") && b && "string" === typeof b && "string" === typeof c) {
                    var e = a.getConfig("cookieDomain");
                    b += "=";
                    c = a.getConfig("base64Storage") ? k.encode(c) : encodeURIComponent(c);
                    c = b + c;
                    b = !1;
                    if (d) {
                        b = d.secure;
                        var g = d.end,
                            f = d.domain;
                        d = d.path;
                        c += g ? "function" === typeof g.toGMTString ? ";expires=" + g.toGMTString() :
                            "number" === typeof g ? ";max-age=" + g.toString() : "" : "";
                        c = c + (e || f ? ";domain=" + (f ? f : e) : "") + (d && "string" === typeof d ? ";path=" + d : "")
                    }
                    e = a.getConfig("cookieSecure") || b;
                    c += e && "boolean" === typeof e ? ";secure" : "";
                    document.cookie = c;
                    return !0
                }
                return null
            },
            h = function(a) {
                var b = null;
                (a = f(a)) && (b = ATInternet.Utils.jsonParse(a));
                return b
            },
            g = function(a) { return l(a.name, ATInternet.Utils.jsonSerialize(a), a.options) ? a : null },
            c = function(a, c, d) {
                var e = null;
                if (!d && b[a]) e = b[a];
                else if (e = h(a)) e.options.session && g(e), b[a] = e;
                return e ?
                    c ? (a = null, !e || "object" !== typeof e.val || e.val instanceof Array || void 0 === e.val[c] || (a = e.val[c]), a) : e.val : null
            },
            e = function(a, c, d, e) {
                var f = null;
                if (c) { if (f = h(a)) e = f, !e || "object" !== typeof e.val || e.val instanceof Array ? f = null : (e.val[c] = d, f = e), f && (f = g(f)) } else c = e = e || {}, e = {}, e.name = a, e.val = d, c.session && "number" === typeof c.session && (c.end = c.session), e.options = c, f = g(e);
                f && (b[a] = f);
                return f ? f.val : null
            },
            d = function(a, c) { c ? e(a, c, void 0) : (b[a] = void 0, l(a, "", { end: 0 })) },
            n = this.get = function(a, b) {
                b = b || !1;
                return a instanceof
                Array && 2 === a.length ? c(a[0], a[1], b) : c(a, void 0, b)
            };
        this.getPrivate = function(b, c) {
            c = c || !1;
            b instanceof Array ? b[0] += a.getConfig("site") : b += a.getConfig("site");
            return n(b, c)
        };
        var q = this.set = function(a, b, c) { return a instanceof Array ? e(a[0], a[1], b) : e(a, null, b, c) };
        this.setPrivate = function(b, c, d) { b instanceof Array ? b[0] += a.getConfig("site") : b += a.getConfig("site"); return q(b, c, d) };
        var t = this.del = function(a) { return a instanceof Array ? d(a[0], a[1]) : d(a) };
        this.delPrivate = function(b) {
            b instanceof Array ? b[0] += a.getConfig("site") :
                b += a.getConfig("site");
            return t(b)
        };
        this.cacheInvalidation = function() { b = {} }
    };
    window.ATInternet.Tracker.addPlugin("Cookies");
}).call(window);;
(function() {
    var dfltPluginCfg = { "lifetime": 182, "domainAttribution": true, "info": true };
    var dfltGlobalCfg = { "redirectionLifetime": 30 };
    window.ATInternet.Tracker.Plugins.IdentifiedVisitor = function(a) {
        var b = null,
            k = null,
            f = null,
            l = null,
            h = "",
            g = "",
            c = null,
            e = null,
            d = "",
            n = "",
            q = {};
        a.configPlugin("IdentifiedVisitor", dfltPluginCfg || {}, function(a) { q = a });
        a.setConfig("redirectionLifetime", dfltGlobalCfg.redirectionLifetime, !0);
        var t = function(b, c, d) {
                var e = null;
                a.plugins.exec(b, c, d, function(a) { e = a });
                return e
            },
            r = function(a, b) { return t("Utils", a, b) },
            p = function(b, c) {
                var d = null;
                a.plugins.exec("Cookies", b, c, function(a) { d = a });
                return d
            },
            v = function(a, b) {
                var c =
                    p(n, [
                        [a]
                    ]);
                if (null !== c) return !("object" !== typeof c || c instanceof Array);
                p(d, [a, {}, b]);
                return !0
            },
            y = function() {
                var d = function(a, b) { /-/.test(b) ? (a.category = b.split("-")[0], a.id = b.split("-")[1]) : a.id = b },
                    n = { category: "", id: "" };
                d(n, g || e);
                var l = { category: "", id: "" };
                d(l, h || c);
                l.id ? (l.category && s("ac", l.category), s("at", l.id)) : b && a.setParam("at", b, { hitType: ["all"], permanent: !0 });
                n.id ? (n.category && s("ac", n.category), s("an", n.id)) : k && a.setParam("anc", f + "-" + k, { hitType: ["all"], permanent: !0 })
            },
            A = function(a, b) {
                v("atidvisitor", { path: "/", session: 86400 * q.lifetime }) && p(d, [
                    ["atidvisitor", a], b
                ])
            },
            s = function(b, c) {
                a.setParam(b, c, { hitType: ["all"], permanent: !0 });
                A(b, c)
            };
        a.plugins.waitForDependencies(["Cookies", "Utils"], function() {
            d = "set" + (q.domainAttribution ? "" : "Private");
            n = "get" + (q.domainAttribution ? "" : "Private");
            var t = r("getLocation", []);
            h = r("getQueryStringValue", ["xtat", t]);
            g = r("getQueryStringValue", ["xtan", t]);
            a.getConfig("redirect") ? (h || g) && v("atredir", { path: "/", end: a.getConfig("redirectionLifetime") }) && (g && p(d, [
                ["atredir",
                    "an"
                ], g
            ]), h && p(d, [
                ["atredir", "at"], h
            ])) : (c = p(n, [
                ["atredir", "at"]
            ]), e = p(n, [
                ["atredir", "an"]
            ]), p("del", [
                ["atredir", "at"]
            ]), p("del", [
                ["atredir", "an"]
            ]), b = p(n, [
                ["atidvisitor", "at"]
            ]), k = p(n, [
                ["atidvisitor", "an"]
            ]), f = p(n, [
                ["atidvisitor", "ac"]
            ]), l = p(n, [
                ["atidvisitor", "vrn"]
            ]), y(), t = "-" + a.getConfig("site") + "-", RegExp(t).test(l) || (l = (l || "") + t, A("vrn", l), t = a.getContext("page") || {}, t.vrn = 1, a.setContext("page", t)));
            a.emit("IdentifiedVisitor:Ready", {
                lvl: "INFO",
                details: {
                    cookieRedirectTextual: c,
                    cookieRedirectNumeric: e,
                    cookieTextual: b,
                    cookieNumeric: k,
                    cookieCategory: f,
                    cookieVrn: l
                }
            })
        });
        a.identifiedVisitor = {};
        a.identifiedVisitor.set = this.set = function(a) {
            var b = a.id;
            a = a.category;
            "number" === typeof b ? s("an", b.toString()) : s("at", b);
            "undefined" !== typeof a && s("ac", a)
        };
        a.identifiedVisitor.unset = this.unset = function() {
            for (var b = ["an", "at", "ac"], c = 0; c < b.length; c++) a.exec("Cookies", "set", [
                ["atidvisitor", b[c], { path: "/" }], void 0
            ]), a.delParam(b[c]);
            a.delParam("anc")
        }
    };
    window.ATInternet.Tracker.addPlugin("IdentifiedVisitor");
}).call(window);;
(function() {
    var dfltPluginCfg = { "storageCapacity": 1, "storageMode": "required", "info": true };
    var dfltGlobalCfg = {};
    window.ATInternet.Tracker.Plugins.Offline = function(a) {
        var b = {};
        a.configPlugin("Offline", dfltPluginCfg || {}, function(a) { b = a });
        var k = function() {
                var a = localStorage.getItem("ATOffline"),
                    b = { hits: [], length: 0 };
                if (a) {
                    var c = ATInternet.Utils.jsonParse(a) || { hits: [] };
                    b.hits = c.hits;
                    b.length = a.length
                }
                return b
            },
            f = function(a) { try { localStorage.setItem("ATOffline", ATInternet.Utils.jsonSerialize(a)) } catch (b) {} },
            l = function() { return k().hits },
            h = function(b) {
                if (0 < b.length) {
                    var c = b.shift(),
                        k = l();
                    k && k[0] === c && (k.shift(), f({ hits: k }));
                    b = k;
                    a.onTrigger("Tracker:Hit:Sent:Ok", function() { h(b) }, !0);
                    a.sendUrl(c)
                } else g(!1)
            },
            g = function(a) {
                var b = l();
                0 < b.length && (h(b), a && c())
            },
            c = function() {
                a.builder.sendUrl = function(a) {
                    if (a) {
                        a = a.split(/&ref=\.*/i);
                        var c = "&cn=offline&olt=" + (new Date).getTime();
                        a = a[0] + c + "&ref=" + (a[1] || "")
                    }
                    var c = k(),
                        g = c.length || 11,
                        h = ATInternet.Utils.jsonSerialize(a).length;
                    4 * (g + h) > 1048576 * b.storageCapacity && c.hits.shift();
                    c.hits.push(a);
                    f({ hits: c.hits })
                }
            };
        a.offline = {};
        a.offline.getLength = function() { return 4 * k().length };
        a.offline.remove =
            function() { f({ hits: [] }) };
        a.offline.get = l;
        a.offline.send = function() { g(!1) };
        (function() {
            var e;
            try {
                var d = window.localStorage;
                d.setItem("__storage_test__", "__storage_test__");
                d.removeItem("__storage_test__");
                e = !0
            } catch (f) { e = !1 }
            d = navigator.onLine;
            if (e && "undefined" !== typeof d) { var h = b.storageMode; "required" === h ? d ? g(!0) : c() : "always" === h && c() }
            a.emit("Offline:Ready", { lvl: "INFO", details: { isLocalStorageAvailable: e, storageMode: b.storageMode, isOnline: d } })
        })()
    };
    window.ATInternet.Tracker.addPlugin("Offline");
}).call(window);;
(function() {
    var dfltPluginCfg = { "info": true };
    var dfltGlobalCfg = {};
    window.ATInternet.Tracker.Plugins.Page = function(a) {
        var b = ["pageId", "chapterLabel", "update"],
            k = ["pid", "pchap", "pidt"],
            f = ["page", "site"],
            l = ["f", "x"],
            h = function(b) {
                var c = b.name;
                a.exec("Utils", "manageChapters", [b, "chapter", 3], function(a) { c = a + (c ? c : "") });
                return c
            },
            g = function(a, b, c) { b ? a = b : a || "undefined" === typeof c || (a = c); return a },
            c = function(a, b, c) { b.hasOwnProperty(c) && (a[c] = g(a[c], b[c])) },
            e = function(b) {
                if (!ATInternet.Utils.isPreview() || a.getConfig("preview")) ATInternet.Utils.isPrerender(function(a) { b(a) }) ||
                    b()
            },
            d = function(b, c, d) {
                if (c)
                    for (var e = 0; e < f.length; e++)
                        if (c.hasOwnProperty(f[e]) && c[f[e]])
                            for (var g in c[f[e]]) c[f[e]].hasOwnProperty(g) && (d ? b[l[e] + g] = c[f[e]][g] : a.setParam(l[e] + g, c[f[e]][g]))
            },
            n = function(c, d, e) { if (d) { a.exec("Utils", "manageChapters", [d, "chapter", 3], function(a) { a && (d.chapterLabel = a.replace(/::$/gi, "")) }); for (var f = 0; f < k.length; f++) d.hasOwnProperty(b[f]) && (e ? c[k[f]] = d[b[f]] : a.setParam(k[f], d[b[f]])) } },
            q = function(b, c, d) {
                if (c && c.keywords instanceof Array) {
                    var e = c.keywords.length;
                    if (0 <
                        e) {
                        for (var f = "", g = 0; g < e; g++) f += "[" + c.keywords[g] + "]" + (g < e - 1 ? "|" : "");
                        d ? b.tag = f : a.setParam("tag", f)
                    }
                }
            },
            t = function(b, c, d) {
                if (c) {
                    var e, f = function(a) { return a ? a : "0" };
                    e = "" + (f(c.category1) + "-");
                    e += f(c.category2) + "-";
                    e += f(c.category3);
                    d ? b.ptype = e : a.setParam("ptype", e)
                }
            },
            r = function(b, c, e) {
                if (c)
                    for (var d in c) c.hasOwnProperty(d) && "undefined" !== typeof c[d] && (e ? b[d] = c[d] : a.setParam(d, c[d]))
            };
        a.customVars = this.customVars = {};
        a.customVars.set = this.customVars.set = function(b) {
            var c = a.getContext("page") || {},
                d = c.customVars;
            if (d) {
                if (b)
                    for (var e in b) b.hasOwnProperty(e) && (d[e] = ATInternet.Utils.completeFstLevelObj(d[e], b[e], !0))
            } else d = b;
            c.customVars = d;
            a.setContext("page", c)
        };
        a.dynamicLabel = this.dynamicLabel = {};
        a.dynamicLabel.set = this.dynamicLabel.set = function(b) {
            var c = a.getContext("page") || {};
            c.dynamicLabel = ATInternet.Utils.completeFstLevelObj(c.dynamicLabel, b, !0);
            a.setContext("page", c)
        };
        a.tags = this.tags = {};
        a.tags.set = this.tags.set = function(b) {
            var c = a.getContext("page") || {};
            c.tags = ATInternet.Utils.completeFstLevelObj(c.tags,
                b, !0);
            a.setContext("page", c)
        };
        a.customTreeStructure = this.customTreeStructure = {};
        a.customTreeStructure.set = this.customTreeStructure.set = function(b) {
            var c = a.getContext("page") || {};
            c.customTreeStructure = ATInternet.Utils.completeFstLevelObj(c.customTreeStructure, b, !0);
            a.setContext("page", c)
        };
        a.page = {};
        a.page.reset = this.reset = function() { a.setContext("page", void 0) };
        a.page.set = this.set = function(b) {
            a.dispatchSubscribe("page");
            var d = a.getContext("page") || {};
            d.name = g(d.name, b.name, "");
            d.level2 = g(d.level2,
                b.level2, "");
            c(d, b, "chapter1");
            c(d, b, "chapter2");
            c(d, b, "chapter3");
            d.customObject = ATInternet.Utils.completeFstLevelObj(d.customObject, b.customObject, !0);
            a.setContext("page", d)
        };
        a.page.send = this.send = function(b) {
            var f = { p: h(b), s2: b.level2 || "" },
                l = !0,
                k = b.customObject;
            if (k) {
                var s = a.getParam("stc", !0);
                if (s && s.options.permanent) {
                    var u = s ? s.options.hitType : [],
                        C = ATInternet.Utils.arrayIndexOf;
                    if (-1 != C(u, "page") || -1 != C(u, "all")) k = ATInternet.Utils.completeFstLevelObj(s.value || {}, k, !0)
                }
                a.exec("Utils", "customObjectToString", [k], function(a) { f.stc = a })
            }
            k = a.getContext("page") || {};
            k.vrn && (f.vrn = k.vrn, k.vrn = void 0, a.setContext("page", k));
            s = a.getContext("InternalSearch") || {};
            "undefined" != typeof s.keyword && (f.mc = ATInternet.Utils.cloneSimpleObject(s.keyword), "undefined" != typeof s.resultPageNumber && (f.np = ATInternet.Utils.cloneSimpleObject(s.resultPageNumber)), a.setContext("InternalSearch", void 0));
            ATInternet.Utils.isPreview() && a.getConfig("preview") && (f.pvw = 1);
            d(f, b.customVars, !0);
            n(f, b.dynamicLabel, !0);
            q(f, b.tags, !0);
            t(f, b.customTreeStructure, !0);
            s = a.getContext("campaigns") || {};
            r(f, s, !0);
            a.setContext("campaigns", void 0);
            a.exec("TechClicks", "manageClick", [b.elem], function(a) { l = a });
            e(function() { a.sendHit(f) });
            k.name = g(k.name, b.name, "");
            k.level2 = g(k.level2, b.level2, "");
            c(k, b, "chapter1");
            c(k, b, "chapter2");
            c(k, b, "chapter3");
            a.setContext("page", k);
            return l
        };
        a.page.onDispatch = this.onDispatch = function() {
            var b = a.getContext("page") || {},
                c = a.getContext("InternalSearch") || {};
            a.setParam("p", h(b));
            a.setParam("s2", b.level2 || "");
            b.vrn && (a.setParam("vrn",
                b.vrn), b.vrn = void 0, a.setContext("page", b));
            "undefined" != typeof c.keyword && (a.setParam("mc", ATInternet.Utils.cloneSimpleObject(c.keyword)), "undefined" != typeof c.resultPageNumber && a.setParam("np", ATInternet.Utils.cloneSimpleObject(c.resultPageNumber)), a.setContext("InternalSearch", void 0));
            ATInternet.Utils.isPreview() && a.getConfig("preview") && a.setParam("pvw", 1);
            d(null, b.customVars, !1);
            n(null, b.dynamicLabel, !1);
            q(null, b.tags, !1);
            t(null, b.customTreeStructure, !1);
            c = a.getContext("campaigns") || {};
            r(null,
                c, !1);
            a.setContext("campaigns", void 0);
            var b = b.customObject,
                f = [
                    ["hitType", ["page"]]
                ];
            if (b)
                if (c = a.getParam("stc", !0)) {
                    var g = c.options.hitType || [],
                        k = ATInternet.Utils.arrayIndexOf,
                        k = -1 != k(g, "page") || -1 != k(g, "all"),
                        g = c.options.permanent;
                    k ? (k = ATInternet.Utils.cloneSimpleObject(c), k.value = ATInternet.Utils.completeFstLevelObj(k.value || {}, b, !0), a.setParam("stc", k.value, { encode: !0 }), e(function() { a.sendHit(null, f) }), g && a.setParam("stc", c.value, c.options)) : (a.setParam("stc", b, { encode: !0 }), e(function() {
                        a.sendHit(null,
                            f)
                    }), a.setParam("stc", c.value, c.options))
                } else a.setParam("stc", b, { encode: !0 }), e(function() { a.sendHit(null, f) });
            else e(function() { a.sendHit(null, f) })
        }
    };
    window.ATInternet.Tracker.addPlugin("Page");
}).call(window);;
(function() {
    var dfltPluginCfg = { "clicksAutoManagementEnabled": true, "clicksAutoManagementTimeout": 500, "info": false };
    var dfltGlobalCfg = {};
    window.ATInternet.Tracker.Plugins.TechClicks = function(a) {
        var b, k;
        a.configPlugin("TechClicks", dfltPluginCfg || {}, function(a) {
            b = a.clicksAutoManagementEnabled;
            k = a.clicksAutoManagementTimeout
        });
        this.deactivateAutoManagement = function() { b = !1 };
        var f = function(a) {
                switch (a.target) {
                    case "_top":
                        window.top.location.href = a.url;
                        break;
                    case "_parent":
                        window.parent.location.href = a.url;
                        break;
                    default:
                        window.location.href = a.url
                }
            },
            l = function(a) {
                var b = a.timeout;
                a.mailto ? setTimeout(function() { window.location.href = a.mailto },
                    b) : a.form ? setTimeout(function() { a.form.submit() }, b) : a.url && setTimeout(function() { f({ url: a.url, target: a.target }) }, b)
            },
            h = function(b) {
                for (var c, e = "_self", g = b.timeoutonly; b;) {
                    if (b.href && 0 === b.href.indexOf("http")) {
                        c = b.href.split('"').join('\\"');
                        e = b.target ? b.target : e;
                        break
                    }
                    b = b.parentNode
                }
                if (c) {
                    if (!g) a.onTrigger("Tracker:Hit:Sent:Ok", function() { f({ url: c, target: e }) });
                    l({ url: c, target: e, timeout: k })
                }
            },
            g = function(b) {
                var c = b;
                for (b = c.timeoutonly; c && "FORM" !== c.nodeName;) c = c.parentNode;
                if (c) {
                    if (!b) a.onTrigger("Tracker:Hit:Sent:Ok",
                        function() { c.submit() });
                    l({ form: c, timeout: k })
                }
            },
            c = function(b) {
                var c = b;
                for (b = c.timeoutonly; c && !(c.href && 0 <= c.href.indexOf("mailto:"));) c = c.parentNode;
                if (c) {
                    if (!b) a.onTrigger("Tracker:Hit:Sent:Ok", function() { window.location.href = c.href });
                    l({ mailto: c.href, timeout: k })
                }
            },
            e = function(a) {
                for (; a;) {
                    if (a.href) { if (0 <= a.href.indexOf("mailto:")) return "mailto"; if (0 === a.href.indexOf("http")) return "redirection" } else if ("FORM" === a.nodeName) return "form";
                    a = a.parentNode
                }
                return !1
            };
        this.manageClick = function(a, f) {
            if (b &&
                a) {
                var l;
                a: {
                    for (l = a; l;) {
                        if ("function" === typeof l.getAttribute && ("_blank" === l.getAttribute("target") || "no" === l.getAttribute("data-atclickmanagement"))) { l = !0; break a }
                        l = l.parentNode
                    }
                    l = a;
                    for (var k = window.location.href, r; l;) {
                        if ((r = l.href) && 0 < r.indexOf("#") && k.substring(0, 0 < k.indexOf("#") ? k.indexOf("#") : k.length) === r.substring(0, r.indexOf("#"))) { l = !0; break a }
                        l = l.parentNode
                    }
                    l = !1
                }
                k = e(a);
                if (!l && k) {
                    switch (k) {
                        case "mailto":
                            c(a);
                            break;
                        case "form":
                            g(a);
                            break;
                        case "redirection":
                            h(a);
                            break;
                        default:
                            return !0
                    }
                    f && !f.defaultPrevented &&
                        f.preventDefault();
                    return !1
                }
            }
            return !0
        }
    };
    window.ATInternet.Tracker.addPlugin("TechClicks");
}).call(window);;
(function() {
    var dfltPluginCfg = { "info": false };
    var dfltGlobalCfg = {};
    window.ATInternet.Tracker.Plugins.Utils = function(a) {
        var b = this,
            k = {};
        b.getQueryStringValue = function(a, b) {
            var f = window.ATInternet.Utils.hashcode(b).toString();
            if (!k[f]) {
                k[f] = {};
                var c = RegExp("[&#?]{1}([^&=#?]*)=([^&#]*)?", "g"),
                    e = c.exec(b);
                if (null !== e)
                    for (; null !== e;) k[f][e[1]] = e[2], e = c.exec(b)
            }
            return k[f].hasOwnProperty(a) ? k[f][a] : null
        };
        b.customObjectToString = function(a) { return encodeURIComponent(window.ATInternet.Utils.jsonSerialize(a)) };
        b.manageChapters = function(b, f, g) {
            var c = a.getConfig("ignoreEmptyChapterValue"),
                e = "";
            if (b) {
                g = parseInt(g, 10);
                for (var d = 1; d < g + 1; d++) var n = b[f + d] || "",
                    e = c ? e + (n ? n + "::" : "") : e + (b.hasOwnProperty(f + d) ? n + "::" : "")
            }
            return e
        };
        b.getDocumentLevel = function() {
            var b = a.getConfig("documentLevel");
            if (0 > b.indexOf(".")) return window[b] || document;
            b = b.split(".");
            return window[b[0]][b[1]] || document
        };
        b.getLocation = function() { return b.getDocumentLevel().location.href };
        a.dispatchIndex = {};
        a.dispatchStack = [];
        a.dispatchEventFor = {};
        var f = 0;
        a.dispatchSubscribe = function(b) {
            return a.dispatchIndex[b] ? !1 : (a.dispatchStack.push(b),
                a.dispatchIndex[b] = !0)
        };
        a.dispatchSubscribed = function(b) { return !0 === a.dispatchIndex[b] };
        a.addSpecificDispatchEventFor = function(b) { return a.dispatchEventFor[b] ? !1 : (a.dispatchEventFor[b] = !0, f++, !0) };
        a.processSpecificDispatchEventFor = function(b) { a.dispatchEventFor[b] && (a.dispatchEventFor[b] = !1, f--, 0 === f && (a.dispatchEventFor = {}, a.emit("Tracker:Plugin:SpecificEvent:Exec:Complete", { lvl: "INFO" }))) };
        a.dispatch = function() {
            var b = function() {
                    for (; 0 < a.dispatchStack.length;) {
                        var b = a.dispatchStack.pop();
                        a[b].onDispatch()
                    }
                    a.dispatchIndex = {};
                    a.delContext(void 0, "customObject")
                },
                h = function() {
                    if (a.plugins.isExecWaitingLazyloading()) a.onTrigger("Tracker:Plugin:Lazyload:Exec:Complete", function() { b() }, !0);
                    else b()
                };
            if (0 === f) h();
            else a.onTrigger("Tracker:Plugin:SpecificEvent:Exec:Complete", function() { h() }, !0)
        };
        a.dispatchRedirect = function(b) {
            var f = !0;
            b && b.elem && (b.elem.timeoutonly = !0, a.plugins.exec("TechClicks", "manageClick", [b.elem], function(a) { f = a }));
            a.dispatch();
            return f
        }
    };
    window.ATInternet.Tracker.addPlugin("Utils");
}).call(window);
if (typeof window.ATInternet.onTrackerLoad === 'function') { window.ATInternet.onTrackerLoad(); }