(function() {
  angular
  .module('purple-wind.components')
  .directive('tagButton', exec);

  function exec($tag) {
    return {
      restrict: 'A',
      link: function($scope, elem, attrs) {
        elem.bind('click', function() {
          // console.log('Tag-button directive:', attrs.tagButton);
          $tag.sendClickBouton(attrs.tagButton);
        });
      }
    };
  }

})();