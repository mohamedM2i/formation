(function() {
    angular
        .module('purple-wind.components')
        .service('$tag', svc);

    function svc($storage, tagPage, tagButton) {

        // Information du device mobile
        var device = null;
        var isMobile = false;

        // Informations de site AtInternet
        var tagInformationSite = {
            log: 'logc233',
            logSSL: 'logs1233',
            secure: true,
            ignoreEmptyChapterValue: true,
            domain: 'xiti.com'
        };

        // Informations global de site
        var tagInformationGlobal = {
            1: '', // Réseau: BP, CE ou BRED
            2: '', // Géolocalisation: 0=non-géolocalisé, 1=géolocalisé
            3: '', // ID OneSignal du device
            4: '', // OS du device
            5: '' // Marque et modèle du device
        };

        // Variable tagATInternet
        var tagATInternet = null;

        // Fonction qui retourne les informtions de site
        function getTagInformationSite() {
            /* jshint ignore:start */
            if (typeof tagInformationSite.site === 'undefined') { tagInformationSite.site = $storage.get('tags') === null ? '585413' : $storage.get('tags').atinternet; }
            /* jshint ignore:end */
            return tagInformationSite;
        }

        function getTagATInternet() {
            if (tagATInternet === null) { tagATInternet = new ATInternet.Tracker.Tag(getTagInformationSite()); }
            return tagATInternet;
        }

        // Fonction qui retourne les informations de tag par rapport à un nom de page
        function findTagInformationPage(nomPage) {
            return tagPage[nomPage];
        }

        // Fonction qui retourne les informations de tag par rapport à un click
        function findTagInformationClick(nomClick) {
            return tagButton[nomClick];
        }

        // Fonction qui enregistre une personne connectée
        function lSetUser(idClient) {
            // Récupération du tag ATInternet
            var lTagATInternet = getTagATInternet();

            // Positionnement des infos user
            lTagATInternet.identifiedVisitor.set({
                id: idClient,
                category: '1'
            });
        }

        // Fonction qui retire une personne connectée
        function lUnsetUser() {
            // Récupération du tag ATInternet
            var lTagATInternet = getTagATInternet();

            // Retrait des infos user
            lTagATInternet.identifiedVisitor.unset();
        }

        // Fonction d'envoi du tag de page à AT Internet
        function lAddGlobalInformation() {
            var reseau = $storage.get('reseau');
            var settings = $storage.get('settings');
            var OneSignalUserID = $storage.get('OneSignalUserID');

            // Indicateur global de site: Réseau (BP, CE ou BRED)
            tagInformationGlobal[1] = reseau === null ? '' : reseau.toUpperCase();

            if (isMobile) {
                // Indicateur global de site: Géolocalisation (0=non-géolocalisé, 1=géolocalisé)
                tagInformationGlobal[2] = (settings === null || settings.geolocalisation === null) ? '' : settings.geolocalisation;

                // Indicateur global de site: ID OneSignal du device
                tagInformationGlobal[3] = OneSignalUserID === null ? '' : OneSignalUserID;
            }
        }

        function lSendTagPageGo(tagInfoPage, detailPage) {
            // Récupération du tag ATInternet
            var lTagATInternet = getTagATInternet();

            // réinitilisation de la page
            lTagATInternet.page.reset();

            lTagATInternet.customVars.set({
                site: tagInformationGlobal
            });

            if (typeof detailPage !== 'undefined' && detailPage !== null) {
                lTagATInternet.customVars.set({
                    page: detailPage
                });
            }
            // Indicateurs de page
            lTagATInternet.page.set(tagInfoPage);

            // Envoi du Tag AT Internet
            lTagATInternet.dispatch();
        }

        function lSendTagPage(nomPage, tagChapitre, detailPage) {
            // console.log('tagPage: ', nomPage);

            // Récupération des informations de page pour AtInternet
            var tagInfoPage = findTagInformationPage(nomPage);

            // Modification des infos de page si nécessaire
            Object.keys(tagChapitre).forEach(function(key) {
                tagInfoPage[key] = tagChapitre[key];
            });

            if (typeof tagInfoPage !== 'undefined') {
                // Récupération des informations de mobile
                if (device === null) {
                    isMobile = (window.cordova);

                    if (isMobile) {
                        ionic.Platform.ready(function() {
                            // will execute when device is ready, or immediately if the device is already ready.
                            device = ionic.Platform.device();

                            // Indicateur global de site: OS du device
                            tagInformationGlobal[4] = isMobile ? (device.platform.toUpperCase() + ' ' + device.version) : 'web';

                            // Indicateur global de site: Marque et modèle du device
                            tagInformationGlobal[5] = device.manufacturer.toUpperCase() + ' ' + device.model.toUpperCase();
                            $storage.set('device', device);
                            // Autres indicateurs globaux: Réseau, Géolocalisation, ID OneSignal du device
                            lAddGlobalInformation();

                            // Envoi du Tag AT Internet
                            lSendTagPageGo(tagInfoPage, detailPage);
                        });
                    } else {
                        // Pas un mobile (device est un object vide {} par opposition à null)
                        device = {};

                        // Indicateurs globaux: Réseau, Géolocalisation, ID OneSignal du device
                        lAddGlobalInformation();

                        // Envoi du Tag AT Internet
                        lSendTagPageGo(tagInfoPage, detailPage);
                    }
                } else {
                    // Indicateurs globaux: Réseau, Géolocalisation, ID OneSignal du device
                    lAddGlobalInformation();

                    // Envoi du Tag AT Internet
                    lSendTagPageGo(tagInfoPage, detailPage);
                }
            }
        }

        // Fonction d'envoi du tag de click de bouton à AT Internet
        function lSendClickBouton(nomClick) {
            // Récupération des informations de click pour AtInternet
            var tagInfoClick = findTagInformationClick(nomClick);

            // console.log('tagButton: ', nomClick);

            if (typeof tagInfoClick !== 'undefined') {
                // Récupération du tag ATInternet
                var lTagATInternet = getTagATInternet();

                // Insertion de l'élément du DOM
                // tagInfoClick.elem = elementDom;

                // Envoi du tag
                return lTagATInternet.click.send(tagInfoClick);
            } else {
                return null;
            }
        }

        // Fonction d'envoi du tag de click de champs à AT Internet
        function lSendClickChamps(name, type, chapter1, chapter2, chapter3) {
            if (typeof name !== 'undefined') {
                // Récupération du tag ATInternet
                var lTagATInternet = getTagATInternet();

                // Insertion des informations à remonter dans le tag
                var tagInfoChamps = { name: name, type: type };

                tagInfoChamps.chapter1 = typeof chapter1 !== 'undefined' ? chapter1 : '';
                tagInfoChamps.chapter2 = typeof chapter2 !== 'undefined' ? chapter2 : '';
                tagInfoChamps.chapter3 = typeof chapter3 !== 'undefined' ? chapter3 : '';

                // Insertion de l'élément du DOM
                // tagInfoClick.elem = elementDom;

                // Envoi du tag
                return lTagATInternet.click.send(tagInfoChamps);
            } else {
                return null;
            }
        }

        return {
            setUser: lSetUser,
            unsetUser: lUnsetUser,

            sendTagPage: lSendTagPage,

            sendClickBouton: lSendClickBouton,
            sendClickChamps: lSendClickChamps
        }
    }
})();