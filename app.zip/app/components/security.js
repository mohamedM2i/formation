(function() {
    angular
        .module('purple-wind.components')
        .service('$security', svc);

    function svc($requester, $q) {
        function authenticate(login, pwd) {
            var dfd = $q.defer();
            $requester
                .api('authenticate_user', {
                    'username': login,
                    'password': pwd,
                    'rememberMe': true
                })
                .then(function(success) {
                    dfd.resolve(success);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }

        function authenticateWithToken() {
            var dfd = $q.defer();
            $requester
                .api('authenticate_token', {})
                .then(function(success) {
                    dfd.resolve(success);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }
        return {
            'authenticateUser': authenticate,
            'authenticateToken': authenticateWithToken
        }
    }
})();