(function() {

    angular
        .module('purple-wind.components')
        .config(config)
        .service('$storage', storageService);

    function config(localStorageServiceProvider) {
        localStorageServiceProvider
            .setPrefix('purple-wind')
            .setStorageType('localStorage')
            .setNotify(true, true);
    }

    function storageService(localStorageService) {
        function setItem(key, val) {
            return localStorageService.set(key, val);
        }

        function getItem(key) {
            return localStorageService.get(key);
        }

        function removeItem(key) {
            return localStorageService.remove(key);
        }

        function clearAll() {
            return localStorageService.clearAll();
        }
        return {
            'set': setItem,
            'get': getItem,
            'remove': removeItem,
            'clearAll': clearAll
        };
    }

})();