(function() {
    angular
        .module('purple-wind.components')
        .service('$modal', svc);

    function svc($ionicModal) {
        function loadTemplate(url, target, effect) {
            return $ionicModal.fromTemplateUrl(url, {
                scope: target,
                animation: effect
            });
        }

        return {
            load: loadTemplate
        };
    }
})();