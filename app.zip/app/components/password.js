(function() {
    angular
        .module('purple-wind.components')
        .directive('passwordEq', directive);

    function directive($parse) {
        return {
            require: 'ngModel',
            link: function(scope, elem, attrs, ngModel) {
                if (typeof attrs.passwordEq === 'string') {
                    var parser = $parse(attrs.passwordEq),
                        password = parser(scope);
                    // Watch for changes to this input
                    scope.$watch(attrs.ngModel, function(newValue) {
                        if (typeof newValue !== 'undefined') {
                            ngModel.$setValidity(attrs.name, newValue === password.$viewValue);
                        }
                    });
                }

            }
        }
    }
})();