(function() {
    angular
        .module('purple-wind.components')
        .service('$startup', service);

    function service($requester, $storage, $notification, $state, config, urls, lodash, $q) {
        function initServices() {
            var initURL = $requester.buildURL(
                config.env.domain[config.env.target].url,
                urls.init, {
                    version: config.env.domain[config.env.target].api
                });

            var initEndPoint = $requester.buildEndPoint(config.env.domain[config.env.target], initURL);
            return $requester.request(initEndPoint)
                .then(processOneSignalConfig)
                .then(doWhenInitSuccess, doWhenInitError);
        }

        function compareVersions(versionA, versionB) {
            var digitsA = lodash.split(versionA, '.'),
                digitsB = lodash.split(versionB, '.'),
                comparison0 = compare(digitsA[0], digitsB[0]),
                comparison1 = compare(digitsA[1], digitsB[1]);

            if (lodash.eq(versionA, versionB)) {
                return {};
            } else {
                if (comparison0 !== 0) {
                    return {
                        'mustUpdate': true,
                        'mandatory': true
                    };
                }
                if (comparison1 >= 0) {
                    return {
                        'mustUpdate': true,
                        'mandatory': false
                    };
                }
            }
        }

        function compare(itemA, itemB) {
            var _result;
            if (lodash.toNumber(itemA) === lodash.toNumber(itemB)) {
                _result = 0;
            }
            if (lodash.toNumber(itemA) > lodash.toNumber(itemB)) {
                _result = 1;
            }
            if (lodash.toNumber(itemA) < lodash.toNumber(itemB)) {
                _result = -1;
            }
            return _result;
        }

        function processOneSignalConfig(res) {
            var dfd = $q.defer(),
                platform = ionic.Platform.platform(),
                oneSignalID = res.data.oneSignal.onesignalID,
                config = $notification.merge(res.data.oneSignal[platform]);
            res.data.oneSignal = config;
            res.data.oneSignal.oneSignalID = oneSignalID;
            dfd.resolve(res.data);
            return dfd.promise;
        }

        function initNotifications(cfg) {
            var oneSignalConfig = $notification.merge(cfg);
            return $notification.init(oneSignalConfig, $notification.handle);
        }

        function doWhenInitSuccess(res) {
            $storage.set('endpoints', res.endpoints);
            $storage.set('oneSignal', res.oneSignal);
            $storage.set('tags', res.tags);
            return res;
        }

        function doWhenInitError() {
            if (!$storage.get('endpoints') && !$storage.get('oneSignal') && !$storage.get('tags')) {
                console.error('error on getting endpoints lists, oneSignal information or tags information');
            } else {
                console.log('endpoints lists, oneSignal information and tags information loaded from cache');
            }
        }

        function defaultState(route, mustUpdate) {
            if (mustUpdate) {
                $state.go(route, mustUpdate);
            } else {
                $state.go(route);
            }
        }

        return {
            'init': initServices,
            'notification': initNotifications,
            'defaultState': defaultState,
            'processAppInfo': compareVersions
        }
    }
})();