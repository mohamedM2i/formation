(function() {
    angular
        .module('purple-wind.components')
        .service('$requester', svc);

    function svc(config, urls, $http, lodash, $storage) {
        /**
         * Send an http request to server
         * 
         * @param {any} endpoint endpoint to call, if the endpoint must define a method. Otherwise GET will be used by default 
         * @param {any} data object that will contain the data to send to server
         * @returns a promise to be resolved later
         */
        function request(endpoint, data) {
            var config = {
                'method': endpoint.method || 'GET',
                'url': endpoint.url,
                'data': data
            };
            var token = $storage.get('tokenID');
            if (token) {
                config.headers = {
                    Authorization: 'Bearer ' + token
                };
            }
            return $http(config);
        }
        /**
         * build an URL to be used for endpoint call
         * 
         * @param {any} domain the domain of the back-office
         * @param {any} url url of the endpoint
         * @param {any} params parameters ot the request
         * @returns an URL to be used for http requests
         */
        function buildURL(domain, url, params) {
            var protocol = (config.env.domain[config.env.target].https) ? 'https' : 'http',
                iterator = 0,
                separator = '';
            lodash.forIn(params, function(value, key) {
                separator = (iterator > 0) ? '&' : '?';
                url = url + separator + key + '=' + value;
                iterator++;
                return;
            });
            return protocol + '://' + domain + url;
        }
        /**
         * build an endpoint
         * 
         * @param {any} endpoint endpoint to call
         * @param {any} url a full url that is obtained by call buildURL method
         * @returns a copy of the endpoint to be used for request method
         */
        function buildEndPoint(endpoint, url) {
            var result = angular.copy(endpoint);
            result.url = url;
            return result;
        }

        /**
         * call an endpoint dynamically
         * 
         * @param {any} api the name of the api as specified in the back-office list
         * @param {any} data data to send 
         * @returns a promise to be resolved later
         */
        function call(api, data) {
            var endPoints = $storage.get('endpoints'),
                _endpointURL,
                _endpointAPI;
            if (endPoints[api]) {
                _endpointAPI = endPoints[api];
            }
            if (_endpointAPI && _endpointAPI.method.toString().toUpperCase() === 'GET') {
                _endpointURL = buildURL(config.env.domain[config.env.target].url, _endpointAPI.url, data);
                /* set variable {data} to null.
                   it has been put in the url.
                   there is no need it anymore
                */
                data = null;
            } else {
                _endpointURL = buildURL(config.env.domain[config.env.target].url, _endpointAPI.url);
            }
            endPoints[api] = buildEndPoint(_endpointAPI, _endpointURL);
            return request(endPoints[api], data);
        }

        function trimURL(url) {
            var trimmedURL = '',
                re1 = '((?:\\/[\\w\\.\\-]+)+)(\\/)',
                re2 = '(\\{id\\})';

            var p = new RegExp(re1 + re2, ['i']);
            var m = p.exec(url);
            if (m != null) {
                trimmedURL = m[1];
            }
            return trimmedURL;
        }
        return {
            'request': request,
            'buildURL': buildURL,
            'buildEndPoint': buildEndPoint,
            'api': call,
            'trimURL': trimURL
        };
    }
})();