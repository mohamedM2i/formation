(function() {
    angular
        .module('purple-wind.components')
        .service('$map', svc);

    function svc($cordovaGeolocation, geolocation) {

        function pinpoint() {
            return $cordovaGeolocation.getCurrentPosition(geolocation.config);
        }

        function load() {
            var map2load = geolocation.osm;
            map2load.icons = geolocation.icons;
            return map2load;
        }

        function calculate(pointA, pointB) {
            var R = geolocation.earthRadius;
            var dLat = getRad(pointB.lat - pointA.lat);
            var dLon = getRad(pointB.lon - pointA.lon);
            var lat1 = getRad(pointA.lat);
            var lat2 = getRad(pointB.lat);
            var a = (Math.sin(dLat / 2) * Math.sin(dLat / 2)) +
                (Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2));
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            return R * c;
        }

        function getRad(deg) {
            return deg * Math.PI / 180;
        }

        return {
            pinpoint: pinpoint,
            load: load,
            calculate: calculate
        };
    }
})();