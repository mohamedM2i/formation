(function() {
  angular
  .module('purple-wind.components')
  .directive('tagPage', execTagPage)
  .directive('tagPageOnClick', execTagPageOnClick);

  function lTagPage($tag, attrTagPage, attrTagChapitre){
    var lTagChapitre={};
    if (typeof attrTagChapitre !== 'undefined') lTagChapitre = JSON.parse(attrTagChapitre);
    $tag.sendTagPage(attrTagPage, lTagChapitre);
  }

  function execTagPage($tag) {
    return {
      restrict: 'EA',
      link: function($scope, elem, attrs) {
        // console.log('Tag-page directive:', attrs.tagPage, '; tagChapitre: ', attrs.tagChapitre);
        lTagPage($tag, attrs.tagPage, attrs.tagChapitre);
      }
    };
  }

  function execTagPageOnClick($tag) {
    return {
      restrict: 'EA',
      link: function($scope, elem, attrs) {
        elem.bind('click', function() {
          // console.log('Tag-page-on-click directive:', attrs.tagPageOnClick, '; tagChapitre: ', attrs.tagChapitre);
          lTagPage($tag, attrs.tagPageOnClick, attrs.tagChapitre);
        });
      }
    };
  }

})();