(function() {
    angular
        .module('purple-wind.components')
        .service('$popup', popupHandlerService);

    function popupHandlerService($ionicPopup, $translate, $storage, urls) {
        var popUp;
        return {
            'showCustomizedError': customizedError,
            'showPopUpError': showPopUpError,
            'showPopUpDialog': showPopUpDialog,
            'showBasicPopupDialog': showBasicPopupDialog,
            'showUpdateAlert': showUpdateAlert,
            'showBasicAlertDialog': showBasicAlertDialog
        };
        /**
         * customizedError customized the error so we can show the popUp alert
         * @param  {object} err
         * @return {object} error customized
         */
        function customizedError(err) {
            var error = {};
            if (err && typeof err === 'object') {
                error.status = err.status;
                error.alertTitle = 'TITLE_ERROR_' + error.status;
                error.alertMessage = 'MESSAGE_ERROR_' + error.status;
                error.cssClass = 'errorPopupClass';
            }
            showPopUpError(error);
            return error;
        }
        /**
         * showPopUpError show the pop up error
         * @param  {object} error
         */
        function showPopUpError(error) {
            if (!popUp) {
                popUp = $ionicPopup.alert({
                    title: $translate.instant(error.alertTitle),
                    template: $translate.instant(error.alertMessage),
                    okText: $translate.instant('CAPITO_TEXT'),
                    cssClass: error.cssClass || 'errorPopupClass'
                }).then(function() {
                    popUp = null;
                });
            }
        }

        /**
         * showPopUpDialog show the pop up dialog
         * @param  {object} dialog
         */
        function showPopUpDialog(dialog) {
            showBasicPopupDialog({
                title: $translate.instant(dialog.alertTitle),
                template: $translate.instant(dialog.alertMessage)
            });
        }

        /**
         * showBasicPopUpDialog show a customizable pop up dialog
         * @param  {object} dialog
         */
        function showBasicPopupDialog(dialogCfg) {
            dialogCfg.okText = dialogCfg.okText || $translate.instant('OK_TEXT');
            dialogCfg.cssClass = 'customPopupClass';
            return $ionicPopup.confirm(dialogCfg);
        }

        /**
         * showBasicPopUpDialog show a customizable pop up dialog
         * @param  {object} dialog
         */
        function showBasicAlertDialog(dialogCfg) {
            dialogCfg.okText = dialogCfg.okText || $translate.instant('OK_TEXT');
            dialogCfg.cssClass = 'customPopupClass';
            return $ionicPopup.alert(dialogCfg);
        }

        function checkUpdateInterval() {
            var today = new Date(),
                firstInvite = new Date($storage.get('firstUpdateInvite'));
            return parseInt((today - firstInvite) / (24 * 3600 * 1000));
        }

        function showUpdateAlert(cfg) {
            if (!popUp) {
                if (!$storage.get('firstUpdateInvite')) {
                    $storage.set('firstUpdateInvite', new Date());
                } else {
                    cfg.mandatory = checkUpdateInterval() > 7;
                }
                var alertbuttons = [{
                        text: $translate.instant('BUTTON_CANCEL'),
                        onTap: function(e) {
                            if (cfg.mandatory) {
                                e.preventDefault();
                            }
                        }
                    },
                    {
                        text: $translate.instant('BUTTON_UPDATE'),
                        onTap: function() {
                            cordova.plugins.market.open(urls['store-' + ionic.Platform.platform()]);
                        }
                    }
                ];

                if (cfg.mandatory) {
                    alertbuttons.splice(0, 1);
                }
                popUp = $ionicPopup.show({
                    title: $translate.instant('UPDATE_ALERT_TITLE'),
                    subTitle: cfg.mandatory ? $translate.instant('UPDATE_ALERT_SUBTITLE_MANDATORY') : $translate.instant('UPDATE_ALERT_SUBTITLE'),
                    buttons: alertbuttons
                }).then(function() {
                    popUp = null;
                });
            }
        }
    }
})();