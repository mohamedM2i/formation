(function() {
    angular
        .module('purple-wind.components')
        .directive('autoComplete', exec);

    function exec() {
        return {
            restrict: 'A',
            link: function($scope, el) {
                el.bind('change', function(e) {
                    e.preventDefault();
                });
            }
        };
    }

})();