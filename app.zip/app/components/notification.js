(function() {
    angular
        .module('purple-wind.components')
        .service('$notification', service);

    function service(platforms, $storage, lodash, $q) {

        var target = (ionic.Platform.isAndroid()) ? 'android' : 'ios';
        /**
         * initialize the set up of OneSignal SDK in order
         * to activate the push notifications
         * @param {any} cfg conf object that contains all settings needed by App
         * @param {any} cb a call be that will be called each time the device receive a push notification
         */
        function initialize(cfg, cb) {
            var dfd = $q.defer();
            if (window && window.plugins && window.plugins.OneSignal) {
                var OneSignal = window.plugins.OneSignal;
                OneSignal
                    .startInit(cfg.oneSignalID)
                    .handleNotificationOpened(cb)
                    .endInit();

                if (cfg.enableNotificationsWhenActive) {
                    OneSignal.enableNotificationsWhenActive(cfg.enableNotificationsWhenActive);
                }

                if (cfg.enableVibrate) {
                    OneSignal.enableVibrate(cfg.enableVibrate);
                }

                if (cfg.enableSound) {
                    OneSignal.enableSound(cfg.enableSound);
                }

                OneSignal.getIds(function(ids) {
                    if (!$storage.get('OneSignalUserID')) {
                        $storage.set('OneSignalUserID', ids.userId);
                        $storage.set('OneSignalPushToken', ids.pushToken);
                    }
                    dfd.resolve(ids);
                });

                if (cfg.registerForPushNotifications) {
                    OneSignal.registerForPushNotifications();
                }

                OneSignal.setSubscription(true);
                OneSignal.sendTag('App', 'CLO');
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }
        /**
         * merge both of the local and on-server configurations 
         * @param {any} oneSignalConf on-server configuration object
         * @returns a single object that contains all OneSignal configuration
         */

        function merge(oneSignalConf) {
            var mergedObj = lodash.mergeWith(platforms[target], oneSignalConf);
            /* jshint ignore:start */
            mergedObj.config.googleProjectNumber = (mergedObj.config && mergedObj.config.googleProjectNumber) ? mergedObj.config.googleProjectNumber.toString() : '';
            /* jshint ignore:end */
            return mergedObj;
        }
        /**
         * notification handler that will be executed each time the device receive a push notification
         */
        function handleNotification() {

        }


        function deactivateNotification() {
            if (window && window.plugins && window.plugins.OneSignal) {
                var OneSignal = window.plugins.OneSignal;
                OneSignal.setSubscription(false);
            }
        }

        function activateNotification() {
            if (window && window.plugins && window.plugins.OneSignal) {
                var OneSignal = window.plugins.OneSignal;
                OneSignal.setSubscription(true);
            }
        }

        return {
            'init': initialize,
            'merge': merge,
            'handle': handleNotification,
            'deactivateNotification': deactivateNotification,
            'activateNotification': activateNotification
        };
    }
})();