(function() {
    angular
        .module('purple-wind.components')
        .service('$styler', svc);

    function svc($document, $compile, $rootScope, config, $storage) {

        function injectStyle(path) {
            var html = '<link rel="stylesheet" type="text/css" href="' + path + '" >';
            angular
                .element($document[0].head)
                .append($compile(html)($rootScope));
        }

        function loadDefaultStyle() {
            var style = $storage.get('style') || config.style.default;
            console.log('loaded style ' + style);
            injectStyle(style);
        }

        function loadBankStyle() {
            var bank = $storage.get('reseau').toString().toLowerCase() || 'bp',
                href = 'css/app-' + bank + '.min.css';
            angular
                .element($document[0].head.getElementsByTagName('link')[0])
                .attr('href', 'css/app-' + bank + '.min.css');
            $storage.set('style', href);
        }
        return {
            'css': injectStyle,
            'default': loadDefaultStyle,
            'change': loadBankStyle
        };
    }
})();