(function() {
    angular
        .module('purple-wind.components')
        .service('$permissions', svc);

    function svc($q) {
        /**
         * Returns true if the device setting for location is on.
         * 
         * - On Android this returns true if Location Mode is switched on. 
         * - On iOS this returns true if Location Services is switched on.
         * 
         * @returns promise
         */
        function isLocationEnabled() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.isLocationEnabled(function(data) {
                _dfd.resolve(data)
            }, function(err) {
                _dfd.reject(err)
            });
            return _dfd.promise;
        }
        /**
         * Checks if app is able to access device location.
         * 
         * - On iOS Mobile this returns true if both the device setting is enabled AND the application is authorized to use location.
         * When location is enabled, the locations returned are by a mixture GPS hardware, network triangulation and Wifi network IDs.
         * 
         * - On Android, this returns true if Location mode is enabled and any mode is selected (e.g. Battery saving, Device only, High accuracy) AND if the app is authorised to use location.
         * 
         * - When location is enabled, the locations returned are dependent on the location mode:
         * Battery saving = network triangulation and Wifi network IDs (low accuracy)
         * Device only = GPS hardware only (high accuracy)
         * High accuracy = GPS hardware, network triangulation and Wifi network IDs (high and low accuracy)
         * @returns promise
         */
        function isLocationAvailable() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.isLocationAvailable(function(data) {
                _dfd.resolve(data);
            }, function(err) {
                _dfd.reject(err);
            })
            return _dfd.promise;
        }
        /**
         * Checks if the application is authorized to use location.
         * 
         * @returns promise
         */
        function isLocationAuthorized() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.isLocationAuthorized(function(data) {
                _dfd.resolve(data);
            }, function(err) {
                _dfd.reject(err);
            });
            return _dfd.promise;
        }
        /**
         * Returns the location authorization status for the application.
         * 
         * Note for Android: 
         * this is intended for Android 6 / API 23 and above.
         * Calling on Android 5 / API 22 and below will always return GRANTED status as permissions are already granted at installation time.
         * 
         * @returns promise
         */
        function getLocationAuthorizationStatus() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.getLocationAuthorizationStatus(function(data) {
                _dfd.resolve(checkStatus(data));
            }, function(err) {
                _dfd.reject(err);
            });
            return _dfd.promise;
        }
        /**
         * checks the value of permission status
         * 
         * @param {String} status 
         * @returns true, if the permission is granted or 'when in use' (for iOS).false, if the permission was not requested or has been denied.
         */
        function checkStatus(status) {
            var _res = { 'permission': status };
            switch (status) {
                case cordova.plugins.diagnostic.permissionStatus.NOT_REQUESTED:
                    _res.status = false;
                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED:
                    _res.status = false;
                    break;
                case cordova.plugins.diagnostic.permissionStatus.DENIED_ALWAYS:
                    _res.status = false;
                    break;
                case cordova.plugins.diagnostic.permissionStatus.GRANTED:
                    _res.status = true;
                    break;
                case cordova.plugins.diagnostic.permissionStatus.GRANTED_WHEN_IN_USE:
                    _res.status = true;
                    break;
            }
            return _res;
        }
        /**
         * Requests location authorization for the application.
         * - Notes for iOS:
         * Calling this on iOS 7 or below will have no effect, as location permissions are are implicitly granted.
         * On iOS 8+, authorization can be requested to use location either "when in use" (only in foreground) or "always" (foreground and background).
         * This should only be called if authorization status is NOT_DETERMINED - calling it when in any other state will have no effect.
         * 
         * - Notes for Android:
         * This is intended for Android 6 / API 23 and above. Calling on Android 5 / API 22 and below will have no effect as the permissions are already granted at installation time.
         * The successCallback is invoked in response to the user's choice in the permission dialog and is passed the resulting authorization status.
         * 
         * @returns promise
         */
        function requestLocationAuthorization() {
            var _dfd = $q.defer();
            window.cordova.plugins.diagnostic.requestLocationAuthorization(function(data) {
                    _dfd.resolve(checkStatus(data));
                },
                function(err) {
                    _dfd.reject(err);
                });
            return _dfd.promise;
        }

        return {
            'isLocationEnabled': isLocationEnabled,
            'isLocationAvailable': isLocationAvailable,
            'isLocationAuthorized': isLocationAuthorized,
            'getLocationAuthorizationStatus': getLocationAuthorizationStatus,
            'requestLocationAuthorization': requestLocationAuthorization
        };
    }
})();