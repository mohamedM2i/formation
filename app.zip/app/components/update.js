(function() {
    angular
        .module('purple-wind.components')
        .service('$update', service);

    function service($storage, $state, config, lodash, $q, $popup) {
        function show(cfg) {
            if (cfg && cfg.mustUpdate) {
                $popup.showUpdateAlert(cfg);
            }
        }

        return {
            'displayUpdateMessage': show
        }
    }
})();