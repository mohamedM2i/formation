(function() {
    angular
        .module('purple-wind.components', ['ui.router']);
})();