(function() {
    angular
        .module('purple-wind.components')
        .component('tutorialSlide3', {
            template: function($element, $attrs) {
                var _slideBtn;
                if ($attrs.slideButton) {
                    _slideBtn = '<div class="row">' +
                        '<button class ="button button-outline button-block button-intro" ui-sref="' + $attrs.slideRoute + '"' +
                        'tag-button="intro_btn" >' + $attrs.slideButton + '</button></div>';
                } else {
                    _slideBtn = '';
                }

                return '<div class="intro-title">' + $attrs.slideTitle + '</div>' +
                    '<div class="intro-image-container"><img class="intro-image" src="' + $attrs.slideImage + '"></div>' +
                    '<div class="col col-center no-padding" ><div class="row">' +
                    '<h3 class="text-center">' + $attrs.slideStep + '</h3></div></div>' +
                    '<div class="col col-center"><div class="row" ><div class="col col-center">' +
                    '<h3 class="text-center">' + $attrs.slideTeaser + '</h3></div></div>' + _slideBtn + '</div>';

            },
            bindings: {
                'slideTitle': '@',
                'slideImage': '@',
                'slideStep': '@',
                'slideTeaser': '@',
                'slideButton': '@',
                'slideRoute': '@'
            }
        });
})();