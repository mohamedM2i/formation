(function() {
    angular
        .module('purple-wind.components')
        .component('tutorialSlide2', {
            template: function($element, $attrs) {
                return '<div class="intro-title">' + $attrs.slideTitle + '</div>' +
                    '<div class="intro-image-container"><img class="intro-image" src="' + $attrs.slideImage + '"></div>' +
                    '<div class="col col-center no-padding" ><div class="row">' +
                    '<div class="col col-center">' +
                    '<h3 class="text-center">' + $attrs.slideStep + '</h3></div></div>' +
                    '<div class="row"><div class="col col-center">' +
                    '<h3 class="text-center">' + $attrs.slideTeaser + '</h3></div></div></div>';
            },
            bindings: {
                'slideTitle': '@',
                'slideImage': '@',
                'slideStep': '@',
                'slideTeaser': '@'
            }
        });
})();