(function() {
    angular
        .module('purple-wind.components')
        .component('tutorialSlide1', {
            template: function($element, $attrs) {
                return '<div class="intro-title" >' + $attrs.slideTitle + '</div>' +
                    '<div class="intro-image-container"><img class="intro-image" src="' + $attrs.slideImage + '"></div>' +
                    '<div class="col col-center no-padding" ><div class="row">' +
                    '<h3 class="text-center">' + $attrs.slideTeaser + '</h3>' +
                    '</div></div>'
            },
            bindings: {
                'slideTitle': '@',
                'slideImage': '@',
                'slideTeaser': '@'
            }
        });
})();