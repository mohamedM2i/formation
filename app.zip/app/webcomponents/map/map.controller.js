(function() {
    angular
        .module('purple-wind.tabs')
        .controller('mapCtrl', ctrl);

    function ctrl($document, lodash, geolocation, $tag, $map, $storage, $permissions, $timeout, $scope) {
        var vm = this,
            mapCenter = geolocation.osm.center,
            mapComponent,
            markersLayer,
            settings = $storage.get('settings');

        if (!settings) {
            settings = {
                'notifications': true,
                'geolocation': false
            };
            $storage.set('settings', settings);
        }

        function initMap(id, cfg) {
            var _layer0 = L.tileLayer(vm.cfg.layers.baselayers.osm.url, {
                id: vm.cfg.layers.baselayers.osm.name,
                detectRetina: true,
                crossOrigin: true
            });
            mapComponent = L
                .map(id, {
                    attributionControl: cfg.defaults.attributionControl,
                    zoomControl: cfg.defaults.zoomControl,
                    fadeAnimation: cfg.defaults.fadeAnimation,
                    markerZoomAnimation: cfg.defaults.markerZoomAnimation,
                    tap: true,
                    touchZoom: cfg.defaults.touchZoom || 'center',
                    doubleClickZoom: cfg.defaults.doubleClickZoom || 'center',
                    tapTolerance: 5,
                    layers: [
                        _layer0
                    ]
                });
            //Listner for map component
            mapComponent.on('popupopen', function() {
                ionic.trigger('popUpOnpened');
            })
        }

        function doWhenDoubleClick() {
            mapComponent.zoomIn();
        }

        function setMapCenter(center) {
            if (mapComponent) {
                mapComponent.setView([center.lat, center.lng], center.zoom);
            }
        }

        function setMapCenterMarker(center) {
            if (vm._centerLayer) {
                mapComponent.removeLayer(vm._centerLayer);
            }
            vm._centerLayer = L.marker([center.lat, center.lng], {
                icon: L.icon(geolocation.icons.center[vm.cfg.network]),
                zIndexOffset: 9999
            }).addTo(mapComponent);
        }

        /**
         * sets an array of markers on map
         * using the cluster grouping
         * @param {Array} markers 
         */
        function setMarkersOnMap(markers) {
            var _cluster = L.markerClusterGroup(geolocation.osm.cluster);
            lodash.forEach(markers, function(marker) {
                _cluster.addLayer(buildMarker(marker));
            });
            if (mapComponent) {
                markersLayer = _cluster;
                mapComponent.addLayer(_cluster);
            }
        }

        function removeMarkers() {
            markersLayer.removeFrom(mapComponent);
        }

        /**
         * builds a marker that can be put on the map
         * using coordinates
         * @param {any} marker 
         * @returns a marker to be put on leaflet map
         */
        function buildMarker(marker) {
            var _marker = L.marker([marker.lat, marker.lng], {
                    icon: L.icon(geolocation.icons[vm.cfg.network])
                }),
                _popup = L.popup({
                    closeButton: false
                })
                .setContent(marker.message);

            _marker.bindPopup(_popup);
            _marker.on('click', function() {
                $tag.sendClickBouton('offer_popup_btn');
                $tag.sendTagPage('app.offer-popup', {});
            });
            return _marker;
        }

        /**
         * adds the button that pinpoints the device on map
         */
        function addControl() {
            
            var CenterButton = L.Control.extend({
                    onAdd: function() {
                        var _btn = L.DomUtil.create('button');
                        _btn.className = 'icon app-position icon-location-big'
                        L.DomEvent.on(_btn, 'click', function() {
                            $map.pinpoint().then(doWhenGeolocationControlTap);
                        });
                        return _btn;
                    },
                    onRemove: function() {
                        L.DomUtil.remove(this);
                        L.DomEvent.off(this)
                    }
                }),
                _btn = function(opts) {
                    return new CenterButton(opts);
                };

                ionic.trigger('calculateDistanceinit');  

            vm._centerBtn = _btn({ position: 'bottomright' }).addTo(mapComponent);
        }

        function doWhenGeolocationControlTap(location) {
            vm._centerCoords = {
                lat: location.coords.latitude,
                lng: location.coords.longitude
            };
            mapComponent.setView([vm._centerCoords.lat, vm._centerCoords.lng]);
            setMapCenterMarker(vm._centerCoords);
            settings.geolocation = true;
            $storage.set('settings', settings);
        }

        /**
         * Callback executed when the component pinpoints 
         * 
         * @param {any} location 
         */
        function doWhenLocationFound(location) {
            vm._centerCoords = {
                lat: location.coords.latitude,
                lng: location.coords.longitude
            };
            mapComponent.setView([vm._centerCoords.lat, vm._centerCoords.lng], 13);
            setMapCenterMarker(vm._centerCoords);
            settings.geolocation = true;
            $storage.set('settings', settings);
        }

        /**
         * occurs when app pinpoint device location
         */
        function doWhenGeolocationActivated() {
            var _setting = {
                'notifications': true,
                'geolocation': true
            }
            $storage.set('settings', _setting);
            addControl();
        }

        function doWhenGeolocationDisabled() {
            var _setting = {
                'notifications': true,
                'geolocation': false
            }
            $storage.set('settings', _setting);
            if (vm._centerLayer) {
                mapComponent.removeLayer(vm._centerLayer);
            }
            if (vm._centerBtn) {
                mapComponent.removeControl(vm._centerBtn);
            }
        }
        /**
         * request permission from user
         * @param {any} permission 
         * @returns promise
         */
        function requestPermission() {
            return $permissions.requestLocationAuthorization();
        }

        function doWhenPermissionGranted() {
            var storageLocateBtn = $storage.get('locate_btn');
            if ((storageLocateBtn === null) || (storageLocateBtn === false)) {
                $tag.sendClickBouton('locate_valid_btn');
            }
            $map.pinpoint().then(doWhenLocationFound);
        }

        function doWhenPermissionDenied() {
            var storageLocateBtn = $storage.get('locate_btn');
            if (storageLocateBtn === null) {
                $tag.sendClickBouton('locate_refuse_btn');
            }
            if (!settings) {
                settings = {
                    'notifications': true,
                    'geolocation': false
                };
                $storage.set('settings', settings);
            }
            doWhenGeolocationDisabled();
        }

        function recalculateCurrentPosition(event, obj){
            vm._centerCoords = {
                lat: obj.position.coords.latitude,
                lng: obj.position.coords.longitude
            };
            setMapCenterMarker(vm._centerCoords);
        }

        $scope.$on('recalculateCurrentPosition',recalculateCurrentPosition);

        function checkDeviceStatus() {
            return $permissions.isLocationEnabled();
        }

        function checkAppStatus() {
            return $permissions.isLocationAvailable();
        }

        function checkLocationAuthorizationStatus() {
            return $permissions.getLocationAuthorizationStatus();
        }

        /**
         * ask for user approval for access to device geolocation feature.
         * PS: the OS popup for approval appear only once, it does not appear when again if user denies it
         * 
         * @param {Object} requestStatus 
         * @returns function argument for chaining
         */
        function applyApprovalToSettings(requestStatus) {
            if (settings) {
                settings.geolocation = requestStatus.status;
                $storage.set('settings', settings);
            }
            $storage.set('locate_btn', requestStatus.status);
            return requestStatus;
        }

        /**
         * double tap event listner
         * zoom on center when user double tap on map
         */
        vm.dblTap = doWhenDoubleClick;

        /**
         * Lifecyle -> Event fired when the component is initialized
         */
        vm.$onInit = function() {
            initMap(vm.mapId, vm.cfg);
            setMapCenter(mapCenter);
            //check if running on device
            if (window.cordova) {
                checkDeviceStatus()
                    .then(function(deviceStatus) {
                        //if geolocation feature is enabled on device
                        //then check app access to geolocation 
                        if (deviceStatus) {
                            if (!settings.geolocation) {
                                requestPermission()
                                    .then(applyApprovalToSettings)
                                    .then(function(requestStatus) {
                                        if (requestStatus.status) {
                                            doWhenPermissionGranted();
                                            doWhenGeolocationActivated();
                                        } else {
                                            //if request denied, only map and markers should be processed
                                            doWhenPermissionDenied();
                                            doWhenGeolocationDisabled();
                                        }
                                    });
                            } else {
                                //if request granted, a secondary checkpoint must be performed in order to handle user
                                //disabling of geolocation from outside the app
                                checkAppStatus()
                                    .then(function(appStatus) {
                                        //if app has access to geolocation
                                        //then get geolocation
                                        if (appStatus) {
                                            doWhenPermissionGranted();
                                            addControl();
                                        } else {
                                            //occurs when geolocation is disabled for app
                                            doWhenGeolocationDisabled();
                                        }
                                    });
                            }
                        } else {
                            doWhenGeolocationDisabled();
                        }
                    });
            }
        };
        /**
         * Lifecycle -> Event fired when update occurs on component binded data
         */
        vm.$onChanges = function(data) {
            //occurs when markers parameter changes
            if (data.markers && data.markers.currentValue) {
                //if the list of marker provided to map component length not empty then put on map
                if (markersLayer) {
                    removeMarkers();
                }
                setMarkersOnMap(data.markers.currentValue);
            }
        };

        //listner for activate/disable geolocation using external settings
        ionic.on('activateGeolocEvent', doWhenGeolocationActivated);
        ionic.on('deactivateGeolocEvent', doWhenGeolocationDisabled);
    }
})();