(function() {
    angular
        .module('purple-wind.components')
        .component('mapDisplay', {
            template: function($element, $attrs) {
                return '<div id="' + $attrs.mapId + '" on-double-tap="$ctrl.dblTap($event)" data-tap-disabled="true"></div>'
            },
            controller: 'mapCtrl',
            bindings: {
                mapId: '@',
                cfg: '=',
                markers: '<'
            }
        });
})();