(function() {
    angular
        .module('purple-wind.components')
        .component('treeGrid', {
            templateUrl: 'webcomponents/treegrid/treegrid.html',
            controller: 'treegridCtrl',
            bindings: {
                'title': '@',
                'tagPage': '@',
                'src': '<'
            }
        });
})();