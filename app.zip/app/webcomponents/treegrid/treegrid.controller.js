(function() {
    angular
        .module('purple-wind.tabs')
        .controller('treegridCtrl', ctrl);

    function ctrl() {
        var vm = this;

        vm.toggleGroup = function(group) {
            group.show = !group.show;
        };

        vm.isGroupShown = function(group) {
            return (group) ? group.show : false;
        };

        /**
         * Lifecyle -> Event fired when the component is initialized
         */
        /*
        vm.$onInit = function() {
            // debugger;
            console.log(vm);
        };
        */

        /**
         * Lifecycle -> Event fired when update occurs on component binded data
         */
        vm.$onChanges = function(data) {
            if (data && data.src && data.src.currentValue) {
                vm.parent = data.src.currentValue;
            }
        };
    }
})();