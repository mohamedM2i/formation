(function() {
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.list', {
                url: '/list',
                views: {
                    'tab-favorites': {
                        templateUrl: 'modules/list/list.html',
                        controller: 'listCtrl'
                    }
                }

            });
    }
})();