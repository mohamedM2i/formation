(function() {
    angular
        .module('purple-wind.tabs')
        .controller('listCtrl', ctrl);

    function ctrl(HomeService, offers, $state, $storage, lodash, $scope, $timeout) {
        var vm = this;

        vm.filtersState = '';
        vm.reverse = false;


        function resortEventMethode(event, obj){
            if(obj.id == 0){
                vm.filtersState = 'minDistance';
                vm.reverse = false;
            } else if(obj.id == 1){
                vm.filtersState = 'minDistance';
                vm.reverse = false;
            } else if(obj.id == 2) {
                vm.filtersState = 'dateFin';
                vm.reverse = false;
            } else if (obj.id == 3) {
                vm.filtersState = 'dateDebut';
                vm.reverse = true;
            } else if (obj.id == 4) {
                vm.filtersState = 'cashBackPourcentage';
                vm.reverse = true;
            }
        }

        $scope.$on('resortEvent',resortEventMethode);

        function updateOffer(id) {
            offers.consultOfferInCache(id);
            lodash.forEach(vm.offers, function(item) {
                if (item.id === lodash.toNumber(id)) {
                    item.consulte = true;
                }
            });
        }

        $scope.$on('sortChange', function (event , obj){
            vm.filtersState = obj.name;
            vm.reverse = obj.reverse ;
         })

        vm.goToDetail = function(id) {
            updateOffer(id);
            $state.go('app.offer-list', { offerId: id });
        }

        vm.animate=function(offer){

            offer.consulte = true;
        }

        vm.inview= function(index, inview, offer){
            if (offer.multiple) { 
                for(var i=0 ; i<offer.ids.length ; i++ ){
                    HomeService
                    .offerConsulted(offer.ids[i])
                    .catch(function () {
                        HomeService.saveOfferId(offer.ids[i]);
                    });
                }
            } else {
                HomeService
                    .offerConsulted(offer.id)
                    .catch(function () {
                        HomeService.saveOfferId(offer.id);
                    });
            }
            $timeout(vm.animate(offer),1000);
        }
    }
})();