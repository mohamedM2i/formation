(function() {
    angular
        .module('purple-wind.components')
        .component('offerList', {
            templateUrl: 'webcomponents/list/list.html',
            controller: 'listCtrl',
            bindings: {
                offers: '='
            }
        });
})();