(function() {
    angular
        .module('purple-wind.tabs')
        .controller('drawerCtrl', ctrl);

    function ctrl($document, lodash, $tag, $storage, $scope) {
        var vm = this,
            mode = true,
            toggle = false;

        vm.options = {
            slidesPerView: 5,
            freeMode: true,
            loop: false
        };

        function createCategoriesList(items) {
            return lodash.chunk(items, 4);
        }

        function openDrawer(mapMode) {
            var _drawer = $document[0].getElementById('drawercomp');
            _drawer.style['height'] = '100%';
            _drawer.style['transition'] = '0.5s';
            _drawer.style['padding'] = '10px';
            _drawer.style['visibility'] = 'visible';
            _drawer.style['opacity'] = '1';
            _drawer.style['position'] = mapMode ? 'fixed' : 'initial';
        }

        function closeDrawer() {
            var _drawer = $document[0].getElementById('drawercomp');
            _drawer.style['height'] = '0%';
            _drawer.style['padding'] = '0';
            _drawer.style['transition'] = '0.5s';
            _drawer.style['visibility'] = 'hidden';
            _drawer.style['opacity'] = '0';
        }

        vm.selectedItems = [];
        /**
         * Lifecyle -> Event fired when the component is initialized
         */
        // vm.$onInit = function() {
            vm.items = createCategoriesList(vm.items);
        // };
        /**
         * Lifecycle -> Event fired when update occurs on component binded data
         */
        vm.$onChanges = function(data) {
            if (data.mode) {
                mode = data.mode.currentValue;
            }
            if (data.toggle) {
                toggle = data.toggle.currentValue;
            }
            if (data.items && data.items.currentValue && data.items.currentValue.length > 0) {
                vm.items = createCategoriesList(data.items.currentValue);
            }
            if (toggle) {
                openDrawer(mode);
            } else {
                closeDrawer();
            }
        };

        vm.select = function(item) {
            item.selected = !item.selected || false;
            if (item.selected) {
                vm.selectedItems = lodash.concat(vm.selectedItems, item);
                vm.onSelect({ data: vm.selectedItems });
            } else {
                vm.selectedItems = lodash.pull(vm.selectedItems, item);
                vm.onRemove({ data: vm.selectedItems });
            }
        }
    }
})();



(function() {
    angular
        .module('purple-wind.tabs')
        .controller('drawerSortCtrl', ctrlSort);

    function ctrlSort($document, lodash, $tag, $storage, $scope, $map, $rootScope, $translate, $popup) {
        var vm = this,
            mode = true,
            toggle = false;

        vm.options = {
            slidesPerView: 5,
            freeMode: true,
            loop: false
        };
        vm.distanceItem;

        function createList(items) {
            vm.distanceItem = items[0];
            return lodash.chunk(items, 2);
        }

        function openDrawer(mapMode) {
            var _drawer = $document[0].getElementById('drawercomp');
            _drawer.style['height'] = '100%';
            _drawer.style['transition'] = '0.5s';
            _drawer.style['padding'] = '10px';
            _drawer.style['visibility'] = 'visible';
            _drawer.style['opacity'] = '1';
            _drawer.style['position'] = mapMode ? 'fixed' : 'initial';
        }

        function closeDrawer() {
            var _drawer = $document[0].getElementById('drawercomp');
            _drawer.style['height'] = '0%';
            _drawer.style['padding'] = '0';
            _drawer.style['transition'] = '0.5s';
            _drawer.style['visibility'] = 'hidden';
            _drawer.style['opacity'] = '0';
        }

        vm.selectedItems = [];
        /**
         * Lifecyle -> Event fired when the component is initialized
         */
        // vm.$onInit = function() {
            vm.items = createList(vm.items);
        // };
        /**
         * Lifecycle -> Event fired when update occurs on component binded data
         */
        vm.$onChanges = function(data) {
            if (data.mode) {
                mode = data.mode.currentValue;
            }
            if (data.toggle) {
                toggle = data.toggle.currentValue;
            }
            if (data.items && data.items.currentValue && data.items.currentValue.length > 0) {
                vm.items = createList(data.items.currentValue);
            }
            if (toggle) {
                openDrawer(mode);
            } else {
                closeDrawer();
            }
        };

        init();

        function notSelected(){
            var result = true ;
            lodash.forEach(vm.items, function(item) {
                if(result){
                    lodash.forEach(item, function(itemS) {
                        if(result){
                            if(itemS.selected){
                                result = false ;
                            }
                        }
                 });
                }
                
            });

            return result;

        } 

        function init(){
            if(notSelected()){
                $map.pinpoint().then(function (location) {
                    vm.distanceItem.disabled = false ;
                    vm.select(vm.distanceItem);
                });
                $rootScope.isFirstTime = false ;
            } 
        } 

        function deselectOther(currentItem){
            lodash.forEach(vm.items, function(item) {      
                lodash.forEach(item, function(itemS) {
                    if(itemS.id != currentItem.id){
                        itemS.selected = false ;
                    }
                });      
            });
        }

        function openHelperLocalisation() {
            return $popup.showBasicAlertDialog({
                'templateUrl': 'modules/helper/helper-localisation.html',
                'okText': $translate.instant('OK')
            });
        }

        vm.select = function(item) {

        if(!item.disabled){
            item.selected = !item.selected || false;
            if (item.selected) {
                deselectOther(item);
                vm.selectedItems = [];
                vm.selectedItems.push(item);
                vm.onSelect({ data: vm.selectedItems });
            } else {
                vm.selectedItems = lodash.pull(vm.selectedItems, item);
                vm.onRemove({ data: vm.selectedItems });
            }
        } else {
            openHelperLocalisation();
        }
        }
    }
})();