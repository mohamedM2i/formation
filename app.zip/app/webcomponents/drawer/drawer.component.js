(function() {
    angular
        .module('purple-wind.tabs')
        .component('drawer', {
            templateUrl: 'webcomponents/drawer/drawer.html',
            controller: 'drawerCtrl',
            bindings: {
                toggle: '<',
                mode: '<',
                items: '<',
                onSelect: '&',
                onRemove: '&'
            }
        });
})();

(function() {
    angular
        .module('purple-wind.tabs')
        .component('drawerSort', {
            templateUrl: 'webcomponents/drawer/drawer.sort.html',
            controller: 'drawerSortCtrl',
            bindings: {
                toggle: '<',
                mode: '<',
                items: '<',
                onSelect: '&',
                onRemove: '&'
            }
        });
})();