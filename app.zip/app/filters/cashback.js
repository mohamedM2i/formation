(function() {
    angular
        .module('purple-wind.filters')
        .filter('cashback', exec);

    function exec() {
        return function(input) {
            return (input - input.toFixed(2) === 0) ? input : input.toPrecision(2);
        }
    }

})();