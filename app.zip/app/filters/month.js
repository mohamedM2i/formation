(function() {
    angular
        .module('purple-wind.filters')
        .filter('month', exec);

    function exec($storage, lodash) {
        return function(input) {
            var output,
                months = $storage.get('months'),
                re = '(\\d+)(\\s+-\\s+)(\\d+)';
            var p = new RegExp(re, ['i']);
            var m = p.exec(input);
            if (m != null) {
                var month = m[1];
                var year = m[3];

                output = months[lodash.toNumber(month) - 1] + ' ' + year;
            }
            return output;
        }
    }

})();