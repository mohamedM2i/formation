(function() {
  angular
  .module('purple-wind.filters', []);
})();