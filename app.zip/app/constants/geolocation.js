(function() {
    angular
        .module('purple-wind.components')
        .constant('geolocation', {
            icons: {
                default: {
                    iconUrl: 'img/marker-icon.png',
                    iconRetinaUrl: 'img/marker-icon-2x.png',
                    iconSize: [30, 50]
                },
                bp: {
                    iconUrl: 'img/marker-icon-bp.png',
                    iconRetinaUrl: 'img/marker-icon-bp-2x.png',
                    iconSize: [22, 27]
                },
                bred: {
                    iconUrl: 'img/marker-icon-bp.png',
                    iconRetinaUrl: 'img/marker-icon-bp-2x.png',
                    iconSize: [22, 27]
                },
                ce: {
                    iconUrl: 'img/marker-icon-ce.png',
                    iconRetinaUrl: 'img/marker-icon-ce-2x.png',
                    iconSize: [22, 27]
                },
                center: {
                    default: {
                        iconUrl: 'img/marker-center.png',
                        iconSize: [15, 15],
                        shadowSize: [20, 20]
                    },
                    bp: {
                        iconUrl: 'img/marker-center-bp.png',
                        iconSize: [15, 15],
                        shadowSize: [20, 20]
                    },
                    bred: {
                        iconUrl: 'img/marker-center-bp.png',
                        iconSize: [15, 15],
                        shadowSize: [20, 20]
                    },
                    ce: {
                        iconUrl: 'img/marker-center-ce.png',
                        iconSize: [15, 15],
                        shadowSize: [20, 20]
                    }
                }
            },
            earthRadius: 6371,
            unit: 'K',
            config: {
                timeout: 10000,
                enableHighAccuracy: false
            },
            osm: {
                defaults: {
                    attributionControl: false,
                    zoomControl: false,
                    fadeAnimation: true,
                    markerZoomAnimation: true,
                    touchZoom: true,
                    doubleClickZoom: true
                },
                cluster: {
                    showCoverageOnHover: false,
                    zoomToBoundsOnClick: true,
                    maxClusterRadius: 30
                },
                markers: [],
                center: {
                    lat: 46.234725,
                    lng: 2.214828,
                    zoom: 5
                },
                tiles: {
                    url: 'http://{s}.tile.osm.org/{z}/{x}/{y}.png'
                },
                layers: {
                    baselayers: {
                        osm: {
                            name: 'OpenStreetMap',
                            url: 'http://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
                            type: 'xyz'
                        },
                        basemaps: {
                            name: 'BaseMaps',
                            url: 'http://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png'
                        }
                    }
                }
            }
        });
})();