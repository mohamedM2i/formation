(function() {
    angular
        .module('purple-wind.components')
        .constant('config', {
            permissions: {
                ACCESS_CHECKIN_PROPERTIES: 'android.permission.ACCESS_CHECKIN_PROPERTIES',
                ACCESS_COARSE_LOCATION: 'android.permission.ACCESS_COARSE_LOCATION',
                ACCESS_FINE_LOCATION: 'android.permission.ACCESS_FINE_LOCATION',
                ACCESS_LOCATION_EXTRA_COMMANDS: 'android.permission.ACCESS_LOCATION_EXTRA_COMMANDS',
                ACCESS_MOCK_LOCATION: 'android.permission.ACCESS_MOCK_LOCATION',
                ACCESS_NETWORK_STATE: 'android.permission.ACCESS_NETWORK_STATE',
                ACCESS_WIFI_STATE: 'android.permission.ACCESS_WIFI_STATE',
                ACCOUNT_MANAGER: 'android.permission.ACCOUNT_MANAGER',
                BLUETOOTH: 'android.permission.BLUETOOTH',
                CALL_PHONE: 'android.permission.CALL_PHONE',
                CAMERA: 'android.permission.CAMERA',
                CHANGE_NETWORK_STATE: 'android.permission.CHANGE_NETWORK_STATE',
                CHANGE_WIFI_STATE: 'android.permission.CHANGE_WIFI_STATE',
                CONTROL_LOCATION_UPDATES: 'android.permission.CONTROL_LOCATION_UPDATES',
                EXPAND_STATUS_BAR: 'android.permission.EXPAND_STATUS_BAR',
                FORCE_BACK: 'android.permission.FORCE_BACK',
                GET_ACCOUNTS: 'android.permission.GET_ACCOUNTS',
                INTERNET: 'android.permission.INTERNET',
                LOCATION_HARDWARE: 'android.permission.LOCATION_HARDWARE',
                MANAGE_ACCOUNTS: 'android.permission.MANAGE_ACCOUNTS',
                MANAGE_APP_TOKENS: 'android.permission.MANAGE_APP_TOKENS',
                MANAGE_DOCUMENTS: 'android.permission.MANAGE_DOCUMENTS',
                MASTER_CLEAR: 'android.permission.MASTER_CLEAR',
                MEDIA_CONTENT_CONTROL: 'android.permission.MEDIA_CONTENT_CONTROL',
                MODIFY_AUDIO_SETTINGS: 'android.permission.MODIFY_AUDIO_SETTINGS',
                MODIFY_PHONE_STATE: 'android.permission.MODIFY_PHONE_STATE',
                MOUNT_FORMAT_FILESYSTEMS: 'android.permission.MOUNT_FORMAT_FILESYSTEMS',
                MOUNT_UNMOUNT_FILESYSTEMS: 'android.permission.MOUNT_UNMOUNT_FILESYSTEMS',
                NFC: 'android.permission.NFC',
                PROCESS_OUTGOING_CALLS: 'android.permission.PROCESS_OUTGOING_CALLS',
                READ_CALENDAR: 'android.permission.READ_CALENDAR',
                READ_CALL_LOG: 'android.permission.READ_CALL_LOG',
                READ_CONTACTS: 'android.permission.READ_CONTACTS',
                READ_EXTERNAL_STORAGE: 'android.permission.READ_EXTERNAL_STORAGE',
                READ_PHONE_STATE: 'android.permission.READ_PHONE_STATE',
                READ_SMS: 'android.permission.READ_SMS',
                READ_SYNC_STATS: 'android.permission.READ_SYNC_STATS',
                SEND_SMS: 'android.permission.SEND_SMS',
                STATUS_BAR: 'android.permission.STATUS_BAR',
                USE_CREDENTIALS: 'android.permission.USE_CREDENTIALS',
                VIBRATE: 'android.permission.VIBRATE',
                WRITE_SECURE_SETTINGS: 'android.permission.WRITE_SECURE_SETTINGS',
                WRITE_SETTINGS: 'android.permission.WRITE_SETTINGS',
                WRITE_SMS: 'android.permission.WRITE_SMS'
            },
            style: {
                default: 'css/app-bp.min.css'
            },
            fake: {
                cgu: ''
            },
            env: {
                target: 'local',
                domain: {
                    local: {
                        root: '192.168.102.114:9090/', //Do not remove the last slash character
                        url: '192.168.102.114:9090/socle-clo-ws/',
                        api: '1',
                        method: 'GET',
                        https: false
                    },
                    recette: {
                        root: 'mesbonsplans.dev.intranatixis.com/', //Do not remove the last slash character
                        url: 'mesbonsplans.dev.intranatixis.com/socle-clo-ws/',
                        api: '1',
                        method: 'GET',
                        https: true
                    },
                    qualif: {
                        root: 'www.qua.mapdil.com/', //Do not remove the last slash character
                        url: 'www.qua.mapdil.com/socle-clo-ws/',
                        api: '1',
                        method: 'GET',
                        https: true
                    },
                    prod: {
                        root: 'www.mapdil.com/', //Do not remove the last slash character
                        url: 'www.mapdil.com/socle-clo-ws/',
                        api: '1',
                        method: 'GET',
                        https: true
                    }
                }
            }
        });
})();