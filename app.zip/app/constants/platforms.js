(function() {
    angular
        .module('purple-wind.components')
        .constant('platforms', {
            // onesignalID: '9ef1d867-13cc-452f-be19-ebb6e0d4a42b',
            android: {
                config: {
                    // googleProjectNumber: 622612570868,
                    autoRegister: true
                },
                enableNotificationsWhenActive: true,
                enableVibrate: true,
                enableSound: true
            },
            ios: {
                config: {
                    autoRegister: false,
                    googleProjectNumber: '',
                },
                registerForPushNotifications: true,
                enableVibrate: true,
                enableSound: true
            }
        })
})();