(function() {
    angular
        .module('purple-wind.components')
        .constant('urls', {
            'init': 'api/app/init',
            'image_advertiser': 'images/photo/',
            'image_logo_small': 'images/logo_90_50/',
            'image_logo_big': 'images/logo_190_90/',
            'store-ios': 'id1251954900',
            'store-android': 'com.natixis.clo'
        });
})();