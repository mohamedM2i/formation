(function () {
    angular
        .module('purple-wind.tabs')
        .controller('OfferCtrl', ctrl);

    function ctrl($state, $stateParams, offers, HomeService) {
        var vm = this;
        vm.offer = offers.get($stateParams.offerId);
        vm.shownItem = false;

        if (vm.offer.multiple) { 
            for(var i=0 ; i<vm.offer.ids.length ; i++ ){
                HomeService
                .offerConsulted(vm.offer.ids[i])
                .catch(function () {
                    HomeService.saveOfferId(vm.offer.ids[i]);
                });
            }
        } else {
            HomeService
                .offerConsulted($stateParams.offerId)
                .catch(function () {
                    HomeService.saveOfferId($stateParams.offerId);
                });
        }

        var locations = HomeService.getLocations(Number.parseInt($stateParams.offerId));

        vm.showLocations = function () {
            var _nextState = 'app.locations';
            $state.go(_nextState, {
                'locations': locations,
                'vendor': vm.offer.annonceur.nom
            });
        };

        vm.openExternal= function(lien){
            cordova.InAppBrowser.open(lien,'_system');
            return false;

        };

        vm.toggleItem = function () {
            vm.shownItem = !vm.shownItem;
        };

    }
})();