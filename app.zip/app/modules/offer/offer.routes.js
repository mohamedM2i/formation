(function() {
    angular
        .module('purple-wind.tabs')
        .config(route);

    function route($stateProvider) {
        $stateProvider
            .state('app.offer-list', {
                url: '/list/:offerId',
                views: {
                    'tab-offers': {
                        templateUrl: 'modules/offer/offer.html',
                        controller: 'OfferCtrl',
                        controllerAs: 'vm'
                    }
                }
            })
            .state('app.offer-map', {
                url: '/map/:offerId',
                views: {
                    'tab-offers': {
                        templateUrl: 'modules/offer/offer.html',
                        controller: 'OfferCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();