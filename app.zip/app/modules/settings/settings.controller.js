(function() {
    angular
        .module('purple-wind.tabs')
        .controller('SettingsCtrl', ctrl);

    function ctrl($state, SettingsService, $scope, $notification, $permissions) {
        var vm = this;
        vm.isIOS = ionic.Platform.isIOS();
        //TODO - this should be moved to service
        vm.setNotification = function() {
            vm.currentSettings.notifications = vm.self.notifications;
            SettingsService.save(vm.currentSettings);
            if (vm.currentSettings.notifications === true) {
                $notification.activateNotification();
            } else {
                $notification.deactivateNotification();
            }
        };

        function callbackCheck(data) {
            vm.hasPermission = data.status;
        }

        //TODO - this should be moved to service
        vm.setGeolocalisation = function() {
            if(!vm.isIOS){
            vm.currentSettings.geolocation = vm.self.geolocation;
            SettingsService.save(vm.currentSettings);
            if (vm.currentSettings.geolocation === true) {
                ionic.trigger('activateGeolocEvent');
            } else {
                ionic.trigger('deactivateGeolocEvent');
            }
        }
        };


        vm.self = {}
        vm.currentSettings = SettingsService.load();

        function redirect(route, params) {
            $state.go(route, params);
        }

        vm.changePassword = function() {
            redirect('app.resetpwd');
        };

        //TODO - this should be moved to service 
        $scope.$on('$ionicView.beforeEnter', function() {
            if (window.cordova) {
                $permissions.getLocationAuthorizationStatus().then(callbackCheck);
            } else {
                vm.hasPermission = true;
            }
        })
        $scope.$on('$ionicView.enter', function() {
            if (vm.currentSettings) {
                vm.self.notifications = (typeof vm.currentSettings.notifications !== 'undefined') ? vm.currentSettings.notifications : true;
                vm.self.geolocation = (typeof vm.currentSettings.geolocation !== 'undefined') ? vm.currentSettings.geolocation : true;
            } else {
                vm.currentSettings = SettingsService.init();
                vm.currentSettings.geolocalisation = vm.hasPermission;
                vm.self.geolocation = vm.currentSettings.geolocation;
                SettingsService.save(vm.currentSettings);
            }
        });
    }
})();