(function () {
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.settings', {
                url: '/settings',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/settings/settings.html',
                        controller: 'SettingsCtrl',
                        controllerAs: 'vm'
                    }
                }
            })
            .state('app.resetpwd', {
                url: '/reset-pwd',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/enroll/enroll-password.html',
                        controller: 'EnrollPasswordCtrl',
                        controllerAs: 'vm'
                    }
                },
                params: {
                    'code': null,
                    'mail': null,
                    'isReset': true
                }
            });
    }
})();