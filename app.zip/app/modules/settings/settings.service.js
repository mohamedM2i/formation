(function() {
    angular
        .module('purple-wind.tabs')
        .service('SettingsService', service);

    function service($storage) {

        function save(settings) {
            $storage.set('settings', settings);
        }

        function load() {
            return $storage.get('settings');
        }

        function init() {
            return {
                'notifications': true,
                'geolocation': true
            };
        }


        return {
            'save': save,
            'load': load,
            'init': init
        };
    }
})();