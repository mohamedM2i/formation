(function() {
    angular
        .module('purple-wind.tabs', []);
})();