(function() {
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app', {
                url: '/app',
                abstract: true,
                templateUrl: function() {
                    return 'modules/root/root.html';
                }
            });
    }
})();