(function() {
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.favorite', {
                url: '/favorite',
                views: {
                    'tab-favorites': {
                        templateUrl: 'modules/favorite/favorite.html',
                        controller: 'listCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();