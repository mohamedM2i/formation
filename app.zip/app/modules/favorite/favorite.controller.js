(function() {
    angular
        .module('purple-wind.tabs')
        .controller('FavoriteCtrl', ctrl);

    function ctrl($scope, $permissions, config) {

        function doWhenPermissionGranted(status) {
            console.log('Granted' + status);
        }

        function doWhenPermissionDenied(status) {
            console.error('denied' + status);
        }

        $permissions.request([
                config.permissions.READ_SMS
            ],
            doWhenPermissionGranted,
            doWhenPermissionDenied
        );

    }
})();