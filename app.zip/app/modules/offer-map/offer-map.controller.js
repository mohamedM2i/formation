(function() {
    angular
        .module('purple-wind.tabs')
        .controller('OfferMapCtrl', ctrl);

    function ctrl($scope, $stateParams, HomeService) {
        var vm = this;
        vm.map = HomeService.loadMap();
        vm.vendor = $stateParams.vendor;

        $scope.$on('$ionicView.afterEnter', function() {
            vm.markers = $stateParams.locations;
        });
    }
})();