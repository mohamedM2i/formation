(function() {
    angular
        .module('purple-wind.tabs')
        .config(route);

    function route($stateProvider) {
        $stateProvider
            .state('app.locations', {
                url: '/locations',
                views: {
                    'tab-offers': {
                        templateUrl: 'modules/offer-map/offer-map.html',
                        controller: 'OfferMapCtrl',
                        controllerAs: 'offermap'
                    }
                },
                params: {
                    locations: null,
                    vendor: ''
                }
            });
    }
})();