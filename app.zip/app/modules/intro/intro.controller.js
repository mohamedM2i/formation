(function() {
    angular
        .module('purple-wind.intro')
        .controller('IntroCtrl', ctrl);

    function ctrl($scope, $storage, $tag, $state, $update, $stateParams) {
        var vm = this;
        vm.options = {
            loop: false,
            effect: 'slide',
            speed: 500
        };

		    $update.displayUpdateMessage($stateParams.update);

        var sendTagPage=function(index){
            switch (index) {
                case 0:
                    $tag.sendTagPage('intro', {});
                    break;
                case 1:
                    $tag.sendTagPage('mobile', {});
                    break;
                case 2:
                    $tag.sendTagPage('simple', {});
                    break;
            }
        };

        var sendTagAction=function(index, nextPage){
            switch (index) {
                case 0:
                    $tag.sendClickBouton('intro_' + (nextPage ? 'next' : 'prev') + '_nav');
                    break;
                case 1:
                    $tag.sendClickBouton('mobile_' + (nextPage ? 'next' : 'prev') + '_nav');
                    break;
                case 2:
                    $tag.sendClickBouton('simple_' + (nextPage ? 'next' : 'prev') + '_nav');
                    break;
            }
        };

        /*
        $scope.$on('$ionicSlides.sliderInitialized', function(event, data) {
            // data.slider is the instance of Swiper
            // sendTagPage(data.slider.activeIndex);
        });
        */

        $scope.$on('$ionicSlides.slideChangeStart', function(event, data) {
            sendTagAction(data.slider.previousIndex, data.slider.activeIndex > data.slider.previousIndex);
            sendTagPage(data.slider.activeIndex);
        });
        $storage.set('landing_state', 'intro');
    }
})();