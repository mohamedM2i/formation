(function() {
    angular
        .module('purple-wind.intro', []);
})();