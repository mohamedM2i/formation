(function() {
    angular
        .module('purple-wind.intro')
        .config(cfg);

    function cfg($stateProvider) {
        $stateProvider
            .state('intro', {
                url: '/intro',
                templateUrl: 'modules/intro/intro.html',
                controller: 'IntroCtrl',
                controllerAs: 'intro',
                params: {
                    'update': null
                }
            });
    }
})();