(function() {
    angular
        .module('purple-wind.tabs')
        .config(cfg);

    function cfg($stateProvider) {
        $stateProvider
            .state('app.tutorial', {
                url: '/tutorial',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/tutorial/tutorial.html',
                        controller: 'TutorialCtrl',
                        controllerAs: 'intro',
                    }
                },
                params: {
                    'update': null
                }
            });
    }
})();