(function() {
    angular
        .module('purple-wind.cgu')
        .service('CguService', svc);

    function svc($q, $requester, $storage, config) {
        function cgu() {
            return config.fake.cgu;
        }

        function optin() {
            return config.fake.cgu;
        }

        function accept() {
            return $storage.set('cguAccepted', true);
        }
        return {
            loadCGU: cgu,
            loadOptin: optin,
            accepted: accept
        };
    }
})();