(function() {
    angular
        .module('purple-wind.cgu', []);
})();