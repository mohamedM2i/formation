(function() {
    angular
        .module('purple-wind.cgu')
        .controller('CguCtrl', ctrl);

    function ctrl($state, CguService) {
        var cgu = this;

        function enroll() {
            CguService.accepted();
        }

        cgu.enroll = enroll;
    }
})();