(function() {
    angular
        .module('purple-wind.cgu')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('cgu', {
                url: '/cgu',
                templateUrl: 'modules/cgu/cgu.html',
                controller: 'CguCtrl',
                controllerAs: 'cgu'
            })
            .state('app.cgu', {
                url: '/cgu',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/cgu/cgu-account.html',
                        controller: 'CguCtrl',
                        controllerAs: 'cgu'
                    }
                }
            });
    }
})();