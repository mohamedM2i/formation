(function() {
    angular
        .module('purple-wind.tabs')
        .service('AccountService', svc);

    function svc($q, $requester) {
        function getCardsList() {
            var dfd = $q.defer();
            $requester
                .api('account_info')
                .then(function(success) {
                    dfd.resolve(success.data);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }


        return {
            'getData': getCardsList
        };

    }
})();