(function() {
    angular
        .module('purple-wind.tabs')
        .controller('AccountCtrl', ctrl);

    function ctrl(AccountService, $scope, $cordovaAppVersion) {
        var vm = this;
        vm.appName = '';
        vm.versionNumber = '';

        if (window.cordova){
            $cordovaAppVersion.getAppName().then(function(appName) {
                vm.appName = appName;
            });
            $cordovaAppVersion.getVersionNumber().then(function(versionNumber) {
                vm.versionNumber = 'v' + versionNumber;
            });
        }

        $scope.$on('$ionicView.beforeEnter', function() {
            AccountService
                .getData()
                .then(function(cb) {
                    vm.numDesensibilise = cb.carteDTOs[0].numero;
                    vm.typeCarte = cb.carteDTOs[0].typeCarte;
                    vm.img = setCardImg(vm.numDesensibilise);
                });
        });

        function setCardImg(typeCarte) {
            return Number.parseInt(typeCarte.substring(0, 1)) === 4 ? 'visa2' : 'mastercard';
        }
    }
})();