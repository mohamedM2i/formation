(function() {
    angular
        .module('purple-wind.entities')
        .factory('saleLocations', salelocationsFactory);

    function salelocationsFactory($requester, $q, $storage, lodash, urls, config) {
        function getAll() {
            var deferred = $q.defer();
            if (inCache()){
                deferred.resolve(loadDataFromCache());
                return deferred.promise;
            } else {
                return $requester
                .api('sale_locations')
                .then(filterEmptySaleLocations, loadDataFromCache)
                .then(processData);
            }
        }

        /**
         * loads sale locations data from cache
         * @returns Array of sale locations stored previously
         */
        function loadDataFromCache() {
            var cache = $storage.get('sale_locations');
            return lodash.toArray(cache);
        }

        function saveDataInCache(data) {
            var dateCourante = new Date();
            $storage.set('sale_locations', data);
            $storage.set('date_sale_locations',dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
            return data;
        }

        /**
         * Sale is in cache and up to date ?
         * @returns {boolean}
         */
        function inCache(){
            var dateCourante = new Date();
            var dateStorage = $storage.get('date_sale_locations');
            return (dateStorage !== null) && (dateStorage === dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
        }

        function filterEmptySaleLocations(result) {
            return lodash.filter(result.data, function(saleLocation) {
                return (saleLocation.offres && saleLocation.offres.length > 0);
            });
        }

        function processData(result) {
            var data = lodash.forEach(result, transform);
            return data;
        }

        function transform(obj) {
            obj = transformImagesUrls(obj);
            obj = transformCoordinates(obj);
            return obj;
        }
        /**
         * transforms offer and add 3 new attributes:
         * annonceur.image_advertiser
         * annonceur.image_logo_small
         * annonceur.image_logo_big
         * @param {any} obj 
         * @returns 
         */
        function transformImagesUrls(obj) {
            var ia = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_advertiser']) + obj.annonceur.photo;
            obj = lodash.set(obj, 'annonceur.image_advertiser', ia);
            var ils = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_logo_small']) + obj.annonceur.logoAnnonceur;
            obj = lodash.set(obj, 'annonceur.image_logo_small', ils);
            var ilb = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_logo_big']) + obj.annonceur.logoAnnonceur;
            obj = lodash.set(obj, 'annonceur.image_logo_big', ilb);
            return obj;
        }

        function transformCoordinates(obj) {
            obj = lodash.set(obj, 'lat', lodash.toNumber(obj.latitude || obj.lat));
            lodash.unset(obj, 'latitude');
            obj = lodash.set(obj, 'lng', lodash.toNumber(obj.longitude || obj.lng));
            lodash.unset(obj, 'longitude');
            return obj;
        }
        return {
            'getAll': getAll,
            'save': saveDataInCache
        };
    }
})();