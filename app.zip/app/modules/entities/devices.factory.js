(function() {
    angular
        .module('purple-wind.entities')
        .factory('deviceFactory', deviceFactory);

    function deviceFactory($requester) {
        function uploadOneSignalData(data) {
            $requester.api('devices', data);
        }

        return {
            'uploadOneSignalData': uploadOneSignalData
        };
    }
})();