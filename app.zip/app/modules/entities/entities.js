(function() {
    angular
        .module('purple-wind.entities', []);
})();