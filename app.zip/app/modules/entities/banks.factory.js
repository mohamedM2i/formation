(function() {
    angular
        .module('purple-wind.entities')
        .factory('banksFactory', banksFactory);

    function banksFactory($requester, $q, $storage, $filter, lodash) {
        var banks = [];
        var banksTranslationData = '';

        /**
         * Get the full set of banks from the server
         * Important: if the data is not reachable from servers, the data is retrieved from cache
         * @returns a promise that contains processed data
         */
        function getAllFromServer() {
            function processData(result) {
                function addBank(obj) {
                    return banks.push({ name: obj.nom, fullName: obj.nomComplet });
                }

                banks = [];
                lodash.forEach(result.data, addBank);
                $storage.set('banks', banks);
                return banks;
            }

            return $requester
                .api('banks')
                .then(processData, loadDataFromCache);
        }

        /**
         * loads banks data from cache
         * @returns Array of sale locations stored previously
         */
        function loadDataFromCache() {
            var cache = $storage.get('banks');
            return lodash.toArray(cache);
        }

        /**
         * Get the full set of banks from the memory
         * Important: if the data is not reachable from servers, the data is retrieved from a var ou from the cache
         * @returns an array of banks
         */
        function getAllFromFactory() {
            if (banks.length === 0) { loadDataFromCache(); }
            return banks;
        }


        /**
         * Get the full set of banks from the memory
         * Important: if the data is not reachable from servers, the data is retrieved from a var ou from the cache
         * @returns an string with all banks
         */
        function translationData() {
            if (banksTranslationData.length === 0) {
                lodash.forEach(banks, addBankTranslationData);
            }

            return { banks: banksTranslationData };
        }

        function addBankTranslationData(bank, key) {
            banksTranslationData += 'de ' + bank.fullName + ((key === banks.length - 2) ? ' ' + $filter('translate')('OR') + ' ' : ((key < banks.length - 2) ? ', ' : ''));
        }

        return {
            'getAllFromServer': getAllFromServer,
            'getAllFromFactory': getAllFromFactory,
            'translationData': translationData
        };
    }
})();