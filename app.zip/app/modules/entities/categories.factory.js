(function() {
    angular
        .module('purple-wind.entities')
        .factory('categoriesFactory', categoriesFactory);

    function categoriesFactory($requester, $q, $storage, $filter, lodash) {
        var categories;

        function getAllFromServer() {
            var deferred = $q.defer();
            if (inCache()){
                deferred.resolve(loadDataFromCache());
                return deferred.promise;
            } else {
                return $requester
                .api('categories')
                .then(processData, loadDataFromCache);
            }
        }

        function processData(result) {
            var dateCourante = new Date();
            categories = [];
            lodash.forEach(result.data, processCategories);
            $storage.set('categories', categories);
            $storage.set('date_categories',dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
            return categories;
        }

        function processCategories(item) {
            item.image = 'app-' + item.nom.toString().toLowerCase().replace(/[\u0300-\u036f]/g, '');
            categories.push(item);
        }

        /**
         * loads categories data from cache
         * @returns Array of categories stored previously
         */
        function loadDataFromCache() {
            var cache = $storage.get('categories');
            return lodash.toArray(cache);
        }

        /**
         * Categories is in cache and up to date ?
         * @returns {boolean}
         */
        function inCache(){
            var dateCourante = new Date();
            var dateStorage = $storage.get('date_categories');
            return (dateStorage !== null) && (dateStorage === dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
        }

        /**
         * Get the full set of categories from the memory
         * Important: if the data is not reachable from servers, the data is retrieved from a var ou from the cache
         * @returns an array of categories
         */
        function getAllFromFactory() {
            if (categories.length === 0) { loadDataFromCache(); }
            return categories;
        }


        return {
            'getAllFromServer': getAllFromServer,
            'getAllFromFactory': getAllFromFactory,
            'processCategories': processCategories
        };
    }
})();