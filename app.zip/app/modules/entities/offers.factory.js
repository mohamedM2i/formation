(function() {
    angular
        .module('purple-wind.entities')
        .factory('offers', offersFactory);

    function offersFactory($requester, $q, $storage, lodash, urls, config) {
        /**
         * gets the full set of offers, process it in order to return only the sale location that have offers
         * Important: if the data is not reachable from servers, the data is retrieved from cache 
         * @returns a promise that contains processed data
         */
        function getAll() {
            var deferred = $q.defer();
            var address = $storage.get('email');
            if (inCache()){
                deferred.resolve(loadDataFromCache());
                return deferred.promise;
            } else {
                return $requester
                        .api('offers', { 'email': address })
                        .then(processData, loadDataFromCache);
            }
        }
        /**
         * get an offer from cache
         * P.S: As discussed, no need to call WS to get offer detail for now
         * @param {number} id Id of the target offer
         * @returns target offer 
         */
        function get(id) {
            var offer = lodash.find($storage.get('offers'), function(offer) {
                return offer.id === lodash.toNumber(id);
            });
            return offer;
        }


        function processData(result) {
            var data = lodash.forEach(result.data, transform);
            return data;
        }

        function transform(obj) {
            obj = transformCategories(obj);
            obj = transformImagesUrls(obj);
            return obj;
        }

        function transformCategories(obj) {
            obj.categories = [];
            lodash.forEach(obj.annonceur.categories, function(category) {
                obj.categories.push({
                    'name': category,
                    'icon': iconize(category)
                });
            });
            return obj;
        }

        function iconize(category) {
            return 'app-' + category.toString().toLowerCase().replace(/[\u0300-\u036f]/g, '');
        }
        /**
         * loads offers data from cache
         * @returns Array of sale locations stored previously
         */
        function loadDataFromCache() {
            var cache = $storage.get('offers');
            return lodash.toArray(cache);
        }
        /**
         * save the offers in cache
         * @param {object} response server response 
         * @returns offers collection
         */
        function saveDataInCache(data) {
            var dateCourante = new Date();
            $storage.set('offers', data);
            $storage.set('date_offers',dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
            return data;
        }

        /**
         * Offers is in cache and up to date ?
         * @returns {boolean}
        */
        function inCache(){
            var dateCourante = new Date();
            var dateStorage = $storage.get('date_offers');
            return (dateStorage !== null) && (dateStorage === dateCourante.getFullYear()+'-'+dateCourante.getQuantiemeInYear());
        }

      /**
       * Update the consult information of an offer from cache
       * @param id
       */
        function consultOfferInCache(id){
            var offersCollection = $storage.get('offers');
            lodash.forEach(offersCollection, function(item) {
                if (item.id === lodash.toNumber(id)) {
                    item.consulte = true;
                }
            });
            $storage.set('offers', offersCollection);
        }

        /**
         * transforms offer and add 3 new attributes:
         * annonceur.image_advertiser
         * annonceur.image_logo_small
         * annonceur.image_logo_big
         * @param {object} obj offer to transform
         * @returns transformed object
         */
        function transformImagesUrls(obj) {
            var ia = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_advertiser']) + obj.annonceur.photo;
            obj = lodash.set(obj, 'annonceur.image_advertiser', ia);
            var ils = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_logo_small']) + obj.annonceur.logoAnnonceur;
            obj = lodash.set(obj, 'annonceur.image_logo_small', ils);
            var ilb = $requester.buildURL(config.env.domain[config.env.target].root, urls['image_logo_big']) + obj.annonceur.logoAnnonceur;
            obj = lodash.set(obj, 'annonceur.image_logo_big', ilb);
            return obj;
        }

        function consult(id) {
            var address = $storage.get('email');
            return $requester.api('offer_consult', { 'email': address, 'idOffre': id });
        }

        return {
            'getAll': getAll,
            'get': get,
            'consult': consult,
            'consultOfferInCache': consultOfferInCache,
            'save': saveDataInCache
        };
    }
})();