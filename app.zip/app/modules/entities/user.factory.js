(function() {
    angular
        .module('purple-wind.entities')
        .factory('user', userFactory);

    function userFactory() {
        function create() {
            return {
                'email': ''
            };
        }
        return {
            'new': create
        };
    }
})();