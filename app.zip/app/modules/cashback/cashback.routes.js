(function() {
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.cashback', {
                url: '/cashback',
                views: {
                    'tab-cashback': {
                        templateUrl: 'modules/cashback/cashback.html',
                        controller: 'CashBackCtrl',
                        controllerAs: 'vm'
                    }
                },
                resolve: {
                    cb: function cbFn(CashbackService){
                        return CashbackService.getData();
                    }
                }
            });
    }
})();