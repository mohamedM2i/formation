(function() {
    angular
        .module('purple-wind.tabs')
        .service('CashbackService', service);

    function service($q, $requester, lodash, $storage) {
        function getCashBackList() {
            var dfd = $q.defer();
            $requester
                .api('cashbacks', { 'email': $storage.get('email') })
                .then(function(success) {
                    dfd.resolve(success.data);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }

        function buildCashBackAccordions(data) {
            lodash.forEach(data, function(element) {
                element.gainEnCours.show = true;
                element.gainRemboursee.show = true;
                lodash.forEach(element.gainEnCours.gainMois, function(gain) {
                    gain.show = false;
                    lodash.forEach(gain.gains, function(transaction) {
                        transaction.show = false;
                    });
                });
                lodash.forEach(element.gainRemboursee.gainMois, function(gain) {
                    gain.show = false;
                    lodash.forEach(gain.gains, function(transaction) {
                        transaction.show = false;
                    });
                });
            });

            return data;
        }

        function getSalesLocationLogo(nom) {
            var offers = $storage.get('offers');
            var logo = '';

            for (var i = 0; i < offers.length; i++) {
                if (offers[i].annonceur.nom == nom) {
                    logo=offers[i].annonceur.image_logo_small;
                    break;
                }
            }

            return logo;
        }

        return {
            'getData': getCashBackList,
            'getSalesLocationLogo': getSalesLocationLogo,
            'build': buildCashBackAccordions
        };

    }
})();