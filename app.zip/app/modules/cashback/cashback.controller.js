(function() {
    angular
        .module('purple-wind.tabs')
        .controller('CashBackCtrl', ctrl);

    function ctrl(CashbackService, cb, $scope) {
        var vm = this;
        // vm.nocashback = false;
        var data = CashbackService.build(cb);

        vm.cartes = [];

        vm.loading=false;
        
                vm.loadTotal = function(datas){
                     vm.gainRemboursee =0;
                     vm.gainEnCours=0;
                     vm.gainRefusee=0;
                     vm.cartes = [];
                    datas.forEach(function(ele){
                        vm.gainRemboursee += ele.gainRemboursee.montant;
                        vm.gainEnCours += ele.gainEnCours.montant;
                        vm.gainRefusee += ele.gainRefusee.montant;
                        vm.cartes.push({typeCarte : ele.typeCarte, numDesensibilise : ele.numDesensibilise })
                    });
        
                }
        
                vm.loadTotal(data);
                
                vm.loadGain = function (index) {
                    vm.loading=true;
                    vm.numDesensibilise = data[index].numDesensibilise;
                    vm.typeCarte = data[index].typeCarte;
                    vm.getGains(data[index]);
                    vm.loading=false;
                }
        
                vm.getGains=function (data) {
                    var list = [];
        
                    data.gainRemboursee.gainMois.forEach(function(element) {
                        element.gains.forEach(function(el){
                            el.type=1;
                            el.logo=CashbackService.getSalesLocationLogo(el.enseigne);
                            list.push(el);
                        });
                    });
        
                     data.gainEnCours.gainMois.forEach(function(element) {
                        element.gains.forEach(function(el){
                            el.type=0;
                            el.logo=CashbackService.getSalesLocationLogo(el.enseigne);
                            list.push(el);
                        });
                    });
        
                     data.gainRefusee.gainMois.forEach(function(element) {
                        element.gains.forEach(function(el){
                            el.type=-1;
                            el.logo=CashbackService.getSalesLocationLogo(el.enseigne);
                            list.push(el);
                        });
                    });
        
        
                    vm.gains=list;
        
        
                }
        
                vm.loadGain(0);
        
                
        
                 $scope.$on('$ionicSlides.slideChangeStart', function(event, data) {
                    $scope.$apply(vm.loadGain(data.slider.activeIndex)); 
                });
        
        
                vm.toggleGroup = function (group) {
                    group.show = !group.show;
                };
                vm.isGroupShown = function (group) {
                    return (group) ? group.show : false;
                };
        
                vm.options = {
                    loop: false,
                    effect: 'slide',
                    speed: 500
                };
        

      
    }
})();