(function() {
    angular
        .module('purple-wind.optin')
        .controller('OptinCtrl', ctrl);

    function ctrl($state, OptinService) {
        var vm = this;

        function goToCGUs() {
            OptinService
                .accepted()
                .then(function() {
                    $state.go('cgu');
                });
        }
        vm.goToCGUs = goToCGUs;
    }
})();