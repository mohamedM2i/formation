(function() {
    angular
        .module('purple-wind.optin')
        .service('OptinService', svc);

    function svc($q, $requester, $storage) {

        function accept() {
            var dfd = $q.defer();
            var res = $storage.set('optinAccepted', true);
            if (res) {
                dfd.resolve();
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }
        return {
            accepted: accept
        };
    }
})();