(function() {
    angular
        .module('purple-wind.optin')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('optin', {
                url: '/optin',
                templateUrl: 'modules/optin/optin.html',
                controller: 'OptinCtrl',
                controllerAs: 'optin'
            });
    }
})();