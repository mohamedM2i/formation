(function() {
    angular
        .module('purple-wind.optin', []);
})();