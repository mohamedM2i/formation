(function() {
    angular
        .module('purple-wind.tabs')
        .service('FaqService', service);

    function service($q, $requester, lodash) {
        function getFAQs() {
            var dfd = $q.defer();
            $requester
                .api('faq')
                .then(function(success) {
                    dfd.resolve(success.data);
                }, function(error) {
                    dfd.reject(error);
                });
            return dfd.promise;
        }

        function buildAccordion(data) {
            lodash.forEach(data, function(element) {
                element.show = false;
                lodash.forEach(element.questionFAQS, function(question) {
                    question.show = false;
                });
            });
            return data;
        }

        return {
            'getData': getFAQs,
            'build': buildAccordion
        };

    }
})();