(function() {
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.faq', {
                url: '/faq',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/faq/faq.html',
                        controller: 'FaqCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();