(function() {
    angular
        .module('purple-wind.tabs')
        .controller('FaqCtrl', ctrl);

    function ctrl($stateParams, FaqService) {
        var vm = this;
        vm.mail = $stateParams.mail;

        FaqService
            .getData()
            .then(function(data) {
                vm.groups = FaqService.build(data);
            });

        vm.toggleGroup = function(group) {
            group.show = !group.show;
        };
        vm.isGroupShown = function(group) {
            return (group) ? group.show : false;
        };
    }
})();