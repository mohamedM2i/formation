(function () {
    angular
        .module('purple-wind.tabs')
        .controller('FeedbackCtrl', ctrl);

    function ctrl($state, $requester, $storage) {
        var vm = this;
        vm.titre = '';
        vm.commentaire = '';
        vm.email = $storage.get('email');


        vm.valider = function () {
                if (vm.titre != '' && vm.commentaire != '') {
                    $requester.api('feedback', { 'titre': vm.titre, 'comment': vm.commentaire, 'clientId': 16954});
                    $state.go('app.account');
                };
                 
        
        };

        



    }
})();