(function() {
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.feedback', {
                url: '/feedback',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/feedback/feedback.html',
                        controller: 'FeedbackCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();