(function() {
    angular
        .module('purple-wind.enroll', []);
})();