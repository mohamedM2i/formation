(function() {
    angular
        .module('purple-wind.enroll')
        .controller('EnrollActivationCtrl', ctrl);

    function ctrl(EnrollService, $state, $stateParams) {
        var vm = this;
        vm.mail = $stateParams.mail;
        vm.reset = $stateParams.reset;

        function redirect(route, params) {
            $state.go(route, params);
        }

        function activate(route) {
            if (!vm.reset) {
                EnrollService
                    .activate(vm.mail, vm.code)
                    .then(function() {
                        redirect(route, {
                            'mail': vm.mail,
                            'code': vm.code
                        });
                    }, handleActivationCodeInvalid);
            } else {
                redirect(route, {
                    'mail': vm.mail,
                    'code': vm.code
                });
            }
        }

        function initPassWord() {
            EnrollService.validate(vm.mail);
        }

        function handleActivationCodeInvalid() {
            vm.codeInvalid = true;
            var id = document.getElementById('usercode');
            angular.element(id).addClass('app-input-error');
        }
        vm.activateUser = activate;
        vm.resendCode = initPassWord;
    }
})();