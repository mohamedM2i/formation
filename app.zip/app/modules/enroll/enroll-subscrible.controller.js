(function() {
    angular
        .module('purple-wind.enroll')
        .controller('EnrollSubscribeCtrl', ctrl);

    function ctrl(EnrollService, $state, $stateParams, $ionicHistory) {
        var vm = this;
        vm.mail = $stateParams.mail;

        vm.banksTranslationData = EnrollService.translationData();
        vm.banks = EnrollService.getBanksList();

        vm.groups = [{
            items: [],
            show: true
        }];

        vm.toggleGroup = function(group) {
            group.show = !group.show;
        };
        vm.isGroupShown = function(group) {
            return group.show;
        };

        function redirect(route, params) {
            $state.go(route, params);
        }

        vm.precedent = function() {
            $ionicHistory.goBack();
        }

        vm.signUp = function() {
            if (vm.establishment) {
                if (vm.establishment !== 'Other') {
                    EnrollService.signUp(vm.mail, vm.establishment).then(function() {
                        redirect('enroll.acknowledgment');
                    });
                } else {
                    redirect('enroll.acknowledgment-other');
                }
            }
        }

    }
})();