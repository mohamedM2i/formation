(function() {
    angular
        .module('purple-wind.enroll')
        .config(cfg);

    function cfg($stateProvider) {
        $stateProvider
            .state('enroll', {
                url: '/enroll',
                abstract: true,
                templateUrl: 'modules/enroll/enroll.html'
            })
            .state('enroll.password', {
                url: '/password',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-password.html',
                        controller: 'EnrollPasswordCtrl',
                        controllerAs: 'vm'
                    }
                },
                params: {
                    'code': null,
                    'mail': null,
                    'isReset': false,
                    'update': null
                }
            })
            .state('enroll.activation', {
                url: '/activation',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-activation.html',
                        controller: 'EnrollActivationCtrl',
                        controllerAs: 'vm'
                    }
                },
                params: {
                    'mail': null,
                    'reset': false
                }
            })
            .state('enroll.subscribe', {
                url: '/subscribe',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-subscribe.html',
                        controller: 'EnrollSubscribeCtrl',
                        controllerAs: 'vm'
                    }
                },
                params: {
                    'mail': null
                }
            })
            .state('enroll.acknowledgment', {
                url: '/acknowledgment',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-acknowledgment.html'
                    }
                },
                params: {
                    'mail': null
                }
            })
            .state('enroll.acknowledgment-other', {
                url: '/acknowledgment',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-acknowledgment-other.html'
                    }
                }
            })
            .state('enroll.email', {
                url: '/email',
                views: {
                    'step': {
                        templateUrl: 'modules/enroll/enroll-email.html',
                        controller: 'EnrollEmailCtrl',
                        controllerAs: 'vm'
                    }
                }
            });
    }
})();