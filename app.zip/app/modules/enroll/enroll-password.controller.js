(function() {
    angular
        .module('purple-wind.enroll')
        .controller('EnrollPasswordCtrl', ctrl);

    function ctrl(EnrollService, $state, $stateParams, $ionicHistory, $scope, $startup, deviceFactory, $storage, $styler) {
        var vm = this;
        vm.mail = $stateParams.mail;
        vm.code = $stateParams.code;
        vm.isReset = $stateParams.isReset;
        vm.isPasswordInvalid = false;

        $scope.$on('$ionicView.enter', function() {
            $scope.$apply(function() {
                vm.confirm_pwd = '';
                vm.password = null;
                vm.oldPassword = '';
                vm.isPasswordInvalid = false;
            });

        });

        function redirect(route, params) {
            $state.go(route, params);
        }


        function passwordInvalid() {
            vm.isPasswordInvalid = true;
        }

        function subscribe() {
            EnrollService
                .validatePassword(vm.password)
                .then(function() {
                    vm.isPasswordInvalid = false;
                    if (vm.isReset) {
                        EnrollService
                            .changePassWord({
                                'newPassword': vm.password,
                                'oldPassword': vm.oldPassword
                            }).then(function() {
                                $ionicHistory.goBack();
                            });
                    } else {
                        EnrollService
                            .finishSubscription({
                                'email': vm.mail,
                                'newPassword': vm.password,
                                'key': vm.code.toString()
                            })
                            .then(function() {
                                EnrollService
                                    .authenticate(vm.mail, vm.password)
                                    .then(function(res) {
                                        EnrollService.saveToken(res.data['id_token']);
                                        $styler.change();
                                        $startup.notification($storage.get('oneSignal'));
                                        redirect('app.home');
                                    });
                            });
                    }

                }, passwordInvalid);

        }
        vm.updateColor = function() {

        }
        vm.subscribe = subscribe;
    }
})();