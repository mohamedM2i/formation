(function() {
    angular
        .module('purple-wind.enroll')
        .controller('EnrollEmailCtrl', ctrl);

    function ctrl(EnrollService, banksFactory, $state, $stateParams, $modal, $scope, $update, $tag, $styler, $startup, $storage, deviceFactory) {
        var vm = this;
        EnrollService.saveRoute('enroll.email');
        $update.displayUpdateMessage($stateParams.update);

        vm.banksTranslationData = banksFactory.translationData();
        banksFactory.getAllFromServer();

        function go(route) {
            EnrollService
                .check(vm.mail)
                .then(function(mail) {
                    EnrollService
                        .validate(mail)
                        .then(function(res) {
                            EnrollService.saveEmail(vm.mail);
                            if (res.status === 200) {
                                openModal();
                            } else {
                                redirect(route, { 'mail': vm.mail });
                            }
                        }, handleNonExistantEmail);
                }, handleEmailInvalid);
        }

        function logIn() {
            EnrollService
                .authenticate(vm.mail, vm.password)
                .then(function(res) {
                    EnrollService.saveToken(res.data['id_token']);
                    $styler.change();
                    closeModal();
                    $startup.notification($storage.get('oneSignal'));
                    redirect('app.home');
                }, handleCredentialsInvalid);
        }

        $modal.load('modules/login/login.html', $scope, 'slide-in-up')
            .then(function(modal) {
                vm.modal = modal;
            });

        function openModal() {
            if (vm.modal) {
                $tag.sendTagPage('login.html', {});
                vm.modal.show();
            }
        }

        function closeModal() {
            if (vm.modal) {
                vm.modal.hide();
            }
        }

        // Cleanup the modal when we're done with it!
        $scope.$on('$destroy', function() {
            if (vm.modal) {
                vm.modal.remove();
            }
        });

        function redirect(route, params) {
            $state.go(route, params);
        }

        function handleEmailInvalid() {
            vm.emailInvalid = true;
            var id = document.getElementById('useremail');
            angular.element(id).addClass('app-input-error');
        }

        function handleNonExistantEmail(error) {
            if (error.status >= 400) {
                redirect('enroll.subscribe', { mail: vm.mail });
            } else {
                handleEmailInvalid();
            }
        }

        function handleCredentialsInvalid() {
            vm.credentialsInvalid = true;
            var id = document.getElementById('userpwd');
            angular.element(id).addClass('app-input-error');
        }

        function resendPW() {
            EnrollService
                .initPassWord(vm.mail)
                .then(function() {
                    closeModal();
                })
                .then(function() {
                    redirect('enroll.activation', { 'mail': vm.mail, 'reset': true });
                });
        }
        vm.forgottenPassword = resendPW;
        vm.logIn = logIn;
        vm.closeModal = closeModal;
        vm.checkMail = go;
    }
})();