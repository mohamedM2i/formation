(function() {
    angular
        .module('purple-wind.enroll')
        .service('EnrollService', service);

    function service($q, $requester, $storage, $security, banksFactory, lodash) {
        /**
         * check if an e-mail address is legit or not asynchronously
         * back on regular expression
         * @param {any} email email to check
         * @returns promise
         */
        function validateEmail(email) {
            var dfd = $q.defer(),
                re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (re.test(email)) {
                dfd.resolve(email);
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }

        function validatePassword(password) {
            var dfd = $q.defer();
            var _regex = /[$-/:-?{-~!"^_`\[\]]/g;
            var _lowerLetters = /[a-z]+/.test(password);
            var _upperLetters = /[A-Z]+/.test(password);
            var _numbers = /[0-9]+/.test(password);
            var _symbols = _regex.test(password);
            var pLength = password.length >= 4;
            if (pLength) {
                dfd.resolve(password);
            } else {
                dfd.reject();
            }

            return dfd.promise;
        }

        /**
         * call the validation api on server to check if user exists:
         * - user exists and activated
         * - user exists but not activated
         * - user does not exist
         * @param {any} email email to check
         * @returns promise to handle. PS: status codes from 4xx and above should be handled as a reject.
         */
        function validateOnServer(email) {
            var dfd = $q.defer();
            $requester
                .api('validate_user', email)
                .then(function(res) {
                    if (res.status < 400) {
                        $storage.set('reseau', res.data);
                        dfd.resolve(res);
                    } else {
                        dfd.reject(res);
                    }
                }, function(err) {
                    dfd.reject(err);
                });
            return dfd.promise;
        }
        /**
         * saves the user email address on localStorage
         * @param {any} email email to store
         * @returns promise
         */
        function saveEmail(email) {
            var dfd = $q.defer();
            if ($storage.set('email', email)) {
                dfd.resolve();
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }
        /**
         * activate an user with a key that is sent
         * to user by e-mail
         * @param {string} email email address
         * @param {string} key activation key 
         * @returns promise
         */
        function activateUser(email, key) {
            var dfd = $q.defer();
            $requester
                .api('activate_user', {
                    'email': email,
                    'key': key
                })
                .then(function(success) {
                        if (success.status < 500) {
                            dfd.resolve(success.data);
                        } else {
                            dfd.reject(success.data);
                        }
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }
        /**
         * authenticate an user using credentials
         * @param {string} login user login
         * @param {string} pwd user password
         * @returns promise to handle
         */
        function authenticate(login, pwd) {
            return $security.authenticateUser(login, pwd);
        }



        function signUp(email, banque) {
            var dfd = $q.defer();
            $requester
                .api('inscription', {
                    'email': email,
                    'banque': banque
                })
                .then(function(success) {
                        dfd.resolve(success);
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }

        /**
         * finalize the subscription process by sending
         * informations about the new user
         * @param {object} data object that has : email {string},newPassword {string}, key {key} 
         * @returns promise to handle
         */
        function finishPassWord(data) {
            var dfd = $q.defer();
            $requester
                .api('finish_password', data)
                .then(function(success) {
                        dfd.resolve(success);
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }

        /**
         * Modifie the user password
         * @param {object} data object that has : oldPassword {string},newPassword {string}
         * @returns promise to handle
         */
        function changePassWord(data) {
            var dfd = $q.defer();
            $requester
                .api('change_password', data)
                .then(function(success) {
                        dfd.resolve(success);
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }

        /**
         * initialize the password retrieval process in the backoffice
         * @param {string} email user email
         * @returns promise to handle
         */
        function initPassWord(email) {
            var dfd = $q.defer();
            $requester
                .api('init_password', {
                    'mail': email
                })
                .then(function(success) {
                        dfd.resolve(success);
                    },
                    function(error) {
                        dfd.reject(error);
                    });
            return dfd.promise;
        }

        /**
         * saves the user token on localStorage
         * @param {string} token token to store
         * @returns promise
         */
        function saveToken(token) {
            var dfd = $q.defer();
            if ($storage.set('tokenID', token)) {
                dfd.resolve();
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }

        /**
         * saves the latest route to be used as a startup route
         * @param {string} route 
         * @returns promise
         */
        function saveRoute(route) {
            var dfd = $q.defer();
            if ($storage.set('landing_state', route)) {
                dfd.resolve();
            } else {
                dfd.reject();
            }
            return dfd.promise;
        }

        function getBanksList() {
            return banksFactory.getAllFromFactory();
        }

        function translationData() {
            return banksFactory.translationData();
        }

        return {
            'activate': activateUser,
            'check': validateEmail,
            'validatePassword': validatePassword,
            'validate': validateOnServer,
            'saveEmail': saveEmail,
            'authenticate': authenticate,
            'finishSubscription': finishPassWord,
            'initPassWord': initPassWord,
            'saveToken': saveToken,
            'changePassWord': changePassWord,
            'saveRoute': saveRoute,
            'signUp': signUp,
            'getBanksList': getBanksList,
            'translationData': translationData
        }
    }
})();