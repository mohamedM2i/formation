(function() {
    angular
        .module('purple-wind.cgu')
        .config(routes);

    function routes($stateProvider) {
        $stateProvider
            .state('app.contact', {
                url: '/contact',
                views: {
                    'tab-account': {
                        templateUrl: 'modules/contact/contact-phone.html'
                    }
                }
            });
    }
})();