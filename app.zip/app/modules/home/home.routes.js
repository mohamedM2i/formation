(function() {
    angular
        .module('purple-wind.tabs')
        .config(routes);

    function routes($stateProvider, $logProvider) {
        // Desactivation des logs de Leaflet
        // TODO: retirer le commentaire de la ligne précédente
        // (Ligne à priori initile depuis qu'on n'utilise plus la directive Leaflet !!!)
        // $logProvider.debugEnabled(false);

        $stateProvider
            .state('app.home', {
                url: '/home',
                views: {
                    'tab-offers': {
                        templateUrl: 'modules/home/home.html',
                        controller: 'HomeCtrl',
                        controllerAs: 'home'
                    }
                },
                params: {
                    update: null
                }
            });
    }
})();