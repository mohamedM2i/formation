(function () {
    angular
        .module('purple-wind.tabs')
        .service('HomeService', svc);

    function svc($q, $filter, $permissions, $map, categoriesFactory, deviceFactory, saleLocations, offers, lodash, config, geolocation, $storage, $translate, $tag, $popup) {
        var toggleMap = true;

        /**
         * load map configuration
         * @returns object
         */
        function loadMap() {
            var _cfg = $map.load();
            _cfg.network = $storage.get('reseau').toString().toLowerCase();
            return _cfg;
        }

        /**
         * loads all the sale locations and offers
         * @returns promise
         */
        function loadOffers() {
            return $q.all([
                saleLocations.getAll(),
                offers.getAll()
            ]).then(calculeSaleLocationsForOffres)
                .then(processData)
                .then(processDisplayData)
                .then(saveDataInCache);

        }

        function loadCategories() {
            return categoriesFactory.getAllFromServer();
        }

        function saveDataInCache(data) {
            saleLocations.save(data.saleLocations);
            offers.save(data.offers);
            return data;
        }

        /**
         * calculate the number of participating sale points
         * @param {number} offerId target offer
         * @returns total of participating sale points for the target offer
         */
        function getSaleLocationsCount(offerId, list) {
            var saleLocations = list;
            var res = [];
            lodash.forEach(saleLocations, function (location) {
                lodash.find(location.offres, function (id) {
                    if (id === lodash.toNumber(offerId)) {
                        res.push(location);
                    }
                });
            });
            return res.length;
        }

        function calculeSaleLocationsForOffres(data) {
            var offers = [];
            lodash.forEach(data[1], function (offer) {
                offer.saleLocationsCount = getSaleLocationsCount(offer.id, data[0]);
                offers.push(offer);
            });

            data[1] = offers;
            return data;
        }

        function processData(arr) {
            return {
                'saleLocations': distinctObjects(arr[0]),
                'offers': arr[1]
            };
        }

        function distinctObjects(objects){
            var distinctObj = [];
            var distinctids = [];

            for(var i = 0 ; i < objects.length ; i++){
                if(distinctids.indexOf(objects[i].id) < 0 ){
                    distinctObj.push(objects[i]);
                    distinctids.push(objects[i].id);

                }
            }
            return distinctObj;
         }

        function processDisplayData(data) {
            var offer;
            lodash.forEach(data.saleLocations, function (location) {
                offer = getOfferFrom(data.offers, location.offres[0]);
                if (offer) {
                    location.categories = offer.annonceur.categories;
                    location.multiple = offer.multiple;
                    if (offer.multiple) {
                        location.cashBack = (offer.maxCashBackPourcentage > 0) ? offer.maxCashBackPourcentage : offer.maxCashBackFixe;
                        location.cashBackSymbol = (offer.maxCashBackPourcentage > 0) ? '%' : '€';
                    } else {
                        location.cashBack = (offer.cashBackPourcentage > 0) ? offer.cashBackPourcentage : offer.cashBackFixe;
                        location.cashBackSymbol = (offer.cashBackPourcentage > 0) ? '%' : '€';
                    }

                    location.cashBackOfferID = offer.id;
                }
            });
            return data;
        }

        function getOfferFrom(collection, id) {
            return lodash.find(collection, function (item) {
                return item.id === id;
            })
        }

        function centerMap(position, zoom) {
            var dfd = $q.defer();
            if (position.latitude && position.longitude) {
                dfd.resolve({
                    lat: position.latitude,
                    lng: position.longitude,
                    zoom: zoom
                });
            } else {
                dfd.reject('No position');
            }
            return dfd.promise;
        }

        function buildMarker(annonceur, icon, translations) {
            var marker = {
                lat: annonceur.lat,
                lng: annonceur.lng,
                icon: icon,
                categories: annonceur.categories
            };
            if (translations) {
                marker.group = annonceur.codePostal.substr(0, 2);
                marker.message = buildPopUp(annonceur, translations);
                marker.popupOptions = { closeButton: false }
            }
            return marker;
        }

        function buildMarkers(saleLocations, volatile) {
            var _markers = [],
                _translate = {
                    'MAP_POPUP_OPENING': $translate.instant('MAP_POPUP_OPENING'),
                    'MAP_POPUP_LINK': $translate.instant('MAP_POPUP_LINK'),
                    'OFFER_DETAIL_CASHBACK': $translate.instant('OFFER_DETAIL_CASHBACK')
                };
            lodash.forEach(saleLocations, function (location) {
                _markers.push(buildMarker(location, geolocation.icons.default, _translate));
            });
            if (!volatile) {
                $storage.set('markers', _markers);
            }
            return _markers;
        }

        function buildCategory(annonceur) {
            var _res = '<div class="row">';
            lodash.forEach(annonceur.categories, function (category) {
                var _icon = 'app-' + category.toString().toLowerCase().replace(/[\u0300-\u036f]/g, '');
                _res += '<i class="icon ' + _icon + ' icon-category"></i><p class="icon-category">' + category + '</p>';
            });
            _res += '</div>'
            return _res;
        }

        function buildPopUp(annonceur, translations) {
            return '<div class="row no-padding"><div class="col"><div class="offer-popup-title">' + annonceur.annonceur.nom + '</div>' +
               '</div><div class="col popup-eye-container offer-visualized"><i class="icon app-vu popup-eye offer-visualized"><class="icon app-vu offer-status offer-visualized"></i></div></div>' +
                '<div class="col no-padding">' +
                buildCategory(annonceur) +
                '<div class="row"><i class="icon app-boutique icon-text"></i><p class="icon-text">' + annonceur.adresse1 + '</p></div>' +
                '<div class="row next-row"><p class="icon-text">' + annonceur.codePostal + ' ' + $filter('capitalize')(annonceur.ville, true) + '</p></div>' +
                (lodash.isNull(annonceur.horaires) ? '' : '<div class="row next-row"><p class="icon-text">' + translations.MAP_POPUP_OPENING + ': ' + annonceur.horaires.toLowerCase() + '</p></div>') +
                '<div class="row"><div class="col col-60 no-padding"><a class="button button-icon button-clear ion-arrow-right-b offer-popup-link" href="#/app/map/' + annonceur.cashBackOfferID + '">' + translations.MAP_POPUP_LINK + '</a></div>' +
                '<div class="col col-33 no-padding offer-popup-cashback">'+(annonceur.multiple ? '<div class="ng-binding" style="font-size: small">jusqu\'à</div>' : '') + $filter('cashback')(annonceur.cashBack, true) + annonceur.cashBackSymbol + '</div></div><div class="no-padding offer-popup-cashback-text">' + translations.OFFER_DETAIL_CASHBACK + '</div></div>';
        }

        function offerConsulted(id) {
            return offers.consult(id);
        }

        function saveOfferId(id) {
            var offersToSync = $storage.get('offersToSync') || [];
            offersToSync.push(id);
            $storage.set('offersToSync', lodash.uniq(offersToSync));
        }

        function tagPage(toggleToggle) {
            if (toggleToggle) { toggleMap = !toggleMap; }
            if (toggleMap) {
                $tag.sendTagPage('app.offers.map', {});
            } else {
                $tag.sendTagPage('app.offers.list', {});
            }
        }

        function getLocations(offerId) {
            var _saleLocations = $storage.get('sale_locations'),
                _res = [];
            lodash.forEach(_saleLocations, function (location) {
                if (lodash.indexOf(location.offres, offerId) >= 0) {
                    _res.push(location);
                }
            });
            return buildMarkers(_res, true);
        }

        function openHelperList() {
            return $popup.showBasicAlertDialog({
                'templateUrl': 'modules/helper/helper-list.html',
                'okText': $translate.instant('UNDERSTOOD_BTN')
            });
        }

        function openHelperMap() {
            return $popup.showBasicAlertDialog({
                'templateUrl': 'modules/helper/helper-map.html',
                'okText': $translate.instant('UNDERSTOOD_BTN')
            });
        }

        function processCategories(list) {
            return categoriesFactory.processCategories(list);
        }

        function getLocationList(offerId , saleLocations){
            _res = [];
             lodash.forEach(saleLocations, function(location) {
                if (lodash.indexOf(location.offres, offerId) >= 0) {
                    _res.push(location);
                }
            });
          return _res;
        }
 
         function getMinDistance(saleLocations){
            var minDistance ;
            if(saleLocations.length > 0){
              minDistance = saleLocations[0].distance ;
             lodash.forEach(saleLocations, function (location){
                 if(location.distance < minDistance){
                     minDistance = location.distance;
                 }
                 
             });
            }
             return minDistance;
         }
 
        function calculateDistance(data){
 
             $map.pinpoint().then(function (location) {
 
                var coords = {lat: location.coords.latitude,
                              lon: location.coords.longitude
                                };
 
                lodash.forEach(data.saleLocations, function(location) {
                    location.distance = $map.calculate(coords, { lat: location.lat , lon : location.lng});
               });
 
                 lodash.forEach(data.offers, function(offer) {
                   var result = getLocationList(offer.id , data.saleLocations);
                   offer.minDistance = getMinDistance(result);
                });
 
                           
 
             });
        }

        function recalculateDistance(data, location){

                var coords = {lat: location.coords.latitude,
                                lon: location.coords.longitude
                                };

                lodash.forEach(data.saleLocations, function(location) {
                    if(location.distance < 10){
                       location.distance = $map.calculate(coords, { lat: location.lat , lon : location.lng});
                    }
                });

                lodash.forEach(data.offers, function(offer) {
                    var result = getLocationList(offer.id , data.saleLocations);
                    offer.minDistance = getMinDistance(result);
                });
            
                                      
            
         }

        function processNotificationData() {
            // debugger;
            var _oneSignalUserID = $storage.get('OneSignalUserID'),
                _oneSignalPushToken = $storage.get('OneSignalPushToken'),
                _device = $storage.get('device');
            deviceFactory.uploadOneSignalData({
                'userUid': _oneSignalUserID,
                'notificationUid': _oneSignalPushToken,
                'marque': _device.manufacturer,
                'model': _device.model
            });
        }

        return {
            'loadMap': loadMap,
            'loadOffers': loadOffers,
            'centerMap': centerMap,
            'buildMarker': buildMarker,
            'buildMarkers': buildMarkers,
            'offerConsulted': offerConsulted,
            'saveOfferId': saveOfferId,
            'tagPage': tagPage,
            'getLocations': getLocations,
            'openHelperList': openHelperList,
            'openHelperMap': openHelperMap,
            'getCategories': loadCategories,
            'processCategories': processCategories,
            'processNotificationData': processNotificationData,
            'calculateDistance':calculateDistance,
            'recalculateDistance':recalculateDistance

        };
    }
})();