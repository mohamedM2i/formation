(function(){
  angular
  .module('purple-wind.home',[]);
})();
