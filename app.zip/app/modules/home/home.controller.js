(function() {
    angular
        .module('purple-wind.tabs')
        .controller('HomeCtrl', ctrl);

    function ctrl($scope, HomeService, $state, $stateParams, $storage, $update, $timeout, lodash, $ionicScrollDelegate, $map, $rootScope) {
        var home = this;
        home.toggleMap = false;
        home.pull = false;
        home.backup = {};

        home.sortItems = [ {id : 1 , nom : 'Plus proche' , icon : 'icon-apps-proche' , disabled : true} , 
                            {id : 2 , nom : 'Bientôt expiré' , icon : 'icon-apps-expire', disabled : false} ,
                            {id : 3 , nom : 'Plus récent' , icon : 'icon-apps-recent', disabled : false} , 
                            {id : 4, nom : 'Plus avantageux' , icon : 'icon-apps-coin-euro', disabled : false} ];
        home.selectedSortId=0;


        home.isDrowerSort = false ;

        if (window.cordova) HomeService.processNotificationData();

        $update.displayUpdateMessage($stateParams.update);
        $storage.set('landing_state', 'app.home');

        var helper_list_understood = $storage.get('helper_list_understood') || false,
            helper_map_understood = $storage.get('helper_map_understood') || false;

        home.map = HomeService.loadMap();

        HomeService
            .loadOffers()
            .then(function(data) {
                
                home.map.markers = HomeService.buildMarkers(data.saleLocations);
                home.backup.markers = home.map.markers;

                home.appSettings = $storage.get('settings');
                if(home.appSettings.geolocation){
                    HomeService.calculateDistance(data);
                    $scope.$broadcast('resortEvent',{ id : 1 } );
                }

                home.offers = data.offers;
                home.backup.offers = home.offers;
                home.data = data ;
            });

            function calculateDistance(){

                if(home.data){
                    HomeService.calculateDistance(home.data);
                    home.offers = home.data.offers;
                    home.backup.offers = home.offers;
                    if( home.selectedSortId < 2){
                         $scope.$broadcast('resortEvent',{ id : 1 } );
                    }
                }       
                $timeout(recalculateCurrentPosition,5000);
            }

            function recalculateCurrentPosition(){
                $timeout(recalculateCurrentPosition,5000);

                $map.pinpoint().then(function(position){
                    
                    var inMemoryPosition = $storage.get('lastcalculatedPosition');
                    if(inMemoryPosition && inMemoryPosition.coords){
                        var coords = {lat: position.coords.latitude,
                            lon: position.coords.longitude
                              };
                        var coords2 = {lat: inMemoryPosition.coords.latitude,
                                lon: inMemoryPosition.coords.longitude
                                  };
                       var distance = $map.calculate(coords , coords2);
                       if(distance > 0.01){
                         $scope.$broadcast('recalculateCurrentPosition', {position : position});
                       }

                       if(distance > 0.1 ){

                        $storage.set('lastcalculatedPosition', position);
                       
                       
                        HomeService.recalculateDistance(home.data, position);
                       

                        home.offers = home.data.offers;
                        home.backup.offers = home.offers;
                       
                       }
                    }else {
                        $storage.set('lastcalculatedPosition', position);     
                    } 
                });
                
            }

        ionic.on('calculateDistanceinit', calculateDistance);   
    
        $timeout(recalculateCurrentPosition,5000);

        HomeService.getCategories().then(function(data) {
            home.categories = data;
        });

        function toggleView() {
            home.toggleMap = !home.toggleMap;
            if (!home.toggleMap && !helper_list_understood) {
                $timeout(openHelperList, 1000);
            }
            HomeService.tagPage(true);
        }

        function switchIcon() {
            return home.toggleMap ? 'icon-apps-listes' : 'icon-apps-cartes';
        }


        function openHelperList() {
            HomeService
                .openHelperList()
                .then(function() {
                    helper_list_understood = true;
                    $storage.set('helper_list_understood', helper_list_understood);
                });
        }

        function openHelperMap() {
            HomeService
                .openHelperMap()
                .then(function() {
                    helper_map_understood = true;
                    $storage.set('helper_map_understood', helper_map_understood);
                });
        }

        function getCategories(data) {
            var _selection = processCategories(data);
            filterOffers(_selection);
            filterMarkers(_selection);
            home.filterOn = true;
        }

        function setSort(data) {  
           home.selectedSortId=data[0].id;
           $scope.$broadcast('resortEvent',{ id : data[0].id } );
        }

        function removeSort(data) {
            $scope.$broadcast('resortEvent',{ id : 0 } );
        }


        function processCategories(data) {
            var _res = [];
            lodash.forEach(data, function(item) {
                _res.push(item.nom);
            });
            return _res;
        }

        function removeCategories(data) {
            var _selection = processCategories(data);
            if (data.length === 0) {
                home.map.markers = home.backup.markers;
                home.offers = home.backup.offers;
                home.filterOn = false;
            } else {
                filterOffers(_selection);
                filterMarkers(_selection);
            }
        }

        function filterMarkers(categories) {
            home.map.markers = lodash.filter(home.backup.markers, function(marker) {
                return lodash.difference(marker.categories, categories).length !== marker.categories.length;
            });
        }

        function filterOffers(categories) {
            home.offers = lodash.filter(home.backup.offers, function(offer) {
                return lodash.difference(offer.annonceur.categories, categories).length !== offer.annonceur.categories.length;
            });
        }

        ionic.on('popUpOnpened', function() {
            if (!helper_map_understood) {
                $timeout(openHelperMap, 1000);
            }
        });

        home.onTouch = function() {
            if (home.pull) {
                home.pull = false;
            }
        };

        home.toggleDrawer = function(current) {
            $timeout(function ()  {
                toggleDrawerExe(current)
            }, 1);
            
        };

        function toggleDrawerExe(current){
           
            if(home.isDrowerSort === current){
                home.pull = !home.pull;
            } else  {
                home.pull = true ;
            }
            home.isDrowerSort = current;
            if (home.pull) $ionicScrollDelegate.scrollTop(true);
        };

        /*
        $scope.$on('$ionicView.beforeEnter', function() {
            if (home.offers) {
                home.offers = $storage.get('offers');
                home.backup.offers = home.offers;
            }
        });
        */

        home.switchIcon = switchIcon;
        home.toggleView = toggleView;
        home.getCategories = getCategories;
        home.setSort=setSort;
        home.removeSort=removeSort;
        home.removeCategories = removeCategories;
    }
})();