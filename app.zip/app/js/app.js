(function() {
    angular
        .module(
            'purple-wind', [
                //app dependencies
                'ionic',
                'ui.router',
                'pascalprecht.translate',
                'ngCookies',
                'ngCordova',
                'ngLodash',
                'LocalStorageModule',
                //app components dependencies
                'purple-wind.components',
                'purple-wind.filters',
                'purple-wind.entities',
                //app modules dependencies
                'purple-wind.intro',
                'purple-wind.enroll',
                'purple-wind.cgu',
                'purple-wind.optin',
                'purple-wind.tabs',
                'angular-inview'
            ]);
})();