(function() {
    angular
        .module('purple-wind')
        .run(runner);

    function runner($ionicPlatform, $storage, $styler, $startup, $rootScope, $translate, $tag, lodash, $cordovaAppVersion, offers, HomeService) {
        // TODO: à supprimer
        /*
        var countDigest = 1;
        console.log('Nb de cycle Digest:', countDigest);
        $rootScope.$watch(function() {
            countDigest++;
            console.log('Nb de cycle Digest:', countDigest);
        });
        */

        //Exec tag AT-Internet on View
        $rootScope.$on('$stateChangeSuccess', function(event, toState) {
            // console.log('Event $stateChangeSuccess: ' + toState.name);
            // handle event
            if (toState.name === 'app.home') {
                HomeService.tagPage(false);
            } else {
                $tag.sendTagPage(toState.name, {});
            }
        });

        //loads the default style in order to display content
        $styler.default();
        $translate('MONTHS').then(function(translation) {
            $storage.set('months', lodash.split(translation, ','));
        });
        $ionicPlatform.ready(startup);
        /* jshint ignore:start */
        var notificationOpenedCallback = function(jsonData) {};
        /* jshint ignore:end */
        /**
         * function that is executed at mobile app start 
         */
        function startup() {
            var route = $storage.get('landing_state') ? $storage.get('landing_state') : 'intro';
            if (window.StatusBar) {
                if (ionic.Platform.isIOS()) {
                    window.StatusBar.styleDefault();
                    // window.StatusBar.styleLightContent();
                    // window.StatusBar.overlaysWebView(false);
                }
                // window.StatusBar.backgroundColorByHexString('#E5E5E5');
                window.StatusBar.styleDefault();
            }

            if (ionic.Platform.isIOS() && cordova && cordova.plugins) {
                if (cordova.plugins.Keyboard) {
                    cordova.plugins.Keyboard.disableScroll(true);
                }
            }
            if (navigator && navigator.splashscreen) {
                navigator.splashscreen.hide();
            }

            $startup.init()
                .then(function(data) {
                    if (window.cordova) {
                        // On mobile device
                        $cordovaAppVersion.getVersionNumber().then(function(version) {
                            if (data && data.app) {
                                $startup.defaultState(route, {
                                    'update': $startup.processAppInfo(data.app.mobile, version)
                                });
                            } else {
                                $startup.defaultState(route);
                            }
                        });
                    } else {
                        // On browser local dev
                        $startup.defaultState(route);
                    }
                });


        }

        $rootScope.$on('$cordovaNetwork:online', function() {
            var list = $storage.get('offersToSync');
            lodash.forEach(list, function(id) {
                if (id) {
                    offers.consult(id);
                }
            });
        });

    }
})();