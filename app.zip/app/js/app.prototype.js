(function() {
  angular
  .module('purple-wind')
  .config(config);

  function config() {
    Date.prototype.getQuantiemeInYear = function getQuantiemeInYearFn(){
      var dateCourante = this;
      var dateDebutAnnee = new Date();

      // On affecte à la date du début de l'année, le mois 1, le jour 1 et l'année courante
      dateDebutAnnee.setDate(1);
      dateDebutAnnee.setMonth(0);
      dateDebutAnnee.setFullYear(dateCourante.getFullYear());

      // On calcule la différence entre les deux dates. Le résultat étant en millisecondes, il faut convertir les millisecondes en jours
      return Math.trunc(((dateCourante.getTime() - dateDebutAnnee.getTime()) / (24 * 3600 * 1000))+1);
    }
  }
})();