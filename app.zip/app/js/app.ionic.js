(function() {
    angular
        .module('purple-wind')
        .config(config);

    function config($ionicConfigProvider, $httpProvider) {
        //$http configuration
        $httpProvider.defaults.headers.common = {};
        $httpProvider.defaults.headers.post = {
            'Content-Type': 'application/json'
        };
        $httpProvider.defaults.headers.put = {
            'Content-Type': 'application/json'
        };
        $httpProvider.defaults.headers.patch = {};
        $httpProvider.defaults.timeout = 5000;
        //Configure tabs position set to bottom for both
        //Android and iOS
        $ionicConfigProvider.tabs
            .position('bottom')
            .style('standard');
        // Configure back button
        $ionicConfigProvider.backButton
            .previousTitleText(false)
            .text('');
    }
})();